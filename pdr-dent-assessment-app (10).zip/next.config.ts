import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Разрешаем загружать локальные фото любого размера в public/uploads
  images: {
    remotePatterns: [],
  },
};

export default nextConfig;
