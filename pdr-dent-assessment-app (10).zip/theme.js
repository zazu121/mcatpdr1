const fs = require('fs');
const path = require('path');
const map = {
  'text-emerald-800': 'text-emerald-400',
  'text-amber-800': 'text-amber-400',
  'bg-emerald-100': 'bg-emerald-950/50',
  'bg-amber-100': 'bg-amber-950/50',
  'bg-slate-50': 'bg-zinc-950',
  'bg-white': 'bg-zinc-900',
  'border-slate-100': 'border-zinc-800/50',
  'border-slate-200': 'border-zinc-800',
  'border-slate-300': 'border-zinc-700',
  'text-slate-900': 'text-zinc-100',
  'text-slate-800': 'text-zinc-200',
  'text-slate-700': 'text-zinc-300',
  'text-slate-600': 'text-zinc-400',
  'text-slate-500': 'text-zinc-400',
  'text-slate-400': 'text-zinc-500',
  'bg-slate-100': 'bg-zinc-800',
  'bg-slate-200': 'bg-zinc-700',
  'bg-slate-900 text-white ring-slate-900': 'bg-zinc-100 text-zinc-950 ring-zinc-100',
  'bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white': 'bg-zinc-100 px-4 py-2.5 text-sm font-semibold text-zinc-950',
  'bg-slate-900 px-3 py-1.5 text-xs font-semibold text-white': 'bg-zinc-100 px-3 py-1.5 text-xs font-semibold text-zinc-950',
  'bg-slate-900 px-4 py-2 text-sm font-semibold text-white': 'bg-zinc-100 px-4 py-2 text-sm font-semibold text-zinc-950',
  'bg-slate-900 px-3 py-2 text-xs font-semibold text-white': 'bg-zinc-100 px-3 py-2 text-xs font-semibold text-zinc-950',
  'bg-slate-900 text-white': 'bg-zinc-100 text-zinc-950',
  'bg-slate-900': 'bg-zinc-100',
  'ring-slate-200': 'ring-zinc-800',
  'ring-slate-300': 'ring-zinc-700',
  'sky-600': 'red-600',
  'sky-500': 'red-500',
  'sky-400': 'red-400',
  'sky-300': 'red-700',
  'bg-sky-50/60': 'bg-red-950/20',
  'bg-sky-50': 'bg-red-950/20',
  'border-sky-100': 'border-red-900/50',
  'border-sky-400': 'border-red-500',
  'text-sky-700': 'text-red-400',
  'text-sky-600': 'text-red-500',
  'ДентЛаб': 'MCAT PDR',
  'from-slate-900 via-slate-900 to-blue-950': 'from-zinc-900 via-zinc-950 to-red-950/20',
  'from-slate-900 to-slate-800': 'from-zinc-900 to-zinc-950',
  'bg-black/25': 'bg-black/50',
  'border-emerald-200 bg-emerald-50': 'border-emerald-900 bg-emerald-950/30',
  'border-amber-200 bg-amber-50': 'border-amber-900 bg-amber-950/30',
  'text-emerald-600': 'text-emerald-500',
  'text-amber-600': 'text-amber-500',
  'text-rose-600': 'text-red-500',
  'bg-white/85': 'bg-zinc-950/85',
  'shadow-slate-900/5': 'shadow-black/20'
};

function replaceAll(str, mapObj) {
  let res = str;
  const keys = Object.keys(mapObj).sort((a,b) => b.length - a.length);
  for (const k of keys) {
    res = res.split(k).join(mapObj[k]);
  }
  return res;
}

function walk(dir) {
  for (const f of fs.readdirSync(dir)) {
    const full = path.join(dir, f);
    if (fs.statSync(full).isDirectory()) walk(full);
    else if (full.endsWith('.tsx') || full.endsWith('.ts')) {
      const code = fs.readFileSync(full, 'utf8');
      const next = replaceAll(code, map);
      fs.writeFileSync(full, next);
    }
  }
}
walk('src');
