import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  pgEnum,
  real,
} from "drizzle-orm/pg-core";

// ---- Статус заказ-наряда / записи в журнале ----
export const jobStatus = pgEnum("job_status", [
  "scheduled",
  "arrived",
  "in_progress",
  "done",
  "delivered",
  "cancelled",
]);

// ---- Настройки (key/value) ----
export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// ---- Класс автомобиля (эконом / средний / премиум …) ----
export const carClasses = pgTable("car_classes", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  label: text("label").notNull(),
  multiplier: real("multiplier").notNull().default(1.0),
  sortOrder: integer("sort_order").notNull().default(0),
  isDefault: boolean("is_default").notNull().default(false),
});

// ---- Материал ЛКП (глянец / матовая / плёнка) ----
export const paintMaterials = pgTable("paint_materials", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  label: text("label").notNull(),
  multiplier: real("multiplier").notNull().default(1.0),
  sortOrder: integer("sort_order").notNull().default(0),
  isDefault: boolean("is_default").notNull().default(false),
});

// ---- Метод ремонта (ПДР / под покраску) ----
export const repairMethods = pgTable("repair_methods", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  label: text("label").notNull(),
  multiplier: real("multiplier").notNull().default(1.0),
  sortOrder: integer("sort_order").notNull().default(0),
  isDefault: boolean("is_default").notNull().default(false),
});

// ---- Каталог разбора / сборки (редактируемый) ----
export const riCatalog = pgTable("ri_catalog", {
  id: serial("id").primaryKey(),
  label: text("label").notNull(),
  panel: text("panel"),
  groupName: text("group_name").notNull().default("Общее"),
  price: integer("price").notNull().default(0),
  sortOrder: integer("sort_order").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
});

// ---- Доп. услуги (полировка и т.п.) ----
export const extraServices = pgTable("extra_services", {
  id: serial("id").primaryKey(),
  label: text("label").notNull(),
  description: text("description"),
  price: integer("price").notNull().default(0),
  sortOrder: integer("sort_order").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
});

// ---- Клиенты ----
export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone"),
  email: text("email"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ---- Автомобили клиента ----
export const vehicles = pgTable("vehicles", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").references(() => customers.id, { onDelete: "set null" }),
  make: text("make").notNull(),
  model: text("model"),
  year: integer("year"),
  color: text("color"),
  licensePlate: text("license_plate"),
  vin: text("vin"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ---- Заказ-наряд / запись в журнале ----
export const jobs = pgTable("jobs", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").references(() => customers.id, { onDelete: "set null" }),
  vehicleId: integer("vehicle_id").references(() => vehicles.id, { onDelete: "set null" }),

  // денормализованные поля клиента / авто
  customerName: text("customer_name"),
  phone: text("phone"),
  vehicleMake: text("vehicle_make").notNull().default(""),
  vehicleModel: text("vehicle_model"),
  vehicleYear: integer("vehicle_year"),
  vehicleColor: text("vehicle_color"),
  licensePlate: text("license_plate"),

  // характеристики работы (снимок slug/multiplier — на случай смены настроек)
  carClassSlug: text("car_class_slug"),
  carClassMult: real("car_class_mult").notNull().default(1.0),
  paintMaterialSlug: text("paint_material_slug"),
  paintMaterialMult: real("paint_material_mult").notNull().default(1.0),
  repairMethodSlug: text("repair_method_slug"),
  repairMethodMult: real("repair_method_mult").notNull().default(1.0),

  // даты
  scheduledAt: timestamp("scheduled_at", { withTimezone: true }),
  arrivedAt: timestamp("arrived_at", { withTimezone: true }),
  startedAt: timestamp("started_at", { withTimezone: true }),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  deliveredAt: timestamp("delivered_at", { withTimezone: true }),

  // финансы (все — с учётом надбавки; сумма к оплате клиенту)
  dentsTotal: integer("dents_total").notNull().default(0),
  riTotal: integer("ri_total").notNull().default(0),
  extrasTotal: integer("extras_total").notNull().default(0),
  discount: integer("discount").notNull().default(0),
  subtotal: integer("subtotal").notNull().default(0), // до надбавки
  markupPercent: real("markup_percent").notNull().default(0), // % на момент
  markupAmount: integer("markup_amount").notNull().default(0), // аренда, ₽
  totalCost: integer("total_cost").notNull().default(0), // клиенту
  earnings: integer("earnings").notNull().default(0), // мне
  paidAmount: integer("paid_amount").notNull().default(0),
  currency: text("currency").notNull().default("RUB"),

  // прочее
  status: jobStatus("status").notNull().default("scheduled"),
  notes: text("notes"),
  internalNotes: text("internal_notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// ---- Вмятины в заказ-наряде ----
export const jobDents = pgTable("job_dents", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id").notNull().references(() => jobs.id, { onDelete: "cascade" }),
  panel: text("panel").notNull(),
  dentType: text("dent_type").notNull().default("round"),
  lengthMm: integer("length_mm").notNull().default(30),
  widthMm: integer("width_mm").notNull().default(30),
  depth: text("depth").notNull().default("shallow"),
  quantity: integer("quantity").notNull().default(1),
  isAluminum: boolean("is_aluminum").notNull().default(false),
  onBodyLine: boolean("on_body_line").notNull().default(false),
  gluePull: boolean("glue_pull").notNull().default(false),
  hardAccess: boolean("hard_access").notNull().default(false),
  unitPrice: integer("unit_price").notNull().default(0),
  lineTotal: integer("line_total").notNull().default(0),
  notes: text("notes"),
  sortOrder: integer("sort_order").notNull().default(0),
});

// ---- Разбор / сборка (R&I) по элементам ----
export const jobRiItems = pgTable("job_ri_items", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id").notNull().references(() => jobs.id, { onDelete: "cascade" }),
  itemId: text("item_id").notNull(),
  label: text("label").notNull(),
  panel: text("panel"),
  price: integer("price").notNull().default(0),
  quantity: integer("quantity").notNull().default(1),
  lineTotal: integer("line_total").notNull().default(0),
  notes: text("notes"),
});

// ---- Доп. услуги в заказ-наряде ----
export const jobExtras = pgTable("job_extras", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id").notNull().references(() => jobs.id, { onDelete: "cascade" }),
  serviceId: integer("service_id"),
  label: text("label").notNull(),
  price: integer("price").notNull().default(0),
  quantity: integer("quantity").notNull().default(1),
  lineTotal: integer("line_total").notNull().default(0),
  notes: text("notes"),
});

// ---- Фото по заказ-наряду ----
export const jobPhotos = pgTable("job_photos", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id").notNull().references(() => jobs.id, { onDelete: "cascade" }),
  url: text("url").notNull(),
  caption: text("caption"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ---- Транзакции кошелька (ручные, помимо job) ----
export const walletEntries = pgTable("wallet_entries", {
  id: serial("id").primaryKey(),
  kind: text("kind").notNull().default("income"), // income | expense
  amount: integer("amount").notNull().default(0),
  category: text("category"),
  description: text("description"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ---- Настраиваемые справочники калькулятора ----
// kind: panel | size_preset | dent_type | depth | surcharge
export const calcOptions = pgTable("calc_options", {
  id: serial("id").primaryKey(),
  kind: text("kind").notNull(),
  slug: text("slug").notNull(),
  label: text("label").notNull(),
  emoji: text("emoji"),
  // множитель для panel/dent_type/depth; для surcharge — процент (0.3 = +30%)
  multiplier: real("multiplier").notNull().default(1.0),
  // для size_preset — размеры
  lengthMm: integer("length_mm"),
  widthMm: integer("width_mm"),
  groupName: text("group_name"),
  sortOrder: integer("sort_order").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
});

// ---- Фото автомобилей клиента ----
export const vehiclePhotos = pgTable("vehicle_photos", {
  id: serial("id").primaryKey(),
  vehicleId: integer("vehicle_id").notNull().references(() => vehicles.id, { onDelete: "cascade" }),
  url: text("url").notNull(),
  caption: text("caption"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ---- Types ----
export type Customer = typeof customers.$inferSelect;
export type NewCustomer = typeof customers.$inferInsert;
export type Vehicle = typeof vehicles.$inferSelect;
export type NewVehicle = typeof vehicles.$inferInsert;
export type Job = typeof jobs.$inferSelect;
export type NewJob = typeof jobs.$inferInsert;
export type JobDent = typeof jobDents.$inferSelect;
export type NewJobDent = typeof jobDents.$inferInsert;
export type JobRiItem = typeof jobRiItems.$inferSelect;
export type NewJobRiItem = typeof jobRiItems.$inferInsert;
export type JobExtra = typeof jobExtras.$inferSelect;
export type NewJobExtra = typeof jobExtras.$inferInsert;
export type JobPhoto = typeof jobPhotos.$inferSelect;
export type CarClass = typeof carClasses.$inferSelect;
export type PaintMaterial = typeof paintMaterials.$inferSelect;
export type RepairMethod = typeof repairMethods.$inferSelect;
export type RiCatalogRow = typeof riCatalog.$inferSelect;
export type ExtraServiceRow = typeof extraServices.$inferSelect;
export type WalletEntry = typeof walletEntries.$inferSelect;
export type Setting = typeof settings.$inferSelect;
export type CalcOption = typeof calcOptions.$inferSelect;
export type NewCalcOption = typeof calcOptions.$inferInsert;
export type VehiclePhoto = typeof vehiclePhotos.$inferSelect;
