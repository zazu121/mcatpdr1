import { sql } from "drizzle-orm";
import { db } from "@/db";

/**
 * Автоматическая инициализация базы при первом запуске (в т.ч. на хостинге).
 * Создаёт все таблицы, если их нет, и заливает справочники по умолчанию.
 * Идемпотентно: повторные вызовы безопасны.
 */

const globalForBoot = globalThis as typeof globalThis & {
  __mcatBootPromise?: Promise<void>;
  __mcatBootOk?: boolean;
};

async function createSchema() {
  // ENUM статусов
  await db.execute(sql`
    DO $$ BEGIN
      CREATE TYPE job_status AS ENUM ('scheduled','arrived','in_progress','done','delivered','cancelled');
    EXCEPTION WHEN duplicate_object THEN NULL; END $$;
  `);

  await db.execute(sql`CREATE TABLE IF NOT EXISTS settings (
    key text PRIMARY KEY,
    value text NOT NULL,
    updated_at timestamptz NOT NULL DEFAULT now()
  )`);

  await db.execute(sql`CREATE TABLE IF NOT EXISTS car_classes (
    id serial PRIMARY KEY,
    slug text NOT NULL UNIQUE,
    label text NOT NULL,
    multiplier real NOT NULL DEFAULT 1,
    sort_order integer NOT NULL DEFAULT 0,
    is_default boolean NOT NULL DEFAULT false
  )`);

  await db.execute(sql`CREATE TABLE IF NOT EXISTS paint_materials (
    id serial PRIMARY KEY,
    slug text NOT NULL UNIQUE,
    label text NOT NULL,
    multiplier real NOT NULL DEFAULT 1,
    sort_order integer NOT NULL DEFAULT 0,
    is_default boolean NOT NULL DEFAULT false
  )`);

  await db.execute(sql`CREATE TABLE IF NOT EXISTS repair_methods (
    id serial PRIMARY KEY,
    slug text NOT NULL UNIQUE,
    label text NOT NULL,
    multiplier real NOT NULL DEFAULT 1,
    sort_order integer NOT NULL DEFAULT 0,
    is_default boolean NOT NULL DEFAULT false
  )`);

  await db.execute(sql`CREATE TABLE IF NOT EXISTS ri_catalog (
    id serial PRIMARY KEY,
    label text NOT NULL,
    panel text,
    group_name text NOT NULL DEFAULT 'Общее',
    price integer NOT NULL DEFAULT 0,
    sort_order integer NOT NULL DEFAULT 0,
    is_active boolean NOT NULL DEFAULT true
  )`);

  await db.execute(sql`CREATE TABLE IF NOT EXISTS extra_services (
    id serial PRIMARY KEY,
    label text NOT NULL,
    description text,
    price integer NOT NULL DEFAULT 0,
    sort_order integer NOT NULL DEFAULT 0,
    is_active boolean NOT NULL DEFAULT true
  )`);

  await db.execute(sql`CREATE TABLE IF NOT EXISTS calc_options (
    id serial PRIMARY KEY,
    kind text NOT NULL,
    slug text NOT NULL,
    label text NOT NULL,
    emoji text,
    multiplier real NOT NULL DEFAULT 1,
    length_mm integer,
    width_mm integer,
    group_name text,
    sort_order integer NOT NULL DEFAULT 0,
    is_active boolean NOT NULL DEFAULT true
  )`);

  await db.execute(sql`CREATE TABLE IF NOT EXISTS customers (
    id serial PRIMARY KEY,
    name text NOT NULL,
    phone text,
    email text,
    notes text,
    created_at timestamptz NOT NULL DEFAULT now()
  )`);

  await db.execute(sql`CREATE TABLE IF NOT EXISTS vehicles (
    id serial PRIMARY KEY,
    customer_id integer REFERENCES customers(id) ON DELETE SET NULL,
    make text NOT NULL,
    model text,
    year integer,
    color text,
    license_plate text,
    vin text,
    notes text,
    created_at timestamptz NOT NULL DEFAULT now()
  )`);

  await db.execute(sql`CREATE TABLE IF NOT EXISTS jobs (
    id serial PRIMARY KEY,
    customer_id integer REFERENCES customers(id) ON DELETE SET NULL,
    vehicle_id integer REFERENCES vehicles(id) ON DELETE SET NULL,
    customer_name text,
    phone text,
    vehicle_make text NOT NULL DEFAULT '',
    vehicle_model text,
    vehicle_year integer,
    vehicle_color text,
    license_plate text,
    car_class_slug text,
    car_class_mult real NOT NULL DEFAULT 1,
    paint_material_slug text,
    paint_material_mult real NOT NULL DEFAULT 1,
    repair_method_slug text,
    repair_method_mult real NOT NULL DEFAULT 1,
    scheduled_at timestamptz,
    arrived_at timestamptz,
    started_at timestamptz,
    completed_at timestamptz,
    delivered_at timestamptz,
    dents_total integer NOT NULL DEFAULT 0,
    ri_total integer NOT NULL DEFAULT 0,
    extras_total integer NOT NULL DEFAULT 0,
    discount integer NOT NULL DEFAULT 0,
    subtotal integer NOT NULL DEFAULT 0,
    markup_percent real NOT NULL DEFAULT 0,
    markup_amount integer NOT NULL DEFAULT 0,
    total_cost integer NOT NULL DEFAULT 0,
    earnings integer NOT NULL DEFAULT 0,
    paid_amount integer NOT NULL DEFAULT 0,
    currency text NOT NULL DEFAULT 'RUB',
    status job_status NOT NULL DEFAULT 'scheduled',
    notes text,
    internal_notes text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
  )`);

  await db.execute(sql`CREATE TABLE IF NOT EXISTS job_dents (
    id serial PRIMARY KEY,
    job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    panel text NOT NULL,
    dent_type text NOT NULL DEFAULT 'round',
    length_mm integer NOT NULL DEFAULT 30,
    width_mm integer NOT NULL DEFAULT 30,
    depth text NOT NULL DEFAULT 'shallow',
    quantity integer NOT NULL DEFAULT 1,
    is_aluminum boolean NOT NULL DEFAULT false,
    on_body_line boolean NOT NULL DEFAULT false,
    glue_pull boolean NOT NULL DEFAULT false,
    hard_access boolean NOT NULL DEFAULT false,
    unit_price integer NOT NULL DEFAULT 0,
    line_total integer NOT NULL DEFAULT 0,
    notes text,
    sort_order integer NOT NULL DEFAULT 0
  )`);

  await db.execute(sql`CREATE TABLE IF NOT EXISTS job_ri_items (
    id serial PRIMARY KEY,
    job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    item_id text NOT NULL,
    label text NOT NULL,
    panel text,
    price integer NOT NULL DEFAULT 0,
    quantity integer NOT NULL DEFAULT 1,
    line_total integer NOT NULL DEFAULT 0,
    notes text
  )`);

  await db.execute(sql`CREATE TABLE IF NOT EXISTS job_extras (
    id serial PRIMARY KEY,
    job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    service_id integer,
    label text NOT NULL,
    price integer NOT NULL DEFAULT 0,
    quantity integer NOT NULL DEFAULT 1,
    line_total integer NOT NULL DEFAULT 0,
    notes text
  )`);

  await db.execute(sql`CREATE TABLE IF NOT EXISTS job_photos (
    id serial PRIMARY KEY,
    job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    url text NOT NULL,
    caption text,
    created_at timestamptz NOT NULL DEFAULT now()
  )`);

  await db.execute(sql`CREATE TABLE IF NOT EXISTS vehicle_photos (
    id serial PRIMARY KEY,
    vehicle_id integer NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
    url text NOT NULL,
    caption text,
    created_at timestamptz NOT NULL DEFAULT now()
  )`);

  await db.execute(sql`CREATE TABLE IF NOT EXISTS wallet_entries (
    id serial PRIMARY KEY,
    kind text NOT NULL DEFAULT 'income',
    amount integer NOT NULL DEFAULT 0,
    category text,
    description text,
    created_at timestamptz NOT NULL DEFAULT now()
  )`);
}

async function seedDefaults() {
  // ---- Настройки ----
  await db.execute(sql`
    INSERT INTO settings(key,value) VALUES
      ('markup_percent','40'),
      ('markup_label','Аренда бокса'),
      ('tz_offset','3'),
      ('rate_per_cm2','180'),
      ('min_dent_price','1200')
    ON CONFLICT (key) DO NOTHING
  `);

  // ---- Классы авто ----
  await db.execute(sql`
    INSERT INTO car_classes(slug,label,multiplier,sort_order,is_default) VALUES
      ('economy','Эконом',1.0,1,true),
      ('mid','Средний',1.15,2,false),
      ('premium','Премиум',1.35,3,false),
      ('luxury','Люкс',1.6,4,false)
    ON CONFLICT (slug) DO NOTHING
  `);

  // ---- Материал ЛКП ----
  await db.execute(sql`
    INSERT INTO paint_materials(slug,label,multiplier,sort_order,is_default) VALUES
      ('gloss','Глянец',1.0,1,true),
      ('matte','Матовая краска',1.4,2,false),
      ('wrap','Плёнка',1.2,3,false)
    ON CONFLICT (slug) DO NOTHING
  `);

  // ---- Метод ремонта ----
  await db.execute(sql`
    INSERT INTO repair_methods(slug,label,multiplier,sort_order,is_default) VALUES
      ('pdr','ПДР (без покраски)',1.0,1,true),
      ('paint','Под покраску',0.85,2,false)
    ON CONFLICT (slug) DO NOTHING
  `);

  // ---- Каталог разбора (только если пусто) ----
  const ri = await db.execute(sql`SELECT count(*)::int AS c FROM ri_catalog`);
  const riCount = Number((ri.rows?.[0] as { c?: number } | undefined)?.c ?? 0);
  if (riCount === 0) {
    await db.execute(sql`
      INSERT INTO ri_catalog(label,panel,group_name,price,sort_order) VALUES
        ('Обшивка двери передней','lf_door','Двери',800,1),
        ('Обшивка двери задней','lr_door','Двери',800,2),
        ('Модуль стеклоподъёмника','lf_door','Двери',1200,3),
        ('Ручка двери (наруж.)','lf_door','Двери',500,4),
        ('Зеркало боковое','lf_door','Двери',700,5),
        ('Стекло двери','lf_door','Двери',1000,6),
        ('Уплотнитель двери','lf_door','Двери',400,7),
        ('Шумоизоляция капота','hood','Перед',500,10),
        ('Упор капота','hood','Перед',300,11),
        ('Фара','lf_fender','Перед',1500,12),
        ('Подкрылок','lf_fender','Перед',600,13),
        ('Колесо (снятие)','lf_fender','Перед',300,14),
        ('Передний бампер','front_bumper','Перед',2500,15),
        ('Решётка радиатора','front_bumper','Перед',800,16),
        ('Потолок (частично)','roof','Крыша',3500,20),
        ('Потолок (полностью)','roof','Крыша',6000,21),
        ('Рейлинги крыши','roof_rail','Крыша',1500,22),
        ('Люк / панорама','roof','Крыша',2500,23),
        ('Антенна / плавник','roof','Крыша',400,24),
        ('Обшивка багажника','trunk','Зад',700,30),
        ('Задний фонарь','rr_quarter','Зад',900,31),
        ('Задний бампер','rear_bumper','Зад',2500,32),
        ('Заднее стекло','trunk','Зад',2000,33),
        ('Спойлер','trunk','Зад',800,34),
        ('Обшивка 5-й двери','tailgate','Зад',900,35),
        ('Обшивка четверти','lr_quarter','Четверти',1200,40),
        ('Задний диван (снятие)','lr_quarter','Четверти',1000,41),
        ('Обшивка стойки C','pillar','Четверти',800,42),
        ('Обшивка стойки B','pillar','Четверти',700,43),
        ('Клемма АКБ (откл.)',NULL,'Общее',200,50),
        ('Парктроник / датчик',NULL,'Общее',400,51),
        ('Камера / радар',NULL,'Общее',600,52),
        ('Молдинг / накладка',NULL,'Общее',500,53),
        ('Эмблема / шильдик',NULL,'Общее',300,54)
    `);
  }

  // ---- Доп. услуги (только если пусто) ----
  const ex = await db.execute(sql`SELECT count(*)::int AS c FROM extra_services`);
  const exCount = Number((ex.rows?.[0] as { c?: number } | undefined)?.c ?? 0);
  if (exCount === 0) {
    await db.execute(sql`
      INSERT INTO extra_services(label,description,price,sort_order) VALUES
        ('Полировка повреждения','Локальная полировка после ремонта',1500,1),
        ('Полировка кузова','Абразивная полировка всего кузова',8000,2),
        ('Керамика (1 элемент)','Защитное покрытие детали',4500,3),
        ('Мойка перед ремонтом','Подготовка кузова к работе',500,4),
        ('Выезд к клиенту','В пределах города',1000,5),
        ('Диагностика вмятины','Осмотр в PDR-свете',500,6)
    `);
  }

  // ---- Справочники калькулятора (только если пусто) ----
  const co = await db.execute(sql`SELECT count(*)::int AS c FROM calc_options`);
  const coCount = Number((co.rows?.[0] as { c?: number } | undefined)?.c ?? 0);
  if (coCount === 0) {
    await db.execute(sql`
      INSERT INTO calc_options(kind,slug,label,emoji,multiplier,sort_order) VALUES
        ('panel','hood','Капот','⬆️',1.0,1),
        ('panel','roof','Крыша','🏠',1.05,2),
        ('panel','lf_door','Дверь ЛП','🚪',1.15,3),
        ('panel','rf_door','Дверь ПП','🚪',1.15,4),
        ('panel','lr_door','Дверь ЛЗ','🚪',1.2,5),
        ('panel','rr_door','Дверь ПЗ','🚪',1.2,6),
        ('panel','lf_fender','Крыло ЛП','🛡️',1.15,7),
        ('panel','rf_fender','Крыло ПП','🛡️',1.15,8),
        ('panel','lr_quarter','Четверть ЛЗ','🔩',1.35,9),
        ('panel','rr_quarter','Четверть ПЗ','🔩',1.35,10),
        ('panel','trunk','Крышка багажника','📦',1.0,11),
        ('panel','front_bumper','Передний бампер','⬛',1.1,12),
        ('panel','rear_bumper','Задний бампер','⬛',1.1,13),
        ('panel','tailgate','Дверь багажника','📦',1.1,14),
        ('panel','pillar','Стойка A/B/C','┃',1.55,15),
        ('panel','rocker','Порог','━',1.45,16)
    `);
    await db.execute(sql`
      INSERT INTO calc_options(kind,slug,label,length_mm,width_mm,sort_order) VALUES
        ('size_preset','coin','Монета',25,25,1),
        ('size_preset','thumb','Палец',40,40,2),
        ('size_preset','fist','Кулак',80,80,3),
        ('size_preset','palm','Ладонь',120,100,4),
        ('size_preset','long','Длинная',200,40,5),
        ('size_preset','xl','Большая',250,180,6)
    `);
    await db.execute(sql`
      INSERT INTO calc_options(kind,slug,label,multiplier,sort_order) VALUES
        ('dent_type','round','Круглая / овальная',1.0,1),
        ('dent_type','door_ding','От двери',0.95,2),
        ('dent_type','hail','Град',0.7,3),
        ('dent_type','crease','Складка / линия',1.45,4),
        ('dent_type','sharp','Острая',1.35,5),
        ('dent_type','stretched','С растяжкой',1.7,6),
        ('depth','shallow','Поверхностная',1.0,1),
        ('depth','medium','Средняя',1.2,2),
        ('depth','deep','Глубокая',1.45,3),
        ('surcharge','isAluminum','Алюминий',0.3,1),
        ('surcharge','onBodyLine','На ребре',0.25,2),
        ('surcharge','gluePull','Glue pull',0.2,3),
        ('surcharge','hardAccess','Сложный доступ',0.35,4)
    `);
  }
}

/** Гарантирует готовность БД. Выполняется один раз на процесс. */
export function ensureDb(): Promise<void> {
  if (globalForBoot.__mcatBootOk) return Promise.resolve();
  if (!globalForBoot.__mcatBootPromise) {
    globalForBoot.__mcatBootPromise = (async () => {
      try {
        await createSchema();
        await seedDefaults();
        globalForBoot.__mcatBootOk = true;
      } catch (e) {
        console.error("[MCAT] Ошибка инициализации БД:", e);
        // Сбрасываем, чтобы попробовать снова при следующем запросе
        globalForBoot.__mcatBootPromise = undefined;
        throw e;
      }
    })();
  }
  return globalForBoot.__mcatBootPromise;
}

/** Безопасный вариант: не роняет страницу, если БД недоступна. */
export async function ensureDbSafe(): Promise<boolean> {
  try {
    await ensureDb();
    return true;
  } catch {
    return false;
  }
}
