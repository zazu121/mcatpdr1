import { drizzle } from "drizzle-orm/node-postgres";
import type { NodePgDatabase } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

/**
 * Ленивое подключение к БД.
 *
 * ВАЖНО: раньше здесь был `throw new Error("DATABASE_URL is required")` на верхнем
 * уровне модуля. Из-за этого `next build` падал на шаге "Collecting page data",
 * потому что Next импортирует все API-роуты, а переменной окружения при сборке нет.
 *
 * Теперь пул создаётся только при первом реальном обращении к БД.
 */

const globalForDb = globalThis as typeof globalThis & {
  __mcatPool?: Pool;
  __mcatDb?: NodePgDatabase<Record<string, never>>;
};

function getConnectionString(): string {
  return (
    process.env.DATABASE_URL ??
    "postgresql://postgres:postgres@127.0.0.1:5432/app_db"
  );
}

export function getPool(): Pool {
  if (!globalForDb.__mcatPool) {
    globalForDb.__mcatPool = new Pool({ connectionString: getConnectionString() });
  }
  return globalForDb.__mcatPool;
}

function getDb(): NodePgDatabase<Record<string, never>> {
  if (!globalForDb.__mcatDb) {
    globalForDb.__mcatDb = drizzle(getPool());
  }
  return globalForDb.__mcatDb;
}

// Прокси: реальное подключение создаётся только при первом обращении (db.select(), ...)
export const db = new Proxy({} as NodePgDatabase<Record<string, never>>, {
  get(_target, prop, receiver) {
    const real = getDb();
    const value = Reflect.get(real as object, prop, receiver);
    return typeof value === "function" ? value.bind(real) : value;
  },
});

export const pool = new Proxy({} as Pool, {
  get(_target, prop, receiver) {
    const real = getPool();
    const value = Reflect.get(real as object, prop, receiver);
    return typeof value === "function" ? value.bind(real) : value;
  },
});
