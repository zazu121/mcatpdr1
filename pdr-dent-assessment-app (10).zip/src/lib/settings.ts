import { db } from "@/db";
import {
  settings,
  carClasses,
  paintMaterials,
  repairMethods,
  riCatalog,
  extraServices,
  calcOptions,
  type CarClass,
  type PaintMaterial,
  type RepairMethod,
  type RiCatalogRow,
  type ExtraServiceRow,
  type CalcOption,
} from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { ensureDbSafe } from "@/db/bootstrap";
import { SETTING_KEYS, DEFAULT_MARKUP_PERCENT, DEFAULT_MARKUP_LABEL, SETTING_TZ, DEFAULT_TZ_OFFSET } from "@/lib/pdr";

export async function getTzOffset(): Promise<number> {
  const v = await getSetting(SETTING_TZ);
  const n = v !== null ? Number(v) : DEFAULT_TZ_OFFSET;
  return Number.isFinite(n) ? n : DEFAULT_TZ_OFFSET;
}

export async function getSetting(key: string): Promise<string | null> {
  await ensureDbSafe();
  try {
    const [row] = await db.select().from(settings).where(eq(settings.key, key));
    return row?.value ?? null;
  } catch {
    return null;
  }
}

export async function setSetting(key: string, value: string) {
  await ensureDbSafe();
  const existing = await db.select().from(settings).where(eq(settings.key, key));
  if (existing.length) {
    await db
      .update(settings)
      .set({ value, updatedAt: new Date() })
      .where(eq(settings.key, key));
  } else {
    await db.insert(settings).values({ key, value });
  }
}

export async function getMarkupPercent(): Promise<number> {
  const v = await getSetting(SETTING_KEYS.markupPercent);
  const n = v ? Number(v) : DEFAULT_MARKUP_PERCENT;
  return Number.isFinite(n) && n >= 0 ? n : DEFAULT_MARKUP_PERCENT;
}

export async function getMarkupLabel(): Promise<string> {
  const v = await getSetting(SETTING_KEYS.markupLabel);
  return v ?? DEFAULT_MARKUP_LABEL;
}

export async function listCarClasses(): Promise<CarClass[]> {
  await ensureDbSafe();
  try {
    return await db.select().from(carClasses).orderBy(asc(carClasses.sortOrder), asc(carClasses.id));
  } catch {
    return [];
  }
}

export async function listPaintMaterials(): Promise<PaintMaterial[]> {
  await ensureDbSafe();
  try {
    return await db
      .select()
      .from(paintMaterials)
      .orderBy(asc(paintMaterials.sortOrder), asc(paintMaterials.id));
  } catch {
    return [];
  }
}

export async function listRepairMethods(): Promise<RepairMethod[]> {
  await ensureDbSafe();
  try {
    return await db
      .select()
      .from(repairMethods)
      .orderBy(asc(repairMethods.sortOrder), asc(repairMethods.id));
  } catch {
    return [];
  }
}

export async function listRiCatalog(): Promise<RiCatalogRow[]> {
  await ensureDbSafe();
  try {
    return await db
      .select()
      .from(riCatalog)
      .where(eq(riCatalog.isActive, true))
      .orderBy(asc(riCatalog.sortOrder), asc(riCatalog.id));
  } catch {
    return [];
  }
}

export async function listExtraServices(): Promise<ExtraServiceRow[]> {
  await ensureDbSafe();
  try {
    return await db
      .select()
      .from(extraServices)
      .where(eq(extraServices.isActive, true))
      .orderBy(asc(extraServices.sortOrder), asc(extraServices.id));
  } catch {
    return [];
  }
}

export async function listCalcOptions(kind: string): Promise<CalcOption[]> {
  await ensureDbSafe();
  try {
    return await db
      .select()
      .from(calcOptions)
      .where(eq(calcOptions.kind, kind))
      .orderBy(asc(calcOptions.sortOrder), asc(calcOptions.id));
  } catch {
    return [];
  }
}

export async function getRatePerCm2(): Promise<number> {
  const v = await getSetting("rate_per_cm2");
  const n = v ? Number(v) : 180;
  return Number.isFinite(n) && n > 0 ? n : 180;
}

export async function getMinDentPrice(): Promise<number> {
  const v = await getSetting("min_dent_price");
  const n = v ? Number(v) : 1200;
  return Number.isFinite(n) && n >= 0 ? n : 1200;
}

/** Загрузить всё, что нужно форме создания записи */
export async function loadJobFormReference() {
  await ensureDbSafe();
  const [markupPercent, markupLabel, cars, paints, methods, ri, extras, panels, presets, dentTypes, depths, surcharges, ratePerCm2, minDentPrice] =
    await Promise.all([
      getMarkupPercent(),
      getMarkupLabel(),
      listCarClasses(),
      listPaintMaterials(),
      listRepairMethods(),
      listRiCatalog(),
      listExtraServices(),
      listCalcOptions("panel"),
      listCalcOptions("size_preset"),
      listCalcOptions("dent_type"),
      listCalcOptions("depth"),
      listCalcOptions("surcharge"),
      getRatePerCm2(),
      getMinDentPrice(),
    ]);
  return {
    markupPercent, markupLabel,
    carClasses: cars, paintMaterials: paints, repairMethods: methods,
    riCatalog: ri, extraServices: extras,
    panels, sizePresets: presets, dentTypes, depths, surcharges,
    ratePerCm2, minDentPrice,
  };
}
