// Настройки оформления — хранятся в localStorage на устройстве мастера.

// Только тёмная тема (светлая убрана — работала криво)
export type ThemeMode = "dark";
export type Wallpaper = "standard" | "green" | "nano" | "cyber" | "detailing" | "neon";
export type NavPosition = "top" | "bottom";
export type NavStyle = "both" | "icon" | "text"; // оба | иконки | текст

export type Appearance = {
  theme: ThemeMode;
  wallpaper: Wallpaper;
  navPosition: NavPosition;
  navStyle: NavStyle;
};

export const DEFAULT_APPEARANCE: Appearance = {
  theme: "dark",
  wallpaper: "standard",
  navPosition: "top",
  navStyle: "both",
};

export const WALLPAPERS: { id: Wallpaper; label: string; preview: string }[] = [
  { id: "standard", label: "Стандарт", preview: "linear-gradient(135deg,#18181b,#7f1d1d)" },
  { id: "green", label: "Тёмно-зелёное", preview: "linear-gradient(135deg,#071410,#059669)" },
  { id: "nano", label: "Нано", preview: "linear-gradient(135deg,#0a0a14,#6366f1,#a855f7)" },
  { id: "cyber", label: "Кибер", preview: "linear-gradient(135deg,#06060a,#06b6d4,#ec4899)" },
  { id: "detailing", label: "Детейлинг", preview: "linear-gradient(135deg,#0c0a09,#f59e0b)" },
  { id: "neon", label: "Неон (анимация)", preview: "linear-gradient(135deg,#08080a,#ef4444)" },
];

const KEY = "mcat_appearance";

export function loadAppearance(): Appearance {
  if (typeof window === "undefined") return DEFAULT_APPEARANCE;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT_APPEARANCE;
    return { ...DEFAULT_APPEARANCE, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_APPEARANCE;
  }
}

export function saveAppearance(a: Appearance) {
  if (typeof window === "undefined") return;
  localStorage.setItem(KEY, JSON.stringify(a));
  applyAppearance(a);
  window.dispatchEvent(new CustomEvent("appearance-change", { detail: a }));
}

export function applyAppearance(a: Appearance) {
  if (typeof document === "undefined") return;
  const html = document.documentElement;
  html.classList.remove("dark", "light");
  html.classList.add("dark"); // всегда тёмная
  html.classList.remove("wp-standard", "wp-green", "wp-nano", "wp-cyber", "wp-detailing", "wp-neon");
  html.classList.add(`wp-${a.wallpaper}`);
  html.classList.toggle("nav-bottom", a.navPosition === "bottom");
  html.classList.toggle("nav-top", a.navPosition === "top");
}
