export type Option = { id: string; label: string; desc?: string };

export const PANELS: (Option & { emoji: string; accessMultiplier: number; group: string; })[] = [
  { id: "hood", label: "Капот", emoji: "⬆️", accessMultiplier: 1.0, group: "Перед" },
  { id: "front_bumper", label: "Передний бампер", emoji: "⬛", accessMultiplier: 1.1, group: "Перед" },
  { id: "lf_fender", label: "Крыло ЛП", emoji: "🛡️", accessMultiplier: 1.15, group: "Перед" },
  { id: "rf_fender", label: "Крыло ПП", emoji: "🛡️", accessMultiplier: 1.15, group: "Перед" },
  { id: "lf_door", label: "Дверь ЛП", emoji: "🚪", accessMultiplier: 1.15, group: "Бок" },
  { id: "rf_door", label: "Дверь ПП", emoji: "🚪", accessMultiplier: 1.15, group: "Бок" },
  { id: "lr_door", label: "Дверь ЛЗ", emoji: "🚪", accessMultiplier: 1.2, group: "Бок" },
  { id: "rr_door", label: "Дверь ПЗ", emoji: "🚪", accessMultiplier: 1.2, group: "Бок" },
  { id: "roof", label: "Крыша", emoji: "🏠", accessMultiplier: 1.05, group: "Верх" },
  { id: "roof_rail", label: "Рейлинг / кромка крыши", emoji: "➖", accessMultiplier: 1.4, group: "Верх" },
  { id: "lr_quarter", label: "Четверть ЛЗ", emoji: "🔩", accessMultiplier: 1.35, group: "Зад" },
  { id: "rr_quarter", label: "Четверть ПЗ", emoji: "🔩", accessMultiplier: 1.35, group: "Зад" },
  { id: "trunk", label: "Крышка багажника", emoji: "📦", accessMultiplier: 1.0, group: "Зад" },
  { id: "rear_bumper", label: "Задний бампер", emoji: "⬛", accessMultiplier: 1.1, group: "Зад" },
  { id: "tailgate", label: "Дверь багажника (SUV)", emoji: "📦", accessMultiplier: 1.1, group: "Зад" },
  { id: "pillar", label: "Стойка A/B/C", emoji: "┃", accessMultiplier: 1.55, group: "Сложные" },
  { id: "rocker", label: "Порог", emoji: "━", accessMultiplier: 1.45, group: "Сложные" },
  { id: "other", label: "Другое", emoji: "🔧", accessMultiplier: 1.2, group: "Сложные" },
];

export const DENT_TYPES: (Option & { multiplier: number })[] = [
  { id: "round", label: "Круглая / овальная", desc: "мяч, камень, парковка", multiplier: 1.0 },
  { id: "door_ding", label: "От двери", desc: "точечный удар соседней дверью", multiplier: 0.95 },
  { id: "hail", label: "Град", desc: "мелкая, типичная градовая", multiplier: 0.7 },
  { id: "crease", label: "Складка / линия", desc: "вытянутая вмятина-полоса", multiplier: 1.45 },
  { id: "sharp", label: "Острая", desc: "глубокий точечный провал", multiplier: 1.35 },
  { id: "stretched", label: "С растяжкой", desc: "металл вытянут, нужна усадка", multiplier: 1.7 },
];

export const DENT_DEPTHS: (Option & { multiplier: number })[] = [
  { id: "shallow", label: "Поверхностная", desc: "лёгкий провал", multiplier: 1.0 },
  { id: "medium", label: "Средняя", desc: "заметный провал", multiplier: 1.2 },
  { id: "deep", label: "Глубокая", desc: "сильный провал / стяжка", multiplier: 1.45 },
];

export const SURCHARGE = { aluminum: 0.3, bodyLine: 0.25, gluePull: 0.2, hardAccess: 0.35 };

export const MIN_JOB_COST = 1500;
const BASE_RATE_PER_CM2 = 180;
const MIN_DENT_PRICE = 1200;
const MAX_SINGLE_DENT = 45000;

export type DentInput = {
  panel: string; dentType: string; lengthMm: number; widthMm: number; depth: string; quantity: number;
  isAluminum: boolean; onBodyLine: boolean; gluePull: boolean; hardAccess: boolean; extraMultipliers?: number[];
};

export type DentBreakdown = {
  lengthMm: number; widthMm: number; areaCm2: number; sizeFactor: number; base: number; typeMultiplier: number;
  accessMultiplier: number; depthMultiplier: number; surcharges: { key: string; label: string; pct: number }[];
  surchargeMultiplier: number; extraMultiplier: number; unitPrice: number; quantity: number; lineTotal: number;
};

function find<T extends { id: string }>(list: T[], id: string): T | undefined { return list.find((x) => x.id === id); }

function sizeFactor(areaCm2: number): number {
  if (areaCm2 <= 5) return 1.45;
  if (areaCm2 <= 15) return 1.45 - ((areaCm2 - 5) / 10) * 0.45;
  if (areaCm2 <= 50) return 1.0 - ((areaCm2 - 15) / 35) * 0.35;
  if (areaCm2 <= 120) return 0.65 - ((areaCm2 - 50) / 70) * 0.15;
  return 0.5;
}

export type DentConfig = {
  ratePerCm2?: number;
  minDentPrice?: number;
  panels?: { id: string; multiplier: number }[];
  dentTypes?: { id: string; multiplier: number }[];
  depths?: { id: string; multiplier: number }[];
  surchargePct?: { aluminum?: number; bodyLine?: number; gluePull?: number; hardAccess?: number };
};

export function calculateDent(input: DentInput, config?: DentConfig): DentBreakdown {
  const rate = config?.ratePerCm2 ?? BASE_RATE_PER_CM2;
  const minDent = config?.minDentPrice ?? MIN_DENT_PRICE;

  const panelMul = config?.panels?.find((p) => p.id === input.panel)?.multiplier
    ?? (find(PANELS, input.panel) ?? PANELS[0]).accessMultiplier;
  const typeMul = config?.dentTypes?.find((t) => t.id === input.dentType)?.multiplier
    ?? (find(DENT_TYPES, input.dentType) ?? DENT_TYPES[0]).multiplier;
  const depthMul = config?.depths?.find((d) => d.id === input.depth)?.multiplier
    ?? (find(DENT_DEPTHS, input.depth) ?? DENT_DEPTHS[0]).multiplier;

  const qty = Math.max(1, Math.floor(input.quantity || 1));
  const lengthMm = Math.max(5, Math.round(input.lengthMm || 30));
  const widthMm = Math.max(5, Math.round(input.widthMm || 30));

  const l = lengthMm / 10;
  const w = widthMm / 10;
  const areaCm2 = Math.round(l * w * 10) / 10;
  const sf = sizeFactor(areaCm2);
  const base = Math.round(areaCm2 * rate * sf);

  const sp = config?.surchargePct ?? {};
  const alu = sp.aluminum ?? SURCHARGE.aluminum;
  const bl = sp.bodyLine ?? SURCHARGE.bodyLine;
  const gp = sp.gluePull ?? SURCHARGE.gluePull;
  const ha = sp.hardAccess ?? SURCHARGE.hardAccess;
  const surcharges: DentBreakdown["surcharges"] = [];
  let surchargeMul = 1;
  if (input.isAluminum) { surcharges.push({ key: "aluminum", label: "Алюминий", pct: alu }); surchargeMul *= 1 + alu; }
  if (input.onBodyLine) { surcharges.push({ key: "bodyLine", label: "На ребре", pct: bl }); surchargeMul *= 1 + bl; }
  if (input.gluePull) { surcharges.push({ key: "gluePull", label: "Glue pull", pct: gp }); surchargeMul *= 1 + gp; }
  if (input.hardAccess) { surcharges.push({ key: "hardAccess", label: "Сложный доступ", pct: ha }); surchargeMul *= 1 + ha; }

  const extraMul = (input.extraMultipliers ?? []).reduce((s, m) => s * (m || 1), 1);
  let unit = base * typeMul * panelMul * depthMul * surchargeMul * extraMul;
  unit = Math.round(unit / 50) * 50;
  unit = Math.min(MAX_SINGLE_DENT, Math.max(minDent, unit));

  return {
    lengthMm, widthMm, areaCm2, sizeFactor: Math.round(sf * 100) / 100, base, typeMultiplier: typeMul,
    accessMultiplier: panelMul, depthMultiplier: depthMul, surcharges,
    surchargeMultiplier: Math.round(surchargeMul * 100) / 100, extraMultiplier: Math.round(extraMul * 100) / 100,
    unitPrice: unit, quantity: qty, lineTotal: unit * qty,
  };
}

export type JobTotals = {
  dentsTotal: number; riTotal: number; extrasTotal: number; discount: number; subtotal: number;
  markupPercent: number; markupAmount: number; totalCost: number; earnings: number; minApplied: boolean;
};

export function calculateJobTotals(dents: { lineTotal: number }[], riItems: { lineTotal: number }[], extras: { lineTotal: number }[], discount = 0, markupPercent = 0): JobTotals {
  const dentsTotal = dents.reduce((s, d) => s + (d.lineTotal || 0), 0);
  const riTotal = riItems.reduce((s, r) => s + (r.lineTotal || 0), 0);
  const extrasTotal = extras.reduce((s, x) => s + (x.lineTotal || 0), 0);
  const disc = Math.max(0, Math.floor(discount || 0));

  let subtotal = dentsTotal + riTotal + extrasTotal - disc;
  let minApplied = false;
  if (subtotal > 0 && subtotal < MIN_JOB_COST) { subtotal = MIN_JOB_COST; minApplied = true; }
  if (subtotal < 0) subtotal = 0;

  const mp = Math.max(0, Number(markupPercent) || 0);
  const markupAmount = Math.round((subtotal * mp) / 100);
  const totalCost = subtotal + markupAmount;

  return { dentsTotal, riTotal, extrasTotal, discount: disc, subtotal, markupPercent: mp, markupAmount, totalCost, earnings: subtotal, minApplied };
}

export function formatPrice(amount: number, currency = "RUB"): string {
  if (currency === "RUB") return `${Math.round(amount).toLocaleString("ru-RU")} ₽`;
  return `${Math.round(amount).toLocaleString("en-US")} ${currency}`;
}

export function formatSize(lengthMm: number, widthMm: number): string {
  if (lengthMm >= 10 && widthMm >= 10) {
    const l = (lengthMm / 10).toFixed(lengthMm % 10 === 0 ? 0 : 1);
    const w = (widthMm / 10).toFixed(widthMm % 10 === 0 ? 0 : 1);
    return `${l} × ${w} см`;
  }
  return `${lengthMm} × ${widthMm} мм`;
}

export function labelOf(list: Option[], id: string): string { return list.find((x) => x.id === id)?.label ?? id; }
export function panelLabel(id: string): string { return PANELS.find((p) => p.id === id)?.label ?? id; }
export function panelEmoji(id: string): string { return PANELS.find((p) => p.id === id)?.emoji ?? "🔧"; }

export const JOB_STATUS: Record<string, { label: string; short: string; color: string; dot: string }> = {
  scheduled: { label: "Запись", short: "Запись", color: "bg-blue-950/50 text-blue-400 ring-blue-900", dot: "bg-blue-500" },
  arrived: { label: "Приехал", short: "Приехал", color: "bg-violet-950/50 text-violet-400 ring-violet-900", dot: "bg-violet-500" },
  in_progress: { label: "В работе", short: "В работе", color: "bg-amber-950/50 text-amber-400 ring-amber-900", dot: "bg-amber-500" },
  done: { label: "Готово", short: "Готово", color: "bg-emerald-950/50 text-emerald-400 ring-emerald-900", dot: "bg-emerald-500" },
  delivered: { label: "Выдано", short: "Выдано", color: "bg-zinc-800/50 text-zinc-400 ring-zinc-700", dot: "bg-zinc-500" },
  cancelled: { label: "Отмена", short: "Отмена", color: "bg-red-950/50 text-red-400 ring-red-900", dot: "bg-red-500" },
};

export const JOB_STATUS_IDS = Object.keys(JOB_STATUS);
export type JobStatusId = keyof typeof JOB_STATUS;

// Всё время храним как "wall-clock" (то, что видит мастер), в UTC-режиме.
// Поэтому форматируем всегда в timeZone: "UTC", чтобы не было сдвига часового пояса.
export function formatDateTime(d: Date | string | null | undefined): string {
  if (!d) return "—";
  const date = typeof d === "string" ? new Date(d) : d;
  if (Number.isNaN(date.getTime())) return "—";
  return date.toLocaleString("ru-RU", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", timeZone: "UTC" });
}

export function formatDate(d: Date | string | null | undefined): string {
  if (!d) return "—";
  const date = typeof d === "string" ? new Date(d) : d;
  if (Number.isNaN(date.getTime())) return "—";
  return date.toLocaleDateString("ru-RU", { day: "2-digit", month: "short", year: "numeric", timeZone: "UTC" });
}

export function formatTime(d: Date | string | null | undefined): string {
  if (!d) return "";
  const date = typeof d === "string" ? new Date(d) : d;
  if (Number.isNaN(date.getTime())) return "";
  return date.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit", timeZone: "UTC" });
}

// Собрать "wall-clock" ISO строку из компонентов (год/месяц/день/час/минута)
// без конвертации в часовой пояс. Такую строку Postgres сохранит как есть.
export function wallClockISO(y: number, mo: number, d: number, h: number, mi: number): string {
  const p = (n: number) => String(n).padStart(2, "0");
  return `${y}-${p(mo + 1)}-${p(d)}T${p(h)}:${p(mi)}:00.000Z`;
}

// "Сейчас" как wall-clock в заданном часовом поясе (смещение в часах, напр. +3 для МСК).
// Возвращает Date, чей UTC-компонент равен локальному времени мастера.
export function wallClockNow(tzOffsetHours = 3): Date {
  const now = new Date();
  return new Date(now.getTime() + tzOffsetHours * 3600 * 1000);
}

export const DEFAULT_TZ_OFFSET = 3; // МСК по умолчанию
export const SETTING_TZ = "tz_offset";

export const BRANDS = [
  "Lada (ВАЗ)", "Toyota", "Kia", "Hyundai", "Volkswagen", "Nissan", "Renault",
  "BMW", "Mercedes-Benz", "Audi", "Skoda", "Mazda", "Ford", "Chevrolet",
  "Mitsubishi", "Honda", "Lexus", "Geely", "Haval", "Chery", "Exeed", "Tesla",
  "Porsche", "Land Rover", "Volvo", "Subaru", "Suzuki", "Peugeot", "Citroën",
  "Genesis", "Infiniti", "Jeep", "Changan", "Omoda", "Jaecoo",
];

export const SIZE_PRESETS: { id: string; label: string; lengthMm: number; widthMm: number }[] = [
  { id: "coin", label: "Монета", lengthMm: 25, widthMm: 25 },
  { id: "thumb", label: "Палец", lengthMm: 40, widthMm: 40 },
  { id: "fist", label: "Кулак", lengthMm: 80, widthMm: 80 },
  { id: "palm", label: "Ладонь", lengthMm: 120, widthMm: 100 },
  { id: "long", label: "Длинная", lengthMm: 200, widthMm: 40 },
  { id: "xl", label: "Большая", lengthMm: 250, widthMm: 180 },
];

export const SETTING_KEYS = { markupPercent: "markup_percent", markupLabel: "markup_label" } as const;
export const DEFAULT_MARKUP_PERCENT = 40;
export const DEFAULT_MARKUP_LABEL = "Аренда бокса";
