import { db } from "@/db";
import { customers, vehicles } from "@/db/schema";
import { eq } from "drizzle-orm";

// Подготовка "initial" для формы записи при переходе из карточки клиента.
export async function loadPrefill(searchParams: {
  customerId?: string;
  vehicleId?: string;
}): Promise<{
  customerId?: number;
  vehicleId?: number;
  customerName?: string;
  phone?: string;
  vehicleMake?: string;
  vehicleModel?: string | null;
  vehicleYear?: number | null;
  vehicleColor?: string | null;
  licensePlate?: string | null;
} | null> {
  const cid = searchParams.customerId ? Number(searchParams.customerId) : null;
  if (!cid || Number.isNaN(cid)) return null;

  const [customer] = await db.select().from(customers).where(eq(customers.id, cid));
  if (!customer) return null;

  const vid = searchParams.vehicleId ? Number(searchParams.vehicleId) : null;
  let vehicle = null;
  if (vid && !Number.isNaN(vid)) {
    const rows = await db.select().from(vehicles).where(eq(vehicles.id, vid));
    vehicle = rows[0] ?? null;
  }
  if (!vehicle) {
    const rows = await db.select().from(vehicles).where(eq(vehicles.customerId, cid)).limit(1);
    vehicle = rows[0] ?? null;
  }

  return {
    customerId: customer.id,
    vehicleId: vehicle?.id,
    customerName: customer.name,
    phone: customer.phone ?? "",
    vehicleMake: vehicle?.make ?? "",
    vehicleModel: vehicle?.model ?? null,
    vehicleYear: vehicle?.year ?? null,
    vehicleColor: vehicle?.color ?? null,
    licensePlate: vehicle?.licensePlate ?? null,
  };
}
