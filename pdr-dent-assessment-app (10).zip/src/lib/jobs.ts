import { db } from "@/db";
import { jobs, jobDents, jobRiItems, jobExtras, jobPhotos } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { calculateJobTotals } from "@/lib/pdr";

export async function recalculateJobTotals(jobId: number) {
  const dents = await db
    .select({ lineTotal: jobDents.lineTotal })
    .from(jobDents)
    .where(eq(jobDents.jobId, jobId));
  const ri = await db
    .select({ lineTotal: jobRiItems.lineTotal })
    .from(jobRiItems)
    .where(eq(jobRiItems.jobId, jobId));
  const extras = await db
    .select({ lineTotal: jobExtras.lineTotal })
    .from(jobExtras)
    .where(eq(jobExtras.jobId, jobId));

  const [job] = await db.select().from(jobs).where(eq(jobs.id, jobId));
  if (!job) return null;

  const totals = calculateJobTotals(dents, ri, extras, job.discount, job.markupPercent);
  const [updated] = await db
    .update(jobs)
    .set({
      dentsTotal: totals.dentsTotal,
      riTotal: totals.riTotal,
      extrasTotal: totals.extrasTotal,
      subtotal: totals.subtotal,
      markupAmount: totals.markupAmount,
      totalCost: totals.totalCost,
      earnings: totals.earnings,
      updatedAt: new Date(),
    })
    .where(eq(jobs.id, jobId))
    .returning();
  return updated;
}

export async function getJobFull(jobId: number) {
  const [job] = await db.select().from(jobs).where(eq(jobs.id, jobId));
  if (!job) return null;
  const dents = await db
    .select()
    .from(jobDents)
    .where(eq(jobDents.jobId, jobId))
    .orderBy(asc(jobDents.sortOrder), asc(jobDents.id));
  const riItems = await db
    .select()
    .from(jobRiItems)
    .where(eq(jobRiItems.jobId, jobId))
    .orderBy(asc(jobRiItems.id));
  const extras = await db
    .select()
    .from(jobExtras)
    .where(eq(jobExtras.jobId, jobId))
    .orderBy(asc(jobExtras.id));
  const photos = await db
    .select()
    .from(jobPhotos)
    .where(eq(jobPhotos.jobId, jobId))
    .orderBy(asc(jobPhotos.id));
  return { job, dents, riItems, extras, photos };
}
