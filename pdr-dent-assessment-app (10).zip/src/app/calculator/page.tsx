import { JobForm } from "@/components/JobForm";
import { loadJobFormReference } from "@/lib/settings";

export const dynamic = "force-dynamic";

export default async function CalculatorPage() {
  const reference = await loadJobFormReference();
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-zinc-100">Калькулятор ПДР</h1>
        <p className="mt-1 text-sm text-zinc-400">
          Длина × ширина, класс авто, ЛКП, метод ремонта, разбор и доп. услуги — цена клиенту сразу с надбавкой.
        </p>
      </div>
      <JobForm mode="create" reference={reference} />
    </div>
  );
}
