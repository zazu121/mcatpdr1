import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { vehicles } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { ensureDbSafe } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  await ensureDbSafe();
  const customerId = request.nextUrl.searchParams.get("customerId");
  try {
    if (customerId) {
      const id = Number(customerId);
      const rows = await db
        .select()
        .from(vehicles)
        .where(eq(vehicles.customerId, id))
        .orderBy(desc(vehicles.createdAt));
      return NextResponse.json({ vehicles: rows });
    }
    const rows = await db.select().from(vehicles).orderBy(desc(vehicles.createdAt)).limit(200);
    return NextResponse.json({ vehicles: rows });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ vehicles: [] });
  }
}

export async function POST(request: NextRequest) {
  await ensureDbSafe();
  try {
    const body = await request.json();
    const make = String(body.make ?? "").trim();
    if (!make) {
      return NextResponse.json({ error: "Укажите марку" }, { status: 400 });
    }
    const [row] = await db
      .insert(vehicles)
      .values({
        customerId: body.customerId ? Number(body.customerId) : null,
        make,
        model: body.model ? String(body.model).trim() : null,
        year: body.year ? Number(body.year) : null,
        color: body.color ? String(body.color).trim() : null,
        licensePlate: body.licensePlate
          ? String(body.licensePlate).trim().toUpperCase()
          : null,
        vin: body.vin ? String(body.vin).trim().toUpperCase() : null,
        notes: body.notes ? String(body.notes).trim() : null,
      })
      .returning();
    return NextResponse.json({ vehicle: row }, { status: 201 });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Не удалось создать авто" }, { status: 500 });
  }
}
