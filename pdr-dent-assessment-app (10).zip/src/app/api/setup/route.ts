import { NextResponse } from "next/server";
import { db } from "@/db";
import { sql } from "drizzle-orm";
import { ensureDb } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

async function readCounts() {
  const r = await db.execute(sql`
    SELECT
      (SELECT count(*)::int FROM car_classes) AS "carClasses",
      (SELECT count(*)::int FROM paint_materials) AS "paintMaterials",
      (SELECT count(*)::int FROM repair_methods) AS "repairMethods",
      (SELECT count(*)::int FROM ri_catalog) AS "riCatalog",
      (SELECT count(*)::int FROM extra_services) AS "extraServices",
      (SELECT count(*)::int FROM calc_options) AS "calcOptions",
      (SELECT count(*)::int FROM jobs) AS "jobs",
      (SELECT count(*)::int FROM customers) AS "customers"
  `);
  return (r.rows?.[0] as Record<string, number>) ?? {};
}

export async function GET() {
  try {
    await ensureDb();
    return NextResponse.json({ ok: true, counts: await readCounts() });
  } catch (e) {
    return NextResponse.json(
      { ok: false, error: e instanceof Error ? e.message : String(e) },
      { status: 500 }
    );
  }
}

/** Пересоздать таблицы (если нет) и долить недостающие справочники */
export async function POST() {
  try {
    await ensureDb();
    return NextResponse.json({ ok: true, counts: await readCounts() });
  } catch (e) {
    return NextResponse.json(
      { ok: false, error: e instanceof Error ? e.message : String(e) },
      { status: 500 }
    );
  }
}
