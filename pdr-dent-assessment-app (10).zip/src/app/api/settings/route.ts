import { NextRequest, NextResponse } from "next/server";
import { getMarkupPercent, getMarkupLabel, getTzOffset, setSetting } from "@/lib/settings";
import { SETTING_KEYS, SETTING_TZ } from "@/lib/pdr";
import { getSetting } from "@/lib/settings";
import { ensureDbSafe } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

// Ключи для коэффициента расчёта площади вмятины
export const SETTING_RATE = "rate_per_cm2";
export const SETTING_MIN_DENT = "min_dent_price";

export async function GET() {
  await ensureDbSafe();
  const [markupPercent, markupLabel, tzOffset, rate, minDent] = await Promise.all([
    getMarkupPercent(),
    getMarkupLabel(),
    getTzOffset(),
    getSetting(SETTING_RATE),
    getSetting(SETTING_MIN_DENT),
  ]);
  return NextResponse.json({
    markupPercent,
    markupLabel,
    tzOffset,
    ratePerCm2: rate ? Number(rate) : 180,
    minDentPrice: minDent ? Number(minDent) : 1200,
  });
}

export async function PATCH(request: NextRequest) {
  await ensureDbSafe();
  const body = await request.json();
  if (body.markupPercent !== undefined) {
    const n = Math.max(0, Math.min(500, Number(body.markupPercent) || 0));
    await setSetting(SETTING_KEYS.markupPercent, String(n));
  }
  if (body.markupLabel !== undefined) {
    await setSetting(SETTING_KEYS.markupLabel, String(body.markupLabel).trim() || "Аренда");
  }
  if (body.tzOffset !== undefined) {
    await setSetting(SETTING_TZ, String(Number(body.tzOffset) || 0));
  }
  if (body.ratePerCm2 !== undefined) {
    await setSetting(SETTING_RATE, String(Math.max(1, Number(body.ratePerCm2) || 180)));
  }
  if (body.minDentPrice !== undefined) {
    await setSetting(SETTING_MIN_DENT, String(Math.max(0, Number(body.minDentPrice) || 0)));
  }
  const [markupPercent, markupLabel, tzOffset, rate, minDent] = await Promise.all([
    getMarkupPercent(),
    getMarkupLabel(),
    getTzOffset(),
    getSetting(SETTING_RATE),
    getSetting(SETTING_MIN_DENT),
  ]);
  return NextResponse.json({
    markupPercent,
    markupLabel,
    tzOffset,
    ratePerCm2: rate ? Number(rate) : 180,
    minDentPrice: minDent ? Number(minDent) : 1200,
  });
}
