import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { jobPhotos } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { promises as fs } from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { ensureDbSafe } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  await ensureDbSafe();
  const jobId = Number(request.nextUrl.searchParams.get("jobId"));
  if (Number.isNaN(jobId)) return NextResponse.json({ photos: [] });
  const rows = await db
    .select()
    .from(jobPhotos)
    .where(eq(jobPhotos.jobId, jobId))
    .orderBy(asc(jobPhotos.id));
  return NextResponse.json({ photos: rows });
}

export async function POST(request: NextRequest) {
  await ensureDbSafe();
  try {
    const form = await request.formData();
    const jobId = Number(form.get("jobId"));
    if (Number.isNaN(jobId)) {
      return NextResponse.json({ error: "jobId required" }, { status: 400 });
    }
    const file = form.get("file");
    if (!(file instanceof File)) {
      return NextResponse.json({ error: "file required" }, { status: 400 });
    }
    const caption = String(form.get("caption") ?? "").trim() || null;

    const buffer = Buffer.from(await file.arrayBuffer());
    const ext = (file.name.split(".").pop() ?? "jpg").toLowerCase().slice(0, 5);
    const safeExt = /^(jpg|jpeg|png|webp|gif|heic)$/.test(ext) ? ext : "jpg";
    const dir = path.join(process.cwd(), "public", "uploads", "jobs", String(jobId));
    await fs.mkdir(dir, { recursive: true });
    const filename = `${Date.now()}-${crypto.randomBytes(4).toString("hex")}.${safeExt}`;
    await fs.writeFile(path.join(dir, filename), buffer);
    const url = `/uploads/jobs/${jobId}/${filename}`;

    const [row] = await db
      .insert(jobPhotos)
      .values({ jobId, url, caption })
      .returning();

    return NextResponse.json({ photo: row }, { status: 201 });
  } catch (e) {
    console.error("photo upload", e);
    return NextResponse.json({ error: "upload failed" }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  await ensureDbSafe();
  const id = Number(request.nextUrl.searchParams.get("id"));
  if (Number.isNaN(id)) return NextResponse.json({ error: "bad id" }, { status: 400 });
  const [row] = await db.select().from(jobPhotos).where(eq(jobPhotos.id, id));
  if (row) {
    try {
      const filePath = path.join(process.cwd(), "public", row.url.replace(/^\//, ""));
      await fs.unlink(filePath);
    } catch {}
  }
  await db.delete(jobPhotos).where(eq(jobPhotos.id, id));
  return NextResponse.json({ ok: true });
}
