import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { carClasses, paintMaterials, repairMethods } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { ensureDbSafe } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

type Kind = "car_class" | "paint_material" | "repair_method";

function tableOf(kind: Kind) {
  if (kind === "car_class") return carClasses;
  if (kind === "paint_material") return paintMaterials;
  return repairMethods;
}

export async function GET() {
  await ensureDbSafe();
  const [cars, paints, methods] = await Promise.all([
    db.select().from(carClasses).orderBy(asc(carClasses.sortOrder), asc(carClasses.id)),
    db.select().from(paintMaterials).orderBy(asc(paintMaterials.sortOrder), asc(paintMaterials.id)),
    db.select().from(repairMethods).orderBy(asc(repairMethods.sortOrder), asc(repairMethods.id)),
  ]);
  return NextResponse.json({ carClasses: cars, paintMaterials: paints, repairMethods: methods });
}

export async function POST(request: NextRequest) {
  await ensureDbSafe();
  const body = await request.json();
  const kind = String(body.kind) as Kind;
  if (!["car_class", "paint_material", "repair_method"].includes(kind)) {
    return NextResponse.json({ error: "bad kind" }, { status: 400 });
  }
  const table = tableOf(kind);
  const [row] = await db
    .insert(table)
    .values({
      slug: (body.slug ? String(body.slug) : String(body.label ?? "item")).toLowerCase().replace(/[^a-z0-9а-я_-]+/gi, "_").slice(0, 40) || `item_${Date.now()}`,
      label: String(body.label ?? "Новое").trim() || "Новое",
      multiplier: Math.max(0, Number(body.multiplier ?? 1) || 1),
      sortOrder: Math.floor(Number(body.sortOrder ?? 0) || 0),
      isDefault: false,
    })
    .returning();
  return NextResponse.json({ item: row }, { status: 201 });
}

export async function PATCH(request: NextRequest) {
  await ensureDbSafe();
  const body = await request.json();
  const kind = String(body.kind) as Kind;
  const id = Number(body.id);
  if (Number.isNaN(id)) return NextResponse.json({ error: "bad id" }, { status: 400 });
  const table = tableOf(kind);
  const update: Record<string, unknown> = {};
  if (body.label !== undefined) update.label = String(body.label).trim() || "—";
  if (body.multiplier !== undefined)
    update.multiplier = Math.max(0, Number(body.multiplier) || 1);
  if (body.sortOrder !== undefined) update.sortOrder = Math.floor(Number(body.sortOrder) || 0);
  if (body.isDefault !== undefined) {
    // сбросить у остальных
    if (body.isDefault) {
      await db.update(table).set({ isDefault: false });
    }
    update.isDefault = Boolean(body.isDefault);
  }
  const [row] = await db.update(table).set(update).where(eq(table.id, id)).returning();
  if (!row) return NextResponse.json({ error: "not found" }, { status: 404 });
  return NextResponse.json({ item: row });
}

export async function DELETE(request: NextRequest) {
  await ensureDbSafe();
  const kind = request.nextUrl.searchParams.get("kind") as Kind;
  const id = Number(request.nextUrl.searchParams.get("id"));
  if (!kind || Number.isNaN(id)) return NextResponse.json({ error: "bad" }, { status: 400 });
  const table = tableOf(kind);
  await db.delete(table).where(eq(table.id, id));
  return NextResponse.json({ ok: true });
}
