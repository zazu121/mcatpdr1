import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { jobs, jobDents, jobRiItems, jobExtras } from "@/db/schema";
import { eq } from "drizzle-orm";
import { calculateDent, JOB_STATUS_IDS, wallClockNow } from "@/lib/pdr";
import { getJobFull, recalculateJobTotals } from "@/lib/jobs";
import { getTzOffset } from "@/lib/settings";
import { ensureDbSafe } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

type StatusValue = (typeof jobs.status.enumValues)[number];

function isStatus(v: unknown): v is StatusValue {
  return typeof v === "string" && JOB_STATUS_IDS.includes(v);
}

type DentIn = {
  panel?: string;
  dentType?: string;
  lengthMm?: number;
  widthMm?: number;
  depth?: string;
  quantity?: number;
  isAluminum?: boolean;
  onBodyLine?: boolean;
  gluePull?: boolean;
  hardAccess?: boolean;
  notes?: string | null;
};

type RiIn = {
  itemId?: string | number;
  label?: string;
  panel?: string | null;
  price?: number;
  quantity?: number;
  notes?: string | null;
};

type ExtraIn = {
  serviceId?: number | null;
  label?: string;
  price?: number;
  quantity?: number;
  notes?: string | null;
};

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await ensureDbSafe();
  const id = Number((await params).id);
  if (Number.isNaN(id)) return NextResponse.json({ error: "bad id" }, { status: 400 });
  const full = await getJobFull(id);
  if (!full) return NextResponse.json({ error: "not found" }, { status: 404 });
  return NextResponse.json(full);
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await ensureDbSafe();
  const id = Number((await params).id);
  if (Number.isNaN(id)) return NextResponse.json({ error: "bad id" }, { status: 400 });

  try {
    const body = await request.json();
    const update: Record<string, unknown> = { updatedAt: new Date() };

    const strFields = [
      "customerName",
      "phone",
      "vehicleMake",
      "vehicleModel",
      "vehicleColor",
      "licensePlate",
      "notes",
      "internalNotes",
      "carClassSlug",
      "paintMaterialSlug",
      "repairMethodSlug",
    ] as const;
    for (const f of strFields) {
      if (body[f] !== undefined) update[f] = body[f] ? String(body[f]).trim() : null;
    }
    if (body.vehicleYear !== undefined) update.vehicleYear = body.vehicleYear ? Number(body.vehicleYear) : null;
    if (body.discount !== undefined) update.discount = Math.max(0, Math.floor(Number(body.discount) || 0));
    if (body.paidAmount !== undefined) update.paidAmount = Math.max(0, Math.floor(Number(body.paidAmount) || 0));
    if (body.customerId !== undefined) update.customerId = body.customerId ? Number(body.customerId) : null;
    if (body.vehicleId !== undefined) update.vehicleId = body.vehicleId ? Number(body.vehicleId) : null;
    if (body.markupPercent !== undefined)
      update.markupPercent = Math.max(0, Math.min(500, Number(body.markupPercent) || 0));

    if (body.carClassMult !== undefined)
      update.carClassMult = Math.max(0, Number(body.carClassMult) || 1);
    if (body.paintMaterialMult !== undefined)
      update.paintMaterialMult = Math.max(0, Number(body.paintMaterialMult) || 1);
    if (body.repairMethodMult !== undefined)
      update.repairMethodMult = Math.max(0, Number(body.repairMethodMult) || 1);

    const dateFields = ["scheduledAt", "arrivedAt", "startedAt", "completedAt", "deliveredAt"] as const;
    for (const f of dateFields) {
      if (body[f] !== undefined) update[f] = body[f] ? new Date(body[f]) : null;
    }

    if (isStatus(body.status)) {
      update.status = body.status;
      const now = wallClockNow(await getTzOffset());
      if (body.status === "arrived" && body.arrivedAt === undefined) update.arrivedAt = now;
      if (body.status === "in_progress" && body.startedAt === undefined) update.startedAt = now;
      if (body.status === "done" && body.completedAt === undefined) update.completedAt = now;
      if (body.status === "delivered" && body.deliveredAt === undefined) update.deliveredAt = now;
    }

    // Достаём текущие множители из обновления или из БД
    const [current] = await db.select().from(jobs).where(eq(jobs.id, id));
    if (!current) return NextResponse.json({ error: "not found" }, { status: 404 });

    const carMul = (update.carClassMult as number) ?? current.carClassMult;
    const paintMul = (update.paintMaterialMult as number) ?? current.paintMaterialMult;
    const methodMul = (update.repairMethodMult as number) ?? current.repairMethodMult;

    if (Array.isArray(body.dents)) {
      await db.delete(jobDents).where(eq(jobDents.jobId, id));
      const dentRows = (body.dents as DentIn[]).map((d, idx) => {
        const calc = calculateDent({
          panel: String(d.panel ?? "hood"),
          dentType: String(d.dentType ?? "round"),
          lengthMm: Number(d.lengthMm ?? 40),
          widthMm: Number(d.widthMm ?? 40),
          depth: String(d.depth ?? "shallow"),
          quantity: Number(d.quantity ?? 1),
          isAluminum: Boolean(d.isAluminum),
          onBodyLine: Boolean(d.onBodyLine),
          gluePull: Boolean(d.gluePull),
          hardAccess: Boolean(d.hardAccess),
          extraMultipliers: [carMul, paintMul, methodMul],
        });
        return {
          jobId: id,
          panel: String(d.panel ?? "hood"),
          dentType: String(d.dentType ?? "round"),
          lengthMm: calc.lengthMm,
          widthMm: calc.widthMm,
          depth: String(d.depth ?? "shallow"),
          quantity: calc.quantity,
          isAluminum: Boolean(d.isAluminum),
          onBodyLine: Boolean(d.onBodyLine),
          gluePull: Boolean(d.gluePull),
          hardAccess: Boolean(d.hardAccess),
          unitPrice: calc.unitPrice,
          lineTotal: calc.lineTotal,
          notes: d.notes ? String(d.notes) : null,
          sortOrder: idx,
        };
      });
      if (dentRows.length) await db.insert(jobDents).values(dentRows);
    }

    if (Array.isArray(body.riItems)) {
      await db.delete(jobRiItems).where(eq(jobRiItems.jobId, id));
      const riRows = (body.riItems as RiIn[]).map((r) => {
        const price = Math.max(0, Math.floor(Number(r.price ?? 0) || 0));
        const quantity = Math.max(1, Math.floor(Number(r.quantity ?? 1) || 1));
        return {
          jobId: id,
          itemId: String(r.itemId ?? "custom"),
          label: String(r.label ?? "Разбор"),
          panel: r.panel ? String(r.panel) : null,
          price,
          quantity,
          lineTotal: price * quantity,
          notes: r.notes ? String(r.notes) : null,
        };
      });
      if (riRows.length) await db.insert(jobRiItems).values(riRows);
    }

    if (Array.isArray(body.extras)) {
      await db.delete(jobExtras).where(eq(jobExtras.jobId, id));
      const extraRows = (body.extras as ExtraIn[]).map((x) => {
        const price = Math.max(0, Math.floor(Number(x.price ?? 0) || 0));
        const quantity = Math.max(1, Math.floor(Number(x.quantity ?? 1) || 1));
        return {
          jobId: id,
          serviceId: x.serviceId ? Number(x.serviceId) : null,
          label: String(x.label ?? "Услуга"),
          price,
          quantity,
          lineTotal: price * quantity,
          notes: x.notes ? String(x.notes) : null,
        };
      });
      if (extraRows.length) await db.insert(jobExtras).values(extraRows);
    }

    const [updated] = await db.update(jobs).set(update).where(eq(jobs.id, id)).returning();
    if (!updated) return NextResponse.json({ error: "not found" }, { status: 404 });

    if (
      Array.isArray(body.dents) ||
      Array.isArray(body.riItems) ||
      Array.isArray(body.extras) ||
      body.discount !== undefined ||
      body.markupPercent !== undefined
    ) {
      await recalculateJobTotals(id);
    }

    const full = await getJobFull(id);
    return NextResponse.json(full);
  } catch (e) {
    console.error("PATCH /api/jobs/[id]", e);
    return NextResponse.json({ error: "не удалось обновить" }, { status: 500 });
  }
}

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await ensureDbSafe();
  const id = Number((await params).id);
  if (Number.isNaN(id)) return NextResponse.json({ error: "bad id" }, { status: 400 });
  const [row] = await db.delete(jobs).where(eq(jobs.id, id)).returning();
  if (!row) return NextResponse.json({ error: "not found" }, { status: 404 });
  return NextResponse.json({ ok: true });
}
