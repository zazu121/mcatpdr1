import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  jobs,
  customers,
  vehicles,
  jobDents,
  jobRiItems,
  jobExtras,
} from "@/db/schema";
import { desc, eq, and, gte, lte, or, ilike } from "drizzle-orm";
import { calculateDent, calculateJobTotals, JOB_STATUS_IDS, wallClockNow } from "@/lib/pdr";
import { getMarkupPercent, getTzOffset } from "@/lib/settings";
import { ensureDbSafe } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

type StatusValue = (typeof jobs.status.enumValues)[number];

function isStatus(v: unknown): v is StatusValue {
  return typeof v === "string" && JOB_STATUS_IDS.includes(v);
}

type DentIn = {
  panel?: string;
  dentType?: string;
  lengthMm?: number;
  widthMm?: number;
  depth?: string;
  quantity?: number;
  isAluminum?: boolean;
  onBodyLine?: boolean;
  gluePull?: boolean;
  hardAccess?: boolean;
  notes?: string | null;
};

type RiIn = {
  itemId?: string | number;
  label?: string;
  panel?: string | null;
  price?: number;
  quantity?: number;
  notes?: string | null;
};

type ExtraIn = {
  serviceId?: number | null;
  label?: string;
  price?: number;
  quantity?: number;
  notes?: string | null;
};

export async function GET(request: NextRequest) {
  await ensureDbSafe();
  const sp = request.nextUrl.searchParams;
  const status = sp.get("status");
  const q = sp.get("q")?.trim();
  const from = sp.get("from");
  const to = sp.get("to");
  const customerId = sp.get("customerId");

  try {
    const conditions = [];
    if (isStatus(status)) conditions.push(eq(jobs.status, status));
    if (customerId) conditions.push(eq(jobs.customerId, Number(customerId)));
    if (from) conditions.push(gte(jobs.scheduledAt, new Date(from)));
    if (to) conditions.push(lte(jobs.scheduledAt, new Date(to)));
    if (q) {
      const p = `%${q}%`;
      conditions.push(
        or(
          ilike(jobs.customerName, p),
          ilike(jobs.phone, p),
          ilike(jobs.vehicleMake, p),
          ilike(jobs.vehicleModel, p),
          ilike(jobs.licensePlate, p)
        )!
      );
    }

    const rows =
      conditions.length > 0
        ? await db
            .select()
            .from(jobs)
            .where(and(...conditions))
            .orderBy(desc(jobs.scheduledAt), desc(jobs.createdAt))
            .limit(300)
        : await db
            .select()
            .from(jobs)
            .orderBy(desc(jobs.scheduledAt), desc(jobs.createdAt))
            .limit(300);

    return NextResponse.json({ jobs: rows });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ jobs: [] });
  }
}

export async function POST(request: NextRequest) {
  await ensureDbSafe();
  try {
    const body = await request.json();

    let customerId: number | null = body.customerId ? Number(body.customerId) : null;
    let vehicleId: number | null = body.vehicleId ? Number(body.vehicleId) : null;

    if (!customerId && body.customerName) {
      const [c] = await db
        .insert(customers)
        .values({
          name: String(body.customerName).trim(),
          phone: body.phone ? String(body.phone).trim() : null,
        })
        .returning();
      customerId = c.id;
    }

    if (!vehicleId && body.vehicleMake) {
      const [v] = await db
        .insert(vehicles)
        .values({
          customerId,
          make: String(body.vehicleMake).trim(),
          model: body.vehicleModel ? String(body.vehicleModel).trim() : null,
          year: body.vehicleYear ? Number(body.vehicleYear) : null,
          color: body.vehicleColor ? String(body.vehicleColor).trim() : null,
          licensePlate: body.licensePlate
            ? String(body.licensePlate).trim().toUpperCase()
            : null,
        })
        .returning();
      vehicleId = v.id;
    }

    const carClassMult = Math.max(0, Number(body.carClassMult ?? 1) || 1);
    const paintMaterialMult = Math.max(0, Number(body.paintMaterialMult ?? 1) || 1);
    const repairMethodMult = Math.max(0, Number(body.repairMethodMult ?? 1) || 1);

    const dentsIn: DentIn[] = Array.isArray(body.dents) ? body.dents : [];
    const riIn: RiIn[] = Array.isArray(body.riItems) ? body.riItems : [];
    const extrasIn: ExtraIn[] = Array.isArray(body.extras) ? body.extras : [];
    const discount = Math.max(0, Math.floor(Number(body.discount ?? 0) || 0));
    const markupPercent =
      body.markupPercent !== undefined
        ? Math.max(0, Math.min(500, Number(body.markupPercent) || 0))
        : await getMarkupPercent();

    const dentRows = dentsIn.map((d, idx) => {
      const calc = calculateDent({
        panel: String(d.panel ?? "hood"),
        dentType: String(d.dentType ?? "round"),
        lengthMm: Number(d.lengthMm ?? 40),
        widthMm: Number(d.widthMm ?? 40),
        depth: String(d.depth ?? "shallow"),
        quantity: Number(d.quantity ?? 1),
        isAluminum: Boolean(d.isAluminum),
        onBodyLine: Boolean(d.onBodyLine),
        gluePull: Boolean(d.gluePull),
        hardAccess: Boolean(d.hardAccess),
        extraMultipliers: [carClassMult, paintMaterialMult, repairMethodMult],
      });
      return {
        panel: String(d.panel ?? "hood"),
        dentType: String(d.dentType ?? "round"),
        lengthMm: calc.lengthMm,
        widthMm: calc.widthMm,
        depth: String(d.depth ?? "shallow"),
        quantity: calc.quantity,
        isAluminum: Boolean(d.isAluminum),
        onBodyLine: Boolean(d.onBodyLine),
        gluePull: Boolean(d.gluePull),
        hardAccess: Boolean(d.hardAccess),
        unitPrice: calc.unitPrice,
        lineTotal: calc.lineTotal,
        notes: d.notes ? String(d.notes) : null,
        sortOrder: idx,
      };
    });

    const riRows = riIn.map((r) => {
      const price = Math.max(0, Math.floor(Number(r.price ?? 0) || 0));
      const quantity = Math.max(1, Math.floor(Number(r.quantity ?? 1) || 1));
      return {
        itemId: String(r.itemId ?? "custom"),
        label: String(r.label ?? "Разбор"),
        panel: r.panel ? String(r.panel) : null,
        price,
        quantity,
        lineTotal: price * quantity,
        notes: r.notes ? String(r.notes) : null,
      };
    });

    const extraRows = extrasIn.map((x) => {
      const price = Math.max(0, Math.floor(Number(x.price ?? 0) || 0));
      const quantity = Math.max(1, Math.floor(Number(x.quantity ?? 1) || 1));
      return {
        serviceId: x.serviceId ? Number(x.serviceId) : null,
        label: String(x.label ?? "Услуга"),
        price,
        quantity,
        lineTotal: price * quantity,
        notes: x.notes ? String(x.notes) : null,
      };
    });

    const totals = calculateJobTotals(dentRows, riRows, extraRows, discount, markupPercent);

    const statusRaw = String(body.status ?? "scheduled");
    const status = isStatus(statusRaw) ? statusRaw : "scheduled";
    const scheduledAt = body.scheduledAt ? new Date(body.scheduledAt) : wallClockNow(await getTzOffset());

    const [job] = await db
      .insert(jobs)
      .values({
        customerId,
        vehicleId,
        customerName: body.customerName ? String(body.customerName).trim() : null,
        phone: body.phone ? String(body.phone).trim() : null,
        vehicleMake: body.vehicleMake ? String(body.vehicleMake).trim() : "",
        vehicleModel: body.vehicleModel ? String(body.vehicleModel).trim() : null,
        vehicleYear: body.vehicleYear ? Number(body.vehicleYear) : null,
        vehicleColor: body.vehicleColor ? String(body.vehicleColor).trim() : null,
        licensePlate: body.licensePlate
          ? String(body.licensePlate).trim().toUpperCase()
          : null,
        carClassSlug: body.carClassSlug ? String(body.carClassSlug) : null,
        carClassMult,
        paintMaterialSlug: body.paintMaterialSlug ? String(body.paintMaterialSlug) : null,
        paintMaterialMult,
        repairMethodSlug: body.repairMethodSlug ? String(body.repairMethodSlug) : null,
        repairMethodMult,
        scheduledAt,
        status,
        notes: body.notes ? String(body.notes).trim() : null,
        internalNotes: body.internalNotes ? String(body.internalNotes).trim() : null,
        dentsTotal: totals.dentsTotal,
        riTotal: totals.riTotal,
        extrasTotal: totals.extrasTotal,
        discount: totals.discount,
        subtotal: totals.subtotal,
        markupPercent: totals.markupPercent,
        markupAmount: totals.markupAmount,
        totalCost: totals.totalCost,
        earnings: totals.earnings,
        paidAmount: Math.max(0, Math.floor(Number(body.paidAmount ?? 0) || 0)),
      })
      .returning();

    if (dentRows.length) {
      await db.insert(jobDents).values(dentRows.map((d) => ({ ...d, jobId: job.id })));
    }
    if (riRows.length) {
      await db.insert(jobRiItems).values(riRows.map((r) => ({ ...r, jobId: job.id })));
    }
    if (extraRows.length) {
      await db.insert(jobExtras).values(extraRows.map((x) => ({ ...x, jobId: job.id })));
    }

    return NextResponse.json({ job }, { status: 201 });
  } catch (e) {
    console.error("POST /api/jobs", e);
    return NextResponse.json({ error: "Не удалось создать запись" }, { status: 500 });
  }
}
