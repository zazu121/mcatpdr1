import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { customers, vehicles, jobs } from "@/db/schema";
import { desc, ilike, or, sql, eq } from "drizzle-orm";
import { ensureDbSafe } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  await ensureDbSafe();
  const q = request.nextUrl.searchParams.get("q")?.trim();

  try {
    let baseRows;
    if (q) {
      const pattern = `%${q}%`;
      baseRows = await db
        .select()
        .from(customers)
        .where(or(ilike(customers.name, pattern), ilike(customers.phone, pattern), ilike(customers.email, pattern)))
        .orderBy(desc(customers.createdAt))
        .limit(50);
    } else {
      baseRows = await db.select().from(customers).orderBy(desc(customers.createdAt)).limit(200);
    }

    const vehAgg = await db
      .select({ customerId: vehicles.customerId, cnt: sql<number>`count(*)::int` })
      .from(vehicles)
      .groupBy(vehicles.customerId);
    const jobAgg = await db
      .select({
        customerId: jobs.customerId,
        cnt: sql<number>`count(*)::int`,
        spent: sql<number>`coalesce(sum(${jobs.totalCost}),0)::int`,
      })
      .from(jobs)
      .groupBy(jobs.customerId);

    const vMap = new Map(vehAgg.map((v) => [v.customerId, v.cnt]));
    const jMap = new Map(jobAgg.map((j) => [j.customerId, { cnt: j.cnt, spent: j.spent }]));

    const rows = baseRows.map((c) => ({
      id: c.id,
      name: c.name,
      phone: c.phone,
      email: c.email,
      notes: c.notes,
      createdAt: c.createdAt,
      vehicleCount: vMap.get(c.id) ?? 0,
      jobCount: jMap.get(c.id)?.cnt ?? 0,
      totalSpent: jMap.get(c.id)?.spent ?? 0,
    }));

    return NextResponse.json({ customers: rows });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ customers: [] });
  }
}
void eq;

export async function POST(request: NextRequest) {
  await ensureDbSafe();
  try {
    const body = await request.json();
    const name = String(body.name ?? "").trim();
    if (!name) {
      return NextResponse.json({ error: "Укажите имя клиента" }, { status: 400 });
    }
    const [row] = await db
      .insert(customers)
      .values({
        name,
        phone: body.phone ? String(body.phone).trim() : null,
        email: body.email ? String(body.email).trim() : null,
        notes: body.notes ? String(body.notes).trim() : null,
      })
      .returning();
    return NextResponse.json({ customer: row }, { status: 201 });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Не удалось создать клиента" }, { status: 500 });
  }
}
