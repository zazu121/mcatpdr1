import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { customers, vehicles, jobs } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { ensureDbSafe } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await ensureDbSafe();
  const id = Number((await params).id);
  if (Number.isNaN(id)) {
    return NextResponse.json({ error: "Некорректный ID" }, { status: 400 });
  }
  const [customer] = await db.select().from(customers).where(eq(customers.id, id));
  if (!customer) {
    return NextResponse.json({ error: "Клиент не найден" }, { status: 404 });
  }
  const vehicleRows = await db
    .select()
    .from(vehicles)
    .where(eq(vehicles.customerId, id))
    .orderBy(desc(vehicles.createdAt));
  const jobRows = await db
    .select()
    .from(jobs)
    .where(eq(jobs.customerId, id))
    .orderBy(desc(jobs.createdAt))
    .limit(50);
  return NextResponse.json({ customer, vehicles: vehicleRows, jobs: jobRows });
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await ensureDbSafe();
  const id = Number((await params).id);
  if (Number.isNaN(id)) {
    return NextResponse.json({ error: "Некорректный ID" }, { status: 400 });
  }
  const body = await request.json();
  const update: Record<string, unknown> = {};
  if (body.name !== undefined) update.name = String(body.name).trim();
  if (body.phone !== undefined) update.phone = body.phone ? String(body.phone).trim() : null;
  if (body.email !== undefined) update.email = body.email ? String(body.email).trim() : null;
  if (body.notes !== undefined) update.notes = body.notes ? String(body.notes).trim() : null;

  const [row] = await db.update(customers).set(update).where(eq(customers.id, id)).returning();
  if (!row) return NextResponse.json({ error: "Клиент не найден" }, { status: 404 });
  return NextResponse.json({ customer: row });
}

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await ensureDbSafe();
  const id = Number((await params).id);
  if (Number.isNaN(id)) {
    return NextResponse.json({ error: "Некорректный ID" }, { status: 400 });
  }
  const [row] = await db.delete(customers).where(eq(customers.id, id)).returning();
  if (!row) return NextResponse.json({ error: "Клиент не найден" }, { status: 404 });
  return NextResponse.json({ ok: true });
}
