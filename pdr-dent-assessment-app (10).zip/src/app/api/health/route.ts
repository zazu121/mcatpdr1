import { db } from "@/db";
import { sql } from "drizzle-orm";
import { ensureDbSafe } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await db.execute(sql`select 1`);
  } catch (e) {
    // БД недоступна — показываем понятную подсказку
    return Response.json(
      {
        ok: false,
        db: "unreachable",
        hint:
          "Проверьте переменную окружения DATABASE_URL на хостинге. " +
          "Формат: postgresql://ПОЛЬЗОВАТЕЛЬ:ПАРОЛЬ@ХОСТ:5432/ИМЯ_БАЗЫ",
        error: e instanceof Error ? e.message : String(e),
      },
      { status: 500 }
    );
  }

  const ready = await ensureDbSafe();

  let counts: Record<string, number> = {};
  try {
    const r = await db.execute(sql`
      SELECT
        (SELECT count(*)::int FROM car_classes) AS car_classes,
        (SELECT count(*)::int FROM paint_materials) AS paint_materials,
        (SELECT count(*)::int FROM repair_methods) AS repair_methods,
        (SELECT count(*)::int FROM ri_catalog) AS ri_catalog,
        (SELECT count(*)::int FROM extra_services) AS extra_services,
        (SELECT count(*)::int FROM calc_options) AS calc_options,
        (SELECT count(*)::int FROM jobs) AS jobs,
        (SELECT count(*)::int FROM customers) AS customers
    `);
    counts = (r.rows?.[0] as Record<string, number>) ?? {};
  } catch {
    /* ignore */
  }

  return Response.json({ ok: true, db: "connected", initialized: ready, counts });
}
