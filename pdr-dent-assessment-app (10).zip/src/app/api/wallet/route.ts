import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { jobs, walletEntries } from "@/db/schema";
import { and, desc, gte, lte, sql } from "drizzle-orm";
import { ensureDbSafe } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  await ensureDbSafe();
  const sp = request.nextUrl.searchParams;
  const from = sp.get("from") ? new Date(sp.get("from")!) : null;
  const to = sp.get("to") ? new Date(sp.get("to")!) : null;

  const conditions = [
    sql`${jobs.status} in ('done','delivered')`,
    sql`${jobs.totalCost} > 0`,
  ];
  if (from) conditions.push(gte(jobs.completedAt, from));
  if (to) conditions.push(lte(jobs.completedAt, to));

  const rows = await db
    .select()
    .from(jobs)
    .where(and(...conditions))
    .orderBy(desc(jobs.completedAt), desc(jobs.updatedAt))
    .limit(500);

  const manual = await db
    .select()
    .from(walletEntries)
    .orderBy(desc(walletEntries.createdAt))
    .limit(200);

  const totals = rows.reduce(
    (acc, j) => {
      acc.gross += j.totalCost;
      acc.earnings += j.earnings;
      acc.rent += j.markupAmount;
      acc.paid += j.paidAmount;
      return acc;
    },
    { gross: 0, earnings: 0, rent: 0, paid: 0 }
  );

  const manualIncome = manual.filter((m) => m.kind === "income").reduce((s, m) => s + m.amount, 0);
  const manualExpense = manual.filter((m) => m.kind === "expense").reduce((s, m) => s + m.amount, 0);

  return NextResponse.json({
    jobs: rows,
    manual,
    totals: {
      ...totals,
      manualIncome,
      manualExpense,
      netEarnings: totals.earnings + manualIncome - manualExpense,
    },
  });
}

export async function POST(request: NextRequest) {
  await ensureDbSafe();
  const body = await request.json();
  const [row] = await db
    .insert(walletEntries)
    .values({
      kind: body.kind === "expense" ? "expense" : "income",
      amount: Math.max(0, Math.floor(Number(body.amount ?? 0) || 0)),
      category: body.category ? String(body.category) : null,
      description: body.description ? String(body.description) : null,
    })
    .returning();
  return NextResponse.json({ entry: row }, { status: 201 });
}

export async function DELETE(request: NextRequest) {
  await ensureDbSafe();
  const id = Number(request.nextUrl.searchParams.get("id"));
  if (Number.isNaN(id)) return NextResponse.json({ error: "bad id" }, { status: 400 });
  await db.delete(walletEntries).where(sql`${walletEntries.id} = ${id}`);
  return NextResponse.json({ ok: true });
}
