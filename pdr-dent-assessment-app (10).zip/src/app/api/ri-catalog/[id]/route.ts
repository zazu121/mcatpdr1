import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { riCatalog } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ensureDbSafe } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await ensureDbSafe();
  const id = Number((await params).id);
  if (Number.isNaN(id)) return NextResponse.json({ error: "bad id" }, { status: 400 });
  const body = await request.json();
  const update: Record<string, unknown> = {};
  if (body.label !== undefined) update.label = String(body.label).trim() || "Разбор";
  if (body.panel !== undefined) update.panel = body.panel ? String(body.panel) : null;
  if (body.groupName !== undefined) update.groupName = String(body.groupName).trim() || "Общее";
  if (body.price !== undefined) update.price = Math.max(0, Math.floor(Number(body.price) || 0));
  if (body.sortOrder !== undefined) update.sortOrder = Math.floor(Number(body.sortOrder) || 0);
  if (body.isActive !== undefined) update.isActive = Boolean(body.isActive);
  const [row] = await db.update(riCatalog).set(update).where(eq(riCatalog.id, id)).returning();
  if (!row) return NextResponse.json({ error: "not found" }, { status: 404 });
  return NextResponse.json({ item: row });
}

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await ensureDbSafe();
  const id = Number((await params).id);
  if (Number.isNaN(id)) return NextResponse.json({ error: "bad id" }, { status: 400 });
  await db.delete(riCatalog).where(eq(riCatalog.id, id));
  return NextResponse.json({ ok: true });
}
