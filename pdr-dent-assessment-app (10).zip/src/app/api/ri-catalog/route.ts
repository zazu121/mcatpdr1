import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { riCatalog } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { ensureDbSafe } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureDbSafe();
  const rows = await db
    .select()
    .from(riCatalog)
    .where(eq(riCatalog.isActive, true))
    .orderBy(asc(riCatalog.sortOrder), asc(riCatalog.id));
  return NextResponse.json({ items: rows });
}

export async function POST(request: NextRequest) {
  await ensureDbSafe();
  const body = await request.json();
  const [row] = await db
    .insert(riCatalog)
    .values({
      label: String(body.label ?? "Разбор").trim() || "Разбор",
      panel: body.panel ? String(body.panel) : null,
      groupName: body.groupName ? String(body.groupName).trim() : "Общее",
      price: Math.max(0, Math.floor(Number(body.price ?? 0) || 0)),
      sortOrder: Math.floor(Number(body.sortOrder ?? 0) || 0),
    })
    .returning();
  return NextResponse.json({ item: row }, { status: 201 });
}
