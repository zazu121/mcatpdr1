import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { calcOptions } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { ensureDbSafe } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

const KINDS = ["panel", "size_preset", "dent_type", "depth", "surcharge"];

export async function GET(request: NextRequest) {
  await ensureDbSafe();
  const kind = request.nextUrl.searchParams.get("kind");
  const q = kind
    ? db.select().from(calcOptions).where(eq(calcOptions.kind, kind)).orderBy(asc(calcOptions.sortOrder), asc(calcOptions.id))
    : db.select().from(calcOptions).orderBy(asc(calcOptions.kind), asc(calcOptions.sortOrder));
  const rows = await q;
  return NextResponse.json({ options: rows });
}

export async function POST(request: NextRequest) {
  await ensureDbSafe();
  const body = await request.json();
  const kind = String(body.kind);
  if (!KINDS.includes(kind)) return NextResponse.json({ error: "bad kind" }, { status: 400 });
  const label = String(body.label ?? "Новое").trim() || "Новое";
  const slug = (body.slug ? String(body.slug) : label)
    .toLowerCase()
    .replace(/[^a-z0-9а-я_-]+/gi, "_")
    .slice(0, 40) || `opt_${Date.now()}`;
  const [row] = await db
    .insert(calcOptions)
    .values({
      kind,
      slug,
      label,
      emoji: body.emoji ? String(body.emoji) : null,
      multiplier: body.multiplier !== undefined ? Math.max(0, Number(body.multiplier) || 0) : 1,
      lengthMm: body.lengthMm !== undefined ? Math.max(1, Number(body.lengthMm) || 1) : null,
      widthMm: body.widthMm !== undefined ? Math.max(1, Number(body.widthMm) || 1) : null,
      groupName: body.groupName ? String(body.groupName) : null,
      sortOrder: Math.floor(Number(body.sortOrder ?? 0) || 0),
    })
    .returning();
  return NextResponse.json({ option: row }, { status: 201 });
}

export async function PATCH(request: NextRequest) {
  await ensureDbSafe();
  const body = await request.json();
  const id = Number(body.id);
  if (Number.isNaN(id)) return NextResponse.json({ error: "bad id" }, { status: 400 });
  const update: Record<string, unknown> = {};
  if (body.label !== undefined) update.label = String(body.label).trim() || "—";
  if (body.emoji !== undefined) update.emoji = body.emoji ? String(body.emoji) : null;
  if (body.multiplier !== undefined) update.multiplier = Math.max(0, Number(body.multiplier) || 0);
  if (body.lengthMm !== undefined) update.lengthMm = Math.max(1, Number(body.lengthMm) || 1);
  if (body.widthMm !== undefined) update.widthMm = Math.max(1, Number(body.widthMm) || 1);
  if (body.groupName !== undefined) update.groupName = body.groupName ? String(body.groupName) : null;
  if (body.sortOrder !== undefined) update.sortOrder = Math.floor(Number(body.sortOrder) || 0);
  if (body.isActive !== undefined) update.isActive = Boolean(body.isActive);
  const [row] = await db.update(calcOptions).set(update).where(eq(calcOptions.id, id)).returning();
  if (!row) return NextResponse.json({ error: "not found" }, { status: 404 });
  return NextResponse.json({ option: row });
}

export async function DELETE(request: NextRequest) {
  await ensureDbSafe();
  const id = Number(request.nextUrl.searchParams.get("id"));
  if (Number.isNaN(id)) return NextResponse.json({ error: "bad id" }, { status: 400 });
  await db.delete(calcOptions).where(eq(calcOptions.id, id));
  return NextResponse.json({ ok: true });
}
