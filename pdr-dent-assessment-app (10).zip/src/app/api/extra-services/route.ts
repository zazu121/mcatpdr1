import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { extraServices } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { ensureDbSafe } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureDbSafe();
  const rows = await db
    .select()
    .from(extraServices)
    .where(eq(extraServices.isActive, true))
    .orderBy(asc(extraServices.sortOrder), asc(extraServices.id));
  return NextResponse.json({ items: rows });
}

export async function POST(request: NextRequest) {
  await ensureDbSafe();
  const body = await request.json();
  const [row] = await db
    .insert(extraServices)
    .values({
      label: String(body.label ?? "Услуга").trim() || "Услуга",
      description: body.description ? String(body.description) : null,
      price: Math.max(0, Math.floor(Number(body.price ?? 0) || 0)),
      sortOrder: Math.floor(Number(body.sortOrder ?? 0) || 0),
    })
    .returning();
  return NextResponse.json({ item: row }, { status: 201 });
}
