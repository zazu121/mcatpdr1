import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { customers, vehicles, jobs, vehiclePhotos } from "@/db/schema";
import { desc, eq, or, and, ne, inArray } from "drizzle-orm";
import { formatDate, formatDateTime, formatPrice } from "@/lib/pdr";
import { StatusBadge, EmptyState } from "@/components/ui";
import { CustomerEditForm } from "@/components/CustomerEditForm";
import { VehicleAddForm } from "@/components/VehicleAddForm";
import { VehiclePhotos } from "@/components/VehiclePhotos";
import { ensureDbSafe } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

type Params = Promise<{ id: string }>;

export default async function CustomerDetailPage({ params }: { params: Params }) {
  await ensureDbSafe();
  const id = Number((await params).id);
  if (Number.isNaN(id)) notFound();

  const [customer] = await db.select().from(customers).where(eq(customers.id, id));
  if (!customer) notFound();

  const vehicleRows = await db
    .select()
    .from(vehicles)
    .where(eq(vehicles.customerId, id))
    .orderBy(desc(vehicles.createdAt));

  // Работы: напрямую по customerId + найденные по телефону/госномеру (если не привязаны)
  const plates = vehicleRows.map((v) => v.licensePlate).filter((p): p is string => !!p);
  const matchConds = [] as ReturnType<typeof or>[];
  const orParts = [eq(jobs.customerId, id)];
  if (customer.phone) orParts.push(eq(jobs.phone, customer.phone));
  if (plates.length) orParts.push(inArray(jobs.licensePlate, plates));
  void matchConds; void and; void ne;

  const jobRows = await db
    .select()
    .from(jobs)
    .where(or(...orParts))
    .orderBy(desc(jobs.createdAt))
    .limit(100);

  // Фото автомобилей клиента
  const vIds = vehicleRows.map((v) => v.id);
  const vPhotos = vIds.length
    ? await db.select().from(vehiclePhotos).where(inArray(vehiclePhotos.vehicleId, vIds))
    : [];
  const photosByVehicle = new Map<number, typeof vPhotos>();
  for (const p of vPhotos) {
    const list = photosByVehicle.get(p.vehicleId) ?? [];
    list.push(p);
    photosByVehicle.set(p.vehicleId, list);
  }

  const spent = jobRows.reduce((s, j) => s + j.totalCost, 0);
  const paid = jobRows.reduce((s, j) => s + j.paidAmount, 0);

  return (
    <div className="space-y-5">
      <Link href="/customers" className="text-sm font-medium text-zinc-400 hover:text-zinc-200">
        ← К клиентам
      </Link>

      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="grid h-14 w-14 place-items-center rounded-2xl bg-zinc-100 text-xl font-bold text-white">
            {customer.name.slice(0, 1).toUpperCase()}
          </span>
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-zinc-100">{customer.name}</h1>
            <p className="text-sm text-zinc-400">
              {customer.phone ?? "без телефона"}
              {customer.email ? ` · ${customer.email}` : ""}
              {" · с "}
              {formatDate(customer.createdAt)}
            </p>
          </div>
        </div>
        <Link
          href={`/journal/new?customerId=${customer.id}&vehicleId=${vehicleRows[0]?.id ?? ""}`}
          className="rounded-xl bg-red-600 px-4 py-2.5 text-sm font-semibold text-white"
        >
          + Запись для клиента
        </Link>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Mini label="Авто" value={String(vehicleRows.length)} />
        <Mini label="Работ" value={String(jobRows.length)} />
        <Mini label="Сумма" value={formatPrice(spent)} />
        <Mini label="Оплачено" value={formatPrice(paid)} />
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <CustomerEditForm customer={customer} />
        <VehicleAddForm customerId={customer.id} />
      </div>

      <section className="rounded-2xl border border-zinc-800 bg-zinc-900 shadow-sm">
        <div className="border-b border-zinc-800/50 px-5 py-3.5">
          <h2 className="text-base font-semibold text-zinc-100">Автомобили</h2>
        </div>
        {vehicleRows.length === 0 ? (
          <div className="p-5">
            <EmptyState icon="🚗" title="Авто не добавлены" text="Добавьте машину клиента формой выше." />
          </div>
        ) : (
          <ul className="divide-y divide-slate-100">
            {vehicleRows.map((v) => (
              <li key={v.id} className="px-5 py-3.5">
                <div className="flex items-center gap-3">
                  <span className="grid h-10 w-10 place-items-center rounded-xl bg-red-950/20 text-lg">🚗</span>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold text-zinc-100">
                      {v.make} {v.model ?? ""} {v.year ? `· ${v.year}` : ""}
                    </p>
                    <p className="text-xs text-zinc-400">
                      {[v.color, v.licensePlate, v.vin].filter(Boolean).join(" · ") || "без доп. данных"}
                    </p>
                  </div>
                </div>
                <VehiclePhotos vehicleId={v.id} initial={photosByVehicle.get(v.id) ?? []} />
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="rounded-2xl border border-zinc-800 bg-zinc-900 shadow-sm">
        <div className="flex items-center justify-between border-b border-zinc-800/50 px-5 py-3.5">
          <h2 className="text-base font-semibold text-zinc-100">История работ</h2>
        </div>
        {jobRows.length === 0 ? (
          <div className="p-5">
            <EmptyState icon="📒" title="Работ ещё не было" text="Создайте запись в журнале." actionHref="/journal/new" actionLabel="Новая запись" />
          </div>
        ) : (
          <ul className="divide-y divide-slate-100">
            {jobRows.map((j) => (
              <li key={j.id}>
                <Link href={`/journal/${j.id}`} className="flex items-center gap-3 px-5 py-3.5 hover:bg-zinc-950">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-zinc-100">
                      {j.vehicleMake} {j.vehicleModel ?? ""} · #{j.id}
                    </p>
                    <p className="text-xs text-zinc-400">{formatDateTime(j.scheduledAt ?? j.createdAt)}</p>
                  </div>
                  <StatusBadge status={j.status} />
                  <span className="w-24 text-right text-sm font-bold text-zinc-100">
                    {formatPrice(j.totalCost)}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function Mini({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-zinc-800 bg-zinc-900 p-4 shadow-sm">
      <p className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">{label}</p>
      <p className="mt-1 text-lg font-bold text-zinc-100">{value}</p>
    </div>
  );
}
