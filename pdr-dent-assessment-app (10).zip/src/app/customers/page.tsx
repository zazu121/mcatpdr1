import Link from "next/link";
import { db } from "@/db";
import { customers, vehicles, jobs } from "@/db/schema";
import { desc, or, ilike, eq, sql } from "drizzle-orm";
import { formatDate, formatPrice } from "@/lib/pdr";
import { EmptyState } from "@/components/ui";
import { CustomerCreateForm } from "@/components/CustomerCreateForm";
import { ensureDbSafe } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

type SP = Promise<{ q?: string }>;

export default async function CustomersPage({ searchParams }: { searchParams: SP }) {
  await ensureDbSafe();
  const { q } = await searchParams;
  const query = q?.trim() ?? "";

  let rows: {
    id: number;
    name: string;
    phone: string | null;
    email: string | null;
    notes: string | null;
    createdAt: Date;
    vehicleCount: number;
    jobCount: number;
    totalSpent: number;
  }[] = [];

  try {
    // Базовые данные клиентов
    let baseRows;
    if (query) {
      const p = `%${query}%`;
      baseRows = await db
        .select()
        .from(customers)
        .where(or(ilike(customers.name, p), ilike(customers.phone, p), ilike(customers.email, p)))
        .orderBy(desc(customers.createdAt))
        .limit(200);
    } else {
      baseRows = await db.select().from(customers).orderBy(desc(customers.createdAt)).limit(200);
    }

    // Агрегаты по авто и работам — отдельными запросами с groupBy (надёжно)
    const vehAgg = await db
      .select({ customerId: vehicles.customerId, cnt: sql<number>`count(*)::int` })
      .from(vehicles)
      .groupBy(vehicles.customerId);
    const jobAgg = await db
      .select({
        customerId: jobs.customerId,
        cnt: sql<number>`count(*)::int`,
        spent: sql<number>`coalesce(sum(${jobs.totalCost}),0)::int`,
      })
      .from(jobs)
      .groupBy(jobs.customerId);

    const vMap = new Map(vehAgg.map((v) => [v.customerId, v.cnt]));
    const jMap = new Map(jobAgg.map((j) => [j.customerId, { cnt: j.cnt, spent: j.spent }]));

    rows = baseRows.map((c) => ({
      id: c.id,
      name: c.name,
      phone: c.phone,
      email: c.email,
      notes: c.notes,
      createdAt: c.createdAt,
      vehicleCount: vMap.get(c.id) ?? 0,
      jobCount: jMap.get(c.id)?.cnt ?? 0,
      totalSpent: jMap.get(c.id)?.spent ?? 0,
    }));
  } catch (e) {
    console.error(e);
  }
  void eq;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-zinc-100">Клиенты</h1>
          <p className="mt-1 text-sm text-zinc-400">{rows.length} в базе · авто и история работ</p>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-[320px_1fr]">
        <CustomerCreateForm />

        <div className="space-y-4">
          <form action="/customers" method="get" className="flex gap-2">
            <input
              name="q"
              defaultValue={query}
              placeholder="Поиск по имени или телефону…"
              className="w-full rounded-xl border border-zinc-800 bg-zinc-900 px-3.5 py-2.5 text-sm outline-none focus:border-red-500 focus:ring-2 focus:ring-red-500/30"
            />
            <button type="submit" className="rounded-xl bg-zinc-100 px-4 py-2.5 text-sm font-semibold text-zinc-950">
              Найти
            </button>
          </form>

          {rows.length === 0 ? (
            <EmptyState
              icon="👤"
              title="Клиентов пока нет"
              text="Добавьте клиента справа или создайте запись в журнале — клиент создастся автоматически."
            />
          ) : (
            <div className="overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900 shadow-sm">
              <ul className="divide-y divide-slate-100">
                {rows.map((c) => (
                  <li key={c.id}>
                    <Link
                      href={`/customers/${c.id}`}
                      className="flex items-center gap-3 px-5 py-3.5 hover:bg-zinc-950"
                    >
                      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-zinc-800 text-sm font-bold text-zinc-400">
                        {c.name.slice(0, 1).toUpperCase()}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold text-zinc-100">{c.name}</p>
                        <p className="truncate text-xs text-zinc-400">
                          {c.phone ?? "без телефона"}
                          {c.email ? ` · ${c.email}` : ""}
                          {" · с "}
                          {formatDate(c.createdAt)}
                        </p>
                      </div>
                      <div className="hidden text-right text-xs text-zinc-400 sm:block">
                        <p>{c.vehicleCount} авто · {c.jobCount} работ</p>
                        <p className="font-semibold text-zinc-200">{formatPrice(c.totalSpent)}</p>
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
