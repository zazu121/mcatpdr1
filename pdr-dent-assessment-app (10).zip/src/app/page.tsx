import Link from "next/link";
import { db } from "@/db";
import { jobs, customers } from "@/db/schema";
import { desc, count, sum, and, gte, sql } from "drizzle-orm";
import {
  formatPrice,
  formatDateTime,
  formatTime,
  JOB_STATUS,
  panelEmoji,
} from "@/lib/pdr";
import { getMarkupLabel } from "@/lib/settings";
import { StatusBadge, EmptyState } from "@/components/ui";
import { ensureDbSafe } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  await ensureDbSafe();
  let totalJobs = 0;
  let revenue = 0;
  let earnings = 0;
  let rent = 0;
  let advancesReceived = 0;
  let customersCount = 0;
  let todayJobs: (typeof jobs.$inferSelect)[] = [];
  let activeJobs: (typeof jobs.$inferSelect)[] = [];
  let recentJobs: (typeof jobs.$inferSelect)[] = [];
  const markupLabel = await getMarkupLabel();

  try {
    const [totals] = await db.select({ total: count(), revenue: sum(jobs.totalCost) }).from(jobs);
    totalJobs = totals?.total ?? 0;
    revenue = Number(totals?.revenue ?? 0);

    // Заработок = моя часть только по завершённым/выданным работам
    const [completed] = await db
      .select({ earnings: sum(jobs.earnings), rent: sum(jobs.markupAmount) })
      .from(jobs)
      .where(sql`${jobs.status} in ('done','delivered')`);
    earnings = Number(completed?.earnings ?? 0);
    rent = Number(completed?.rent ?? 0);

    // Полученные авансы по незавершённым работам
    const [advances] = await db
      .select({ paid: sum(jobs.paidAmount) })
      .from(jobs)
      .where(sql`${jobs.status} not in ('done','delivered','cancelled')`);
    advancesReceived = Number(advances?.paid ?? 0);

    const [c] = await db.select({ total: count() }).from(customers);
    customersCount = c?.total ?? 0;

    const start = new Date();
    start.setHours(0, 0, 0, 0);
    const end = new Date();
    end.setHours(23, 59, 59, 999);

    todayJobs = await db
      .select()
      .from(jobs)
      .where(
        and(
          gte(jobs.scheduledAt, start),
          sql`${jobs.scheduledAt} <= ${end}`,
          sql`${jobs.status} not in ('cancelled', 'delivered')`
        )
      )
      .orderBy(jobs.scheduledAt)
      .limit(20);

    activeJobs = await db
      .select()
      .from(jobs)
      .where(
        sql`${jobs.status} in ('scheduled', 'arrived', 'in_progress', 'done')`
      )
      .orderBy(desc(jobs.updatedAt))
      .limit(8);

    recentJobs = await db
      .select()
      .from(jobs)
      .orderBy(desc(jobs.createdAt))
      .limit(6);
  } catch (e) {
    console.error("dashboard", e);
  }

  const avg = totalJobs > 0 ? Math.round(revenue / totalJobs) : 0;
  const inWork = activeJobs.filter((j) => j.status === "in_progress").length;
  const waiting = activeJobs.filter((j) => j.status === "arrived" || j.status === "scheduled").length;

  return (
    <div className="space-y-6">
      <section className="theme-hero relative overflow-hidden rounded-3xl bg-gradient-to-br from-zinc-900 via-zinc-950 to-red-950/30 p-6 text-white shadow-2xl shadow-black/40 sm:p-8">
        <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-red-600/20 blur-3xl" />
        <div className="relative">
          <p className="text-xs font-medium uppercase tracking-wider text-red-400">Рабочий стол мастера ПДР</p>
          <h1 className="mt-2 text-2xl font-bold tracking-tight sm:text-3xl">MCAT PDR</h1>
          <p className="mt-2 max-w-2xl text-sm text-zinc-300 sm:text-base">
            Журнал машин, запись клиентов, калькулятор с размерами вмятин и разбором элементов — всё под рукой.
          </p>
          <div className="mt-5 flex flex-wrap gap-2">
            <Link href="/journal/new" className="rounded-xl bg-red-600 px-4 py-2.5 text-sm font-semibold text-white shadow-lg shadow-red-600/30 hover:bg-red-500">
              + Новая запись
            </Link>
            <Link href="/calculator" className="rounded-xl bg-white/10 px-4 py-2.5 text-sm font-semibold text-white ring-1 ring-white/15 hover:bg-white/15">
              Калькулятор
            </Link>
            <Link href="/journal" className="rounded-xl bg-white/10 px-4 py-2.5 text-sm font-semibold text-white ring-1 ring-white/15 hover:bg-white/15">
              Журнал
            </Link>
          </div>
        </div>
      </section>

      <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Мне (заработок)" value={formatPrice(earnings)} hint="выданные / готовые" tone="ok" />
        <Stat label="Авансы получены" value={formatPrice(advancesReceived)} hint="по активным" tone="ok" />
        <Stat label={markupLabel} value={formatPrice(rent)} hint="надбавка (готовые)" tone="warn" />
        <Stat label="Всего с клиентов" value={formatPrice(revenue)} hint={`ср. чек ${formatPrice(avg)}`} />
      </section>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="rounded-2xl border border-zinc-800 bg-zinc-900 shadow-sm">
          <div className="flex items-center justify-between border-b border-zinc-800/50 px-5 py-3.5">
            <h2 className="text-base font-semibold text-zinc-100">На сегодня</h2>
            <Link href="/journal" className="text-sm font-medium text-red-500">Журнал →</Link>
          </div>
          {todayJobs.length === 0 ? (
            <div className="p-5">
              <EmptyState icon="📅" title="На сегодня пусто" text="Добавьте запись — укажите время приезда клиента." actionHref="/journal/new" actionLabel="Записать клиента" />
            </div>
          ) : (
            <ul className="divide-y divide-slate-100">
              {todayJobs.map((j) => (
                <li key={j.id}>
                  <Link href={`/journal/${j.id}`} className="flex items-center gap-3 px-5 py-3 hover:bg-zinc-950">
                    <div className="w-12 shrink-0 text-center">
                      <p className="text-sm font-bold text-zinc-100">{formatTime(j.scheduledAt)}</p>
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold text-zinc-100">
                        {j.vehicleMake} {j.vehicleModel ?? ""}
                      </p>
                      <p className="truncate text-xs text-zinc-400">
                        {j.customerName ?? "Без имени"}
                        {j.phone ? ` · ${j.phone}` : ""}
                        {j.licensePlate ? ` · ${j.licensePlate}` : ""}
                      </p>
                    </div>
                    <StatusBadge status={j.status} />
                    <span className="hidden w-20 shrink-0 text-right text-sm font-bold text-zinc-100 sm:block">
                      {formatPrice(j.totalCost)}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="rounded-2xl border border-zinc-800 bg-zinc-900 shadow-sm">
          <div className="flex items-center justify-between border-b border-zinc-800/50 px-5 py-3.5">
            <h2 className="text-base font-semibold text-zinc-100">Активные</h2>
            <div className="flex gap-1">
              {(["scheduled", "arrived", "in_progress", "done"] as const).map((s) => (
                <span key={s} className={`h-2 w-2 rounded-full ${JOB_STATUS[s].dot}`} title={JOB_STATUS[s].label} />
              ))}
            </div>
          </div>
          {activeJobs.length === 0 ? (
            <div className="p-5">
              <EmptyState icon="🚗" title="Нет активных работ" text="Когда появятся записи — они будут здесь." />
            </div>
          ) : (
            <ul className="divide-y divide-slate-100">
              {activeJobs.map((j) => (
                <li key={j.id}>
                  <Link href={`/journal/${j.id}`} className="flex items-center gap-3 px-5 py-3 hover:bg-zinc-950">
                    <span className={`h-2.5 w-2.5 shrink-0 rounded-full ${JOB_STATUS[j.status]?.dot ?? "bg-slate-300"}`} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold text-zinc-100">
                        {j.vehicleMake} {j.vehicleModel ?? ""} · #{j.id}
                      </p>
                      <p className="truncate text-xs text-zinc-400">
                        {JOB_STATUS[j.status]?.label} · {formatDateTime(j.updatedAt)}
                      </p>
                    </div>
                    <span className="text-sm font-bold text-zinc-100">{formatPrice(j.totalCost)}</span>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      <section className="rounded-2xl border border-zinc-800 bg-zinc-900 shadow-sm">
        <div className="flex items-center justify-between border-b border-zinc-800/50 px-5 py-3.5">
          <h2 className="text-base font-semibold text-zinc-100">Последние записи</h2>
          <Link href="/journal" className="text-sm font-medium text-red-500">Все →</Link>
        </div>
        {recentJobs.length === 0 ? (
          <div className="p-5">
            <EmptyState icon="📝" title="Журнал пуст" text="Создайте первую запись с оценкой вмятин." actionHref="/journal/new" actionLabel="Создать запись" />
          </div>
        ) : (
          <ul className="divide-y divide-slate-100">
            {recentJobs.map((j) => (
              <li key={j.id}>
                <Link href={`/journal/${j.id}`} className="flex items-center gap-3 px-5 py-3.5 hover:bg-zinc-950">
                  <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-red-950/20 text-lg">
                    {panelEmoji("hood")}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-zinc-100">
                      {j.vehicleMake} {j.vehicleModel ?? ""} {j.vehicleYear ? `· ${j.vehicleYear}` : ""}
                    </p>
                    <p className="truncate text-xs text-zinc-400">
                      {j.customerName ?? "Без клиента"}
                      {j.licensePlate ? ` · ${j.licensePlate}` : ""} · {formatDateTime(j.createdAt)}
                    </p>
                  </div>
                  <StatusBadge status={j.status} />
                  <div className="w-24 shrink-0 text-right text-sm font-bold text-zinc-100">
                    {formatPrice(j.totalCost)}
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function Stat({
  label,
  value,
  hint,
  tone,
}: {
  label: string;
  value: string;
  hint: string;
  tone?: "ok" | "warn";
}) {
  const accent =
    tone === "ok"
      ? "border-emerald-900 bg-emerald-950/30"
      : tone === "warn"
      ? "border-amber-900 bg-amber-950/30"
      : "border-zinc-800 bg-zinc-900";
  return (
    <div className={`rounded-2xl border p-4 shadow-sm sm:p-5 ${accent}`}>
      <p className="text-[11px] font-medium uppercase tracking-wider text-zinc-400">{label}</p>
      <p className="mt-1.5 text-xl font-bold tracking-tight text-zinc-100 sm:text-2xl">{value}</p>
      <p className="mt-0.5 text-xs text-zinc-400">{hint}</p>
    </div>
  );
}
