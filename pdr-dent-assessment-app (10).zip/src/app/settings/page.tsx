import { SettingsClient } from "@/components/SettingsClient";
import { loadJobFormReference } from "@/lib/settings";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const reference = await loadJobFormReference();
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-zinc-100">Настройки</h1>
        <p className="mt-1 text-sm text-zinc-400">
          Надбавка (аренда), класс авто, ЛКП, метод ремонта, каталог разбора и доп. услуги.
        </p>
      </div>
      <SettingsClient reference={reference} />
    </div>
  );
}
