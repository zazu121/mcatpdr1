import Link from "next/link";
import { db } from "@/db";
import { jobs, jobStatus } from "@/db/schema";
import { desc, eq, or, ilike, and, sql } from "drizzle-orm";
import {
  formatPrice,
  formatDateTime,
  formatDate,
  formatTime,
  JOB_STATUS,
} from "@/lib/pdr";
import { StatusBadge, EmptyState } from "@/components/ui";
import { ensureDbSafe } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

type SP = Promise<{ status?: string; q?: string }>;

const FILTERS = [
  { id: "all", label: "Все" },
  { id: "scheduled", label: "Запись" },
  { id: "arrived", label: "Приехал" },
  { id: "in_progress", label: "В работе" },
  { id: "done", label: "Готово" },
  { id: "delivered", label: "Выдано" },
  { id: "cancelled", label: "Отмена" },
];

export default async function JournalPage({ searchParams }: { searchParams: SP }) {
  await ensureDbSafe();
  const sp = await searchParams;
  const valid = jobStatus.enumValues as string[];
  const active = sp.status && valid.includes(sp.status) ? sp.status : "all";
  const q = sp.q?.trim() ?? "";

  let rows: (typeof jobs.$inferSelect)[] = [];
  try {
    const conditions = [];
    if (active !== "all") {
      conditions.push(eq(jobs.status, active as (typeof jobStatus.enumValues)[number]));
    }
    if (q) {
      const p = `%${q}%`;
      conditions.push(
        or(
          ilike(jobs.customerName, p),
          ilike(jobs.phone, p),
          ilike(jobs.vehicleMake, p),
          ilike(jobs.vehicleModel, p),
          ilike(jobs.licensePlate, p),
          sql`cast(${jobs.id} as text) like ${p}`
        )!
      );
    }
    if (conditions.length) {
      rows = await db
        .select()
        .from(jobs)
        .where(and(...conditions))
        .orderBy(desc(jobs.scheduledAt), desc(jobs.createdAt))
        .limit(300);
    } else {
      rows = await db
        .select()
        .from(jobs)
        .orderBy(desc(jobs.scheduledAt), desc(jobs.createdAt))
        .limit(300);
    }
  } catch (e) {
    console.error(e);
  }

  // Группировка по дате записи
  const groups = new Map<string, (typeof jobs.$inferSelect)[]>();
  for (const j of rows) {
    const key = j.scheduledAt
      ? formatDate(j.scheduledAt)
      : formatDate(j.createdAt);
    const list = groups.get(key) ?? [];
    list.push(j);
    groups.set(key, list);
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-zinc-100">Журнал машин</h1>
          <p className="mt-1 text-sm text-zinc-400">
            {rows.length} записей · когда приедет, когда сделали, сумма
          </p>
        </div>
        <Link
          href="/journal/new"
          className="inline-flex rounded-xl bg-red-600 px-4 py-2.5 text-sm font-semibold text-white shadow-lg shadow-red-600/25"
        >
          + Новая запись
        </Link>
      </div>

      {/* Поиск + фильтры */}
      <form className="flex flex-wrap gap-2" action="/journal" method="get">
        {active !== "all" && <input type="hidden" name="status" value={active} />}
        <input
          name="q"
          defaultValue={q}
          placeholder="Поиск: имя, телефон, номер, марка, #id…"
          className="min-w-[200px] flex-1 rounded-xl border border-zinc-800 bg-zinc-900 px-3.5 py-2.5 text-sm outline-none focus:border-red-500 focus:ring-2 focus:ring-red-500/30"
        />
        <button type="submit" className="rounded-xl bg-zinc-100 px-4 py-2.5 text-sm font-semibold text-zinc-950">
          Найти
        </button>
      </form>

      <div className="flex flex-wrap gap-1.5">
        {FILTERS.map((f) => {
          const href =
            f.id === "all"
              ? q
                ? `/journal?q=${encodeURIComponent(q)}`
                : "/journal"
              : `/journal?status=${f.id}${q ? `&q=${encodeURIComponent(q)}` : ""}`;
          return (
            <Link
              key={f.id}
              href={href}
              className={`rounded-full px-3 py-1.5 text-xs font-medium sm:text-sm ${
                active === f.id
                  ? "bg-zinc-100 text-zinc-950"
                  : "bg-zinc-900 text-zinc-400 ring-1 ring-zinc-800 hover:ring-zinc-700"
              }`}
            >
              {f.id !== "all" && (
                <span className={`mr-1.5 inline-block h-1.5 w-1.5 rounded-full ${JOB_STATUS[f.id]?.dot ?? ""}`} />
              )}
              {f.label}
            </Link>
          );
        })}
      </div>

      {rows.length === 0 ? (
        <EmptyState
          icon="📒"
          title="Записей нет"
          text="Создайте запись: клиент, авто, вмятины, разбор — и всё видно в одном месте."
          actionHref="/journal/new"
          actionLabel="Создать первую запись"
        />
      ) : (
        <div className="space-y-6">
          {Array.from(groups.entries()).map(([day, list]) => (
            <section key={day}>
              <h2 className="mb-2 text-xs font-bold uppercase tracking-wider text-zinc-500">{day}</h2>
              <div className="overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900 shadow-sm">
                <ul className="divide-y divide-slate-100">
                  {list.map((j) => (
                    <li key={j.id}>
                      <Link
                        href={`/journal/${j.id}`}
                        className="grid grid-cols-[auto_1fr_auto] items-center gap-3 px-4 py-3.5 transition-colors hover:bg-zinc-950 sm:grid-cols-[72px_1fr_auto_auto_auto] sm:gap-4 sm:px-5"
                      >
                        <div className="text-center">
                          <p className="text-sm font-bold text-zinc-100">
                            {j.scheduledAt ? formatTime(j.scheduledAt) : "—"}
                          </p>
                          <p className="text-[10px] text-zinc-500">#{j.id}</p>
                        </div>
                        <div className="min-w-0">
                          <p className="truncate text-sm font-semibold text-zinc-100">
                            {j.vehicleMake} {j.vehicleModel ?? ""}
                            {j.vehicleYear ? ` · ${j.vehicleYear}` : ""}
                            {j.vehicleColor ? ` · ${j.vehicleColor}` : ""}
                          </p>
                          <p className="truncate text-xs text-zinc-400">
                            {j.customerName ?? "Без клиента"}
                            {j.phone ? ` · ${j.phone}` : ""}
                            {j.licensePlate ? ` · ${j.licensePlate}` : ""}
                          </p>
                          <div className="mt-1 flex flex-wrap gap-x-3 gap-y-0.5 text-[11px] text-zinc-500 sm:hidden">
                            {j.arrivedAt && <span>Приехал {formatTime(j.arrivedAt)}</span>}
                            {j.completedAt && <span>Готово {formatTime(j.completedAt)}</span>}
                          </div>
                        </div>
                        <div className="hidden min-w-[140px] text-xs text-zinc-400 sm:block">
                          <p>Запись: {formatDateTime(j.scheduledAt)}</p>
                          {j.arrivedAt && <p>Приехал: {formatDateTime(j.arrivedAt)}</p>}
                          {j.startedAt && <p>Старт: {formatDateTime(j.startedAt)}</p>}
                          {j.completedAt && <p>Готово: {formatDateTime(j.completedAt)}</p>}
                          {j.deliveredAt && <p>Выдано: {formatDateTime(j.deliveredAt)}</p>}
                        </div>
                        <StatusBadge status={j.status} />
                        <div className="text-right">
                          <p className="text-sm font-bold tabular-nums text-zinc-100">
                            {formatPrice(j.totalCost)}
                          </p>
                          {j.paidAmount > 0 && (
                            <p className="text-[11px] text-emerald-500">
                              опл. {formatPrice(j.paidAmount)}
                            </p>
                          )}
                          {j.paidAmount === 0 && j.totalCost > 0 && (
                            <p className="text-[11px] text-amber-500">не оплачено</p>
                          )}
                        </div>
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </section>
          ))}
        </div>
      )}
    </div>
  );
}
