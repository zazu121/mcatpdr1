import { notFound } from "next/navigation";
import Link from "next/link";
import { getJobFull } from "@/lib/jobs";
import { JobForm } from "@/components/JobForm";
import { loadJobFormReference } from "@/lib/settings";
import { ensureDbSafe } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

type Params = Promise<{ id: string }>;

export default async function EditJobPage({ params }: { params: Params }) {
  await ensureDbSafe();
  const id = Number((await params).id);
  if (Number.isNaN(id)) notFound();
  const full = await getJobFull(id);
  if (!full) notFound();
  const { job, dents, riItems, extras, photos } = full;
  const reference = await loadJobFormReference();

  return (
    <div className="space-y-5">
      <div>
        <Link href={`/journal/${id}`} className="text-sm font-medium text-zinc-400 hover:text-zinc-200">
          ← К записи #{id}
        </Link>
        <h1 className="mt-1 text-2xl font-bold tracking-tight text-zinc-100">
          Редактирование · {job.vehicleMake} {job.vehicleModel ?? ""}
        </h1>
      </div>
      <JobForm
        mode="edit"
        reference={reference}
        initial={{
          id: job.id,
          customerName: job.customerName,
          phone: job.phone,
          vehicleMake: job.vehicleMake,
          vehicleModel: job.vehicleModel,
          vehicleYear: job.vehicleYear,
          vehicleColor: job.vehicleColor,
          licensePlate: job.licensePlate,
          scheduledAt: job.scheduledAt,
          notes: job.notes,
          internalNotes: job.internalNotes,
          discount: job.discount,
          paidAmount: job.paidAmount,
          status: job.status,
          carClassSlug: job.carClassSlug,
          paintMaterialSlug: job.paintMaterialSlug,
          repairMethodSlug: job.repairMethodSlug,
          markupPercent: job.markupPercent,
          dents,
          riItems,
          extras,
          photos,
        }}
      />
    </div>
  );
}
