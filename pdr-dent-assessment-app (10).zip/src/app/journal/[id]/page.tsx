import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import {
  formatPrice,
  formatDateTime,
  formatSize,
  labelOf,
  panelLabel,
  panelEmoji,
  DENT_TYPES,
  DENT_DEPTHS,
  JOB_STATUS,
} from "@/lib/pdr";
import { getJobFull } from "@/lib/jobs";
import { StatusBadge } from "@/components/ui";
import { JobActions } from "@/components/JobActions";
import { db } from "@/db";
import { carClasses, paintMaterials, repairMethods } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ensureDbSafe } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

type Params = Promise<{ id: string }>;

function Row({ k, v, mono }: { k: string; v: React.ReactNode; mono?: boolean }) {
  return (
    <div className="flex items-start justify-between gap-3 py-2">
      <span className="text-sm text-zinc-400">{k}</span>
      <span className={`text-right text-sm font-medium text-zinc-200 ${mono ? "tabular-nums" : ""}`}>
        {v}
      </span>
    </div>
  );
}

export default async function JobDetailPage({ params }: { params: Params }) {
  await ensureDbSafe();
  const id = Number((await params).id);
  if (Number.isNaN(id)) notFound();

  const full = await getJobFull(id);
  if (!full) notFound();
  const { job: j, dents, riItems, extras, photos } = full;

  const [carClass] = j.carClassSlug
    ? await db.select().from(carClasses).where(eq(carClasses.slug, j.carClassSlug))
    : [];
  const [paintMaterial] = j.paintMaterialSlug
    ? await db.select().from(paintMaterials).where(eq(paintMaterials.slug, j.paintMaterialSlug))
    : [];
  const [repairMethod] = j.repairMethodSlug
    ? await db.select().from(repairMethods).where(eq(repairMethods.slug, j.repairMethodSlug))
    : [];

  const timeline = [
    { key: "scheduledAt", label: "Запись / приедет", at: j.scheduledAt },
    { key: "arrivedAt", label: "Приехал", at: j.arrivedAt },
    { key: "startedAt", label: "Начали работу", at: j.startedAt },
    { key: "completedAt", label: "Сделали", at: j.completedAt },
    { key: "deliveredAt", label: "Клиент забрал", at: j.deliveredAt },
  ];

  return (
    <div className="space-y-5">
      <Link href="/journal" className="inline-flex items-center gap-1.5 text-sm font-medium text-zinc-400 hover:text-zinc-200">
        ← К журналу
      </Link>

      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        <div className="space-y-5">
          <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm sm:p-6">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h1 className="text-2xl font-bold tracking-tight text-zinc-100">
                    {j.vehicleMake} {j.vehicleModel ?? ""}
                  </h1>
                  <StatusBadge status={j.status} />
                </div>
                <p className="mt-1 text-sm text-zinc-400">
                  {[j.vehicleYear, j.vehicleColor, j.licensePlate, `#${j.id}`].filter(Boolean).join(" · ")}
                </p>
                <div className="mt-2 flex flex-wrap gap-1.5 text-xs">
                  {carClass && <Chip>Класс: {carClass.label}</Chip>}
                  {paintMaterial && <Chip>ЛКП: {paintMaterial.label}</Chip>}
                  {repairMethod && <Chip>Метод: {repairMethod.label}</Chip>}
                </div>
              </div>
              <div className="text-right">
                <p className="text-xs uppercase tracking-wider text-zinc-500">Клиенту</p>
                <p className="text-3xl font-bold tabular-nums text-zinc-100">{formatPrice(j.totalCost)}</p>
                <p className="text-xs text-zinc-400">
                  из них аренда {formatPrice(j.markupAmount)} ({j.markupPercent}%)
                </p>
                {j.paidAmount > 0 && (
                  <p className="text-xs text-emerald-500">
                    оплачено {formatPrice(j.paidAmount)}
                    {j.paidAmount < j.totalCost ? ` · долг ${formatPrice(j.totalCost - j.paidAmount)}` : " · закрыто"}
                  </p>
                )}
              </div>
            </div>

            <div className="mt-5 grid gap-4 border-t border-zinc-800/50 pt-5 sm:grid-cols-2">
              <div>
                <p className="text-xs uppercase tracking-wider text-zinc-500">Клиент</p>
                <p className="mt-1 text-sm font-semibold text-zinc-100">{j.customerName ?? "—"}</p>
                {j.phone && (
                  <a href={`tel:${j.phone}`} className="text-sm text-red-500 hover:underline">
                    {j.phone}
                  </a>
                )}
                {j.customerId && (
                  <div>
                    <Link href={`/customers/${j.customerId}`} className="text-xs text-zinc-500 hover:text-red-500">
                      Карточка клиента →
                    </Link>
                  </div>
                )}
              </div>
              <div>
                <p className="text-xs uppercase tracking-wider text-zinc-500">Статус сейчас</p>
                <p className="mt-1 text-sm font-semibold text-zinc-100">{JOB_STATUS[j.status]?.label ?? j.status}</p>
                <p className="text-xs text-zinc-500">обновлено {formatDateTime(j.updatedAt)}</p>
              </div>
            </div>
          </section>

          {photos.length > 0 && (
            <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
              <h2 className="mb-3 text-base font-semibold text-zinc-100">Фотографии · {photos.length}</h2>
              <div className="grid grid-cols-3 gap-2 sm:grid-cols-4 md:grid-cols-5">
                {photos.map((p) => (
                  <a key={p.id} href={p.url} target="_blank" rel="noopener" className="relative aspect-square overflow-hidden rounded-xl border border-zinc-800 bg-zinc-800">
                    <Image src={p.url} alt={p.caption ?? "фото"} fill className="object-cover" sizes="200px" unoptimized />
                  </a>
                ))}
              </div>
            </section>
          )}

          <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
            <h2 className="mb-4 text-base font-semibold text-zinc-100">Хронология</h2>
            <ol className="relative ml-2 space-y-0 border-l-2 border-zinc-800/50">
              {timeline.map((t) => {
                const done = Boolean(t.at);
                return (
                  <li key={t.key} className="relative pb-5 pl-5 last:pb-0">
                    <span className={`absolute -left-[9px] top-1 h-4 w-4 rounded-full border-2 border-white ${done ? "bg-red-950/200" : "bg-zinc-700"}`} />
                    <p className={`text-sm font-medium ${done ? "text-zinc-100" : "text-zinc-500"}`}>{t.label}</p>
                    <p className="text-xs text-zinc-400">{done ? formatDateTime(t.at) : "ещё не отмечено"}</p>
                  </li>
                );
              })}
            </ol>
          </section>

          <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-base font-semibold text-zinc-100">Вмятины · {dents.length}</h2>
              <span className="text-sm font-semibold text-zinc-300">{formatPrice(j.dentsTotal)}</span>
            </div>
            {dents.length === 0 ? (
              <p className="text-sm text-zinc-400">Вмятины не добавлены.</p>
            ) : (
              <ul className="divide-y divide-slate-100 overflow-hidden rounded-xl border border-zinc-800/50">
                {dents.map((d) => (
                  <li key={d.id} className="flex items-start gap-3 p-3.5">
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-red-950/20 text-lg">{panelEmoji(d.panel)}</span>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-zinc-100">
                        {panelLabel(d.panel)}
                        {d.quantity > 1 ? ` · ×${d.quantity}` : ""}
                      </p>
                      <p className="text-xs text-zinc-400">
                        {formatSize(d.lengthMm, d.widthMm)} · {labelOf(DENT_TYPES, d.dentType)} · {labelOf(DENT_DEPTHS, d.depth)}
                      </p>
                      <div className="mt-1 flex flex-wrap gap-1">
                        {d.isAluminum && <Tag>Алюминий</Tag>}
                        {d.onBodyLine && <Tag>Ребро</Tag>}
                        {d.gluePull && <Tag>Glue pull</Tag>}
                        {d.hardAccess && <Tag>Сложный доступ</Tag>}
                      </div>
                      {d.notes && <p className="mt-1 text-xs text-zinc-400">{d.notes}</p>}
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold tabular-nums text-zinc-100">{formatPrice(d.lineTotal)}</p>
                      <p className="text-[11px] text-zinc-500">{formatPrice(d.unitPrice)} / шт</p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </section>

          {riItems.length > 0 && (
            <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
              <div className="mb-3 flex items-center justify-between">
                <h2 className="text-base font-semibold text-zinc-100">Разбор / сборка · {riItems.length}</h2>
                <span className="text-sm font-semibold text-zinc-300">{formatPrice(j.riTotal)}</span>
              </div>
              <ul className="divide-y divide-slate-100 overflow-hidden rounded-xl border border-zinc-800/50">
                {riItems.map((r) => (
                  <li key={r.id} className="flex items-center justify-between gap-3 p-3.5">
                    <div>
                      <p className="text-sm font-medium text-zinc-100">{r.label}</p>
                      {r.panel && <p className="text-xs text-zinc-500">{panelLabel(r.panel)}</p>}
                    </div>
                    <div className="text-right text-sm">
                      <p className="font-bold tabular-nums text-zinc-100">{formatPrice(r.lineTotal)}</p>
                      {r.quantity > 1 && <p className="text-[11px] text-zinc-500">{formatPrice(r.price)} × {r.quantity}</p>}
                    </div>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {extras.length > 0 && (
            <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
              <div className="mb-3 flex items-center justify-between">
                <h2 className="text-base font-semibold text-zinc-100">Доп. услуги · {extras.length}</h2>
                <span className="text-sm font-semibold text-zinc-300">{formatPrice(j.extrasTotal)}</span>
              </div>
              <ul className="divide-y divide-slate-100 overflow-hidden rounded-xl border border-zinc-800/50">
                {extras.map((r) => (
                  <li key={r.id} className="flex items-center justify-between gap-3 p-3.5">
                    <p className="text-sm font-medium text-zinc-100">{r.label}</p>
                    <div className="text-right text-sm">
                      <p className="font-bold tabular-nums text-zinc-100">{formatPrice(r.lineTotal)}</p>
                      {r.quantity > 1 && <p className="text-[11px] text-zinc-500">{formatPrice(r.price)} × {r.quantity}</p>}
                    </div>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {(j.notes || j.internalNotes) && (
            <section className="grid gap-4 sm:grid-cols-2">
              {j.notes && (
                <div className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
                  <p className="text-xs font-medium uppercase tracking-wider text-zinc-500">Комментарий</p>
                  <p className="mt-2 whitespace-pre-wrap text-sm text-zinc-300">{j.notes}</p>
                </div>
              )}
              {j.internalNotes && (
                <div className="rounded-2xl border border-amber-100 bg-amber-50/50 p-5 shadow-sm">
                  <p className="text-xs font-medium uppercase tracking-wider text-amber-700/70">Внутренняя заметка</p>
                  <p className="mt-2 whitespace-pre-wrap text-sm text-amber-950">{j.internalNotes}</p>
                </div>
              )}
            </section>
          )}
        </div>

        <aside className="space-y-5 lg:sticky lg:top-20 lg:self-start">
          <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
            <h2 className="mb-3 text-base font-semibold text-zinc-100">Разбивка</h2>
            <div className="divide-y divide-slate-100">
              <Row k="ПДР" v={formatPrice(j.dentsTotal)} mono />
              <Row k="Разбор" v={formatPrice(j.riTotal)} mono />
              <Row k="Доп. услуги" v={formatPrice(j.extrasTotal)} mono />
              {j.discount > 0 && <Row k="Скидка" v={`−${formatPrice(j.discount)}`} mono />}
              <Row k="Моя часть" v={<span className="text-emerald-500">{formatPrice(j.earnings)}</span>} mono />
              <Row k={`Аренда ${j.markupPercent}%`} v={<span className="text-amber-500">{formatPrice(j.markupAmount)}</span>} mono />
              <Row k="К оплате" v={<span className="text-base font-bold">{formatPrice(j.totalCost)}</span>} mono />
              <Row k="Оплачено" v={formatPrice(j.paidAmount)} mono />
              <Row k="Остаток" v={formatPrice(Math.max(0, j.totalCost - j.paidAmount))} mono />
            </div>
          </section>

          <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
            <h2 className="mb-3 text-base font-semibold text-zinc-100">Действия</h2>
            <JobActions jobId={j.id} currentStatus={j.status} paidAmount={j.paidAmount} totalCost={j.totalCost} />
          </section>
        </aside>
      </div>
    </div>
  );
}

function Tag({ children }: { children: React.ReactNode }) {
  return (
    <span className="rounded-md bg-zinc-800 px-1.5 py-0.5 text-[10px] font-medium text-zinc-400">{children}</span>
  );
}
function Chip({ children }: { children: React.ReactNode }) {
  return (
    <span className="rounded-full bg-zinc-800 px-2 py-0.5 text-[11px] font-medium text-zinc-400">{children}</span>
  );
}
