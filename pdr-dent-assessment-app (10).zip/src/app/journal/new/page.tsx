import { JobForm } from "@/components/JobForm";
import { loadJobFormReference } from "@/lib/settings";
import { loadPrefill } from "@/lib/prefill";

export const dynamic = "force-dynamic";

type SP = Promise<{ customerId?: string; vehicleId?: string }>;

export default async function NewJobPage({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  const reference = await loadJobFormReference();
  const prefill = await loadPrefill(sp);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-zinc-100">Новая запись</h1>
        <p className="mt-1 text-sm text-zinc-400">
          Клиент, авто, вмятины с размерами, разбор и доп. услуги. Надбавка учитывается автоматически.
        </p>
      </div>
      <JobForm mode="create" reference={reference} initial={prefill ?? undefined} />
    </div>
  );
}
