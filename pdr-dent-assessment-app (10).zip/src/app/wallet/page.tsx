import Link from "next/link";
import { db } from "@/db";
import { jobs, walletEntries } from "@/db/schema";
import { and, desc, gte, sql } from "drizzle-orm";
import { formatPrice, formatDateTime, formatDate } from "@/lib/pdr";
import { getMarkupLabel } from "@/lib/settings";
import { WalletManual } from "@/components/WalletManual";
import { ensureDbSafe } from "@/db/bootstrap";

export const dynamic = "force-dynamic";

type SP = Promise<{ period?: string }>;

const PERIODS = [
  { id: "7d", label: "7 дней" },
  { id: "30d", label: "30 дней" },
  { id: "90d", label: "90 дней" },
  { id: "all", label: "Всё время" },
];

function periodStart(id: string): Date | null {
  const n = new Date();
  if (id === "7d") { n.setDate(n.getDate() - 7); return n; }
  if (id === "30d") { n.setDate(n.getDate() - 30); return n; }
  if (id === "90d") { n.setDate(n.getDate() - 90); return n; }
  return null;
}

export default async function WalletPage({ searchParams }: { searchParams: SP }) {
  await ensureDbSafe();
  const { period } = await searchParams;
  const p = period ?? "30d";
  const from = periodStart(p);
  const markupLabel = await getMarkupLabel();

  const conditions = [
    sql`${jobs.status} in ('done','delivered')`,
    sql`${jobs.totalCost} > 0`,
  ];
  if (from) conditions.push(gte(jobs.completedAt, from));

  const jobsRows = await db
    .select()
    .from(jobs)
    .where(and(...conditions))
    .orderBy(desc(jobs.completedAt), desc(jobs.updatedAt))
    .limit(500);

  const manual = await db
    .select()
    .from(walletEntries)
    .orderBy(desc(walletEntries.createdAt))
    .limit(100);

  const totals = jobsRows.reduce(
    (acc, j) => {
      acc.gross += j.totalCost;
      acc.earnings += j.earnings;
      acc.rent += j.markupAmount;
      acc.paid += j.paidAmount;
      acc.debt += Math.max(0, j.totalCost - j.paidAmount);
      return acc;
    },
    { gross: 0, earnings: 0, rent: 0, paid: 0, debt: 0 }
  );
  const manualIncome = manual.filter((m) => m.kind === "income").reduce((s, m) => s + m.amount, 0);
  const manualExpense = manual.filter((m) => m.kind === "expense").reduce((s, m) => s + m.amount, 0);
  const netEarnings = totals.earnings + manualIncome - manualExpense;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-zinc-100">Кошелёк</h1>
          <p className="mt-1 text-sm text-zinc-400">Разбивка выручки по завершённым работам · {jobsRows.length} шт</p>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {PERIODS.map((pp) => (
            <Link
              key={pp.id}
              href={`/wallet?period=${pp.id}`}
              className={`rounded-full px-3 py-1.5 text-xs font-medium sm:text-sm ${
                p === pp.id ? "bg-zinc-100 text-zinc-950" : "bg-zinc-900 text-zinc-400 ring-1 ring-zinc-800 hover:ring-zinc-700"
              }`}
            >
              {pp.label}
            </Link>
          ))}
        </div>
      </div>

      <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <BigStat label="Мне (заработал)" value={formatPrice(totals.earnings)} tone="ok" hint="из завершённых" />
        <BigStat label={markupLabel} value={formatPrice(totals.rent)} tone="warn" hint="надбавка" />
        <BigStat label="Всего с клиентов" value={formatPrice(totals.gross)} tone="primary" hint={`оплачено ${formatPrice(totals.paid)}`} />
        <BigStat label="Долги" value={formatPrice(totals.debt)} tone="danger" hint="не оплачено" />
      </section>

      <section className="grid gap-5 lg:grid-cols-[1fr_320px]">
        <div className="rounded-2xl border border-zinc-800 bg-zinc-900 shadow-sm">
          <div className="border-b border-zinc-800/50 px-5 py-3.5">
            <h2 className="text-base font-semibold text-zinc-100">Завершённые работы</h2>
          </div>
          {jobsRows.length === 0 ? (
            <div className="p-8 text-center text-sm text-zinc-400">
              За выбранный период завершённых работ нет.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead className="bg-zinc-950 text-xs uppercase tracking-wider text-zinc-500">
                  <tr>
                    <th className="px-4 py-2 text-left">Когда</th>
                    <th className="px-4 py-2 text-left">Авто / клиент</th>
                    <th className="px-4 py-2 text-right">Мне</th>
                    <th className="px-4 py-2 text-right">Аренда</th>
                    <th className="px-4 py-2 text-right">К оплате</th>
                    <th className="px-4 py-2 text-right">Оплачено</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {jobsRows.map((j) => (
                    <tr key={j.id} className="hover:bg-zinc-950">
                      <td className="px-4 py-2.5 text-xs text-zinc-400">
                        {formatDate(j.completedAt ?? j.updatedAt)}
                      </td>
                      <td className="px-4 py-2.5">
                        <Link href={`/journal/${j.id}`} className="font-medium text-zinc-100 hover:text-red-500">
                          {j.vehicleMake} {j.vehicleModel ?? ""}
                        </Link>
                        <div className="text-xs text-zinc-400">{j.customerName ?? "—"}</div>
                      </td>
                      <td className="px-4 py-2.5 text-right font-semibold tabular-nums text-emerald-500">
                        {formatPrice(j.earnings)}
                      </td>
                      <td className="px-4 py-2.5 text-right text-xs tabular-nums text-amber-500">
                        {formatPrice(j.markupAmount)}
                        <span className="ml-1 text-zinc-500">{j.markupPercent}%</span>
                      </td>
                      <td className="px-4 py-2.5 text-right font-bold tabular-nums text-zinc-100">
                        {formatPrice(j.totalCost)}
                      </td>
                      <td className="px-4 py-2.5 text-right tabular-nums">
                        {j.paidAmount >= j.totalCost ? (
                          <span className="text-emerald-500">закрыто</span>
                        ) : (
                          <span className="text-red-500">−{formatPrice(j.totalCost - j.paidAmount)}</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="border-t border-zinc-800 bg-zinc-950 font-semibold">
                  <tr>
                    <td colSpan={2} className="px-4 py-3 text-zinc-400">Итого за период</td>
                    <td className="px-4 py-3 text-right tabular-nums text-emerald-500">{formatPrice(totals.earnings)}</td>
                    <td className="px-4 py-3 text-right tabular-nums text-amber-500">{formatPrice(totals.rent)}</td>
                    <td className="px-4 py-3 text-right tabular-nums text-zinc-100">{formatPrice(totals.gross)}</td>
                    <td className="px-4 py-3 text-right tabular-nums text-zinc-400">{formatPrice(totals.paid)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </div>

        <aside className="space-y-5">
          <div className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
            <h3 className="mb-2 text-base font-semibold text-zinc-100">Чистый итог</h3>
            <div className="space-y-1.5 text-sm">
              <div className="flex justify-between text-zinc-400">
                <span>Работы (моё)</span>
                <span className="font-medium text-zinc-100 tabular-nums">{formatPrice(totals.earnings)}</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Ручные доходы</span>
                <span className="font-medium text-emerald-500 tabular-nums">+{formatPrice(manualIncome)}</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Ручные расходы</span>
                <span className="font-medium text-red-500 tabular-nums">−{formatPrice(manualExpense)}</span>
              </div>
              <div className="mt-2 flex justify-between border-t border-zinc-800/50 pt-2 text-base font-bold text-zinc-100">
                <span>Чистыми</span>
                <span className="tabular-nums">{formatPrice(netEarnings)}</span>
              </div>
            </div>
          </div>

          <WalletManual entries={manual} />
        </aside>
      </section>

      {manual.length > 0 && (
        <section className="rounded-2xl border border-zinc-800 bg-zinc-900 shadow-sm">
          <div className="border-b border-zinc-800/50 px-5 py-3.5">
            <h2 className="text-base font-semibold text-zinc-100">Ручные операции</h2>
          </div>
          <ul className="divide-y divide-slate-100">
            {manual.map((m) => (
              <li key={m.id} className="flex items-center justify-between gap-3 px-5 py-3">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-zinc-100">
                    {m.description || (m.kind === "income" ? "Доход" : "Расход")}
                    {m.category && <span className="ml-2 text-xs text-zinc-400">· {m.category}</span>}
                  </p>
                  <p className="text-xs text-zinc-400">{formatDateTime(m.createdAt)}</p>
                </div>
                <span className={`text-sm font-bold tabular-nums ${m.kind === "income" ? "text-emerald-500" : "text-red-500"}`}>
                  {m.kind === "income" ? "+" : "−"}
                  {formatPrice(m.amount)}
                </span>
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}

function BigStat({
  label,
  value,
  hint,
  tone,
}: {
  label: string;
  value: string;
  hint: string;
  tone: "ok" | "warn" | "primary" | "danger";
}) {
  const cls =
    tone === "ok"
      ? "from-emerald-500 to-emerald-600 text-white"
      : tone === "warn"
      ? "from-amber-500 to-amber-600 text-white"
      : tone === "danger"
      ? "from-rose-500 to-rose-600 text-white"
      : "from-zinc-900 to-zinc-950 text-white";
  return (
    <div className={`rounded-2xl bg-gradient-to-br p-4 shadow-lg sm:p-5 ${cls}`}>
      <p className="text-[11px] font-medium uppercase tracking-wider opacity-80">{label}</p>
      <p className="mt-1.5 text-xl font-bold tracking-tight sm:text-2xl">{value}</p>
      <p className="mt-0.5 text-xs opacity-75">{hint}</p>
    </div>
  );
}
