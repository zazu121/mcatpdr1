import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { Navbar } from "@/components/Navbar";
import { AppearanceProvider } from "@/components/AppearanceProvider";

export const metadata: Metadata = {
  title: "MCAT PDR — Журнал и оценка ПДР",
  description:
    "Рабочий инструмент мастера ПДР: журнал машин, запись клиентов, калькулятор вмятин с размерами и разбором элементов.",
};

// Скрипт применяет сохранённое оформление до отрисовки — без мигания темы.
const themeScript = `
(function(){
  try {
    var a = JSON.parse(localStorage.getItem('mcat_appearance') || '{}');
    var h = document.documentElement;
    h.classList.add(a.theme === 'light' ? 'light' : 'dark');
    h.classList.add('wp-' + (a.wallpaper || 'standard'));
    if (a.navPosition === 'bottom') h.classList.add('nav-bottom');
  } catch(e) {
    document.documentElement.classList.add('dark','wp-standard');
  }
})();
`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru" className="dark wp-standard">
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body className="min-h-screen text-zinc-100 antialiased">
        <AppearanceProvider />
        <Navbar />
        <main className="mx-auto max-w-7xl px-3 py-6 sm:px-6 sm:py-8">{children}</main>
        <footer className="border-t border-zinc-800 bg-zinc-900">
          <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-4 py-5 text-sm text-zinc-400 sm:flex-row sm:px-6">
            <p>© {new Date().getFullYear()} MCAT PDR · PDR журнал и калькулятор</p>
            <p className="text-xs text-zinc-500">Для быстрой оценки и учёта работ</p>
          </div>
        </footer>
      </body>
    </html>
  );
}
