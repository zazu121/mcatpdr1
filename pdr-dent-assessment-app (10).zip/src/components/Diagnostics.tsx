"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

type Counts = Record<string, number>;

const LABELS: [string, string][] = [
  ["carClasses", "Классы авто"],
  ["paintMaterials", "Материалы ЛКП"],
  ["repairMethods", "Методы ремонта"],
  ["riCatalog", "Позиции разбора"],
  ["extraServices", "Доп. услуги"],
  ["calcOptions", "Опции калькулятора"],
  ["jobs", "Записей в журнале"],
  ["customers", "Клиентов"],
];

export function Diagnostics() {
  const router = useRouter();
  const [counts, setCounts] = useState<Counts | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function check() {
    setErr(null);
    try {
      const res = await fetch("/api/setup");
      const data = await res.json();
      if (data.ok) setCounts(data.counts);
      else setErr(data.error || "Ошибка");
    } catch {
      setErr("Нет связи с сервером");
    }
  }

  useEffect(() => {
    check();
  }, []);

  async function repair() {
    setBusy(true);
    setErr(null);
    try {
      const res = await fetch("/api/setup", { method: "POST" });
      const data = await res.json();
      if (data.ok) {
        setCounts(data.counts);
        router.refresh();
      } else setErr(data.error || "Ошибка");
    } catch {
      setErr("Нет связи с сервером");
    }
    setBusy(false);
  }

  const empty = counts
    ? LABELS.slice(0, 6).every(([k]) => (counts[k] ?? 0) === 0)
    : false;

  return (
    <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
      <h3 className="mb-1 text-base font-semibold text-zinc-100">🩺 Диагностика базы</h3>
      <p className="mb-4 text-sm text-zinc-400">
        Состояние справочников на сервере. При первом запуске всё создаётся автоматически.
      </p>

      {err && (
        <div className="mb-3 rounded-xl border border-red-900/50 bg-red-950/30 p-3 text-sm text-red-300">
          {err}
          <div className="mt-1 text-xs text-zinc-400">
            Проверьте переменную <code className="text-red-400">DATABASE_URL</code> на хостинге.
          </div>
        </div>
      )}

      {counts && (
        <div className="mb-4 grid grid-cols-2 gap-2">
          {LABELS.map(([k, label]) => {
            const n = counts[k] ?? 0;
            const bad = n === 0 && !["jobs", "customers"].includes(k);
            return (
              <div
                key={k}
                className={`rounded-xl border px-3 py-2 ${
                  bad ? "border-amber-900 bg-amber-950/20" : "border-zinc-800 bg-zinc-950"
                }`}
              >
                <p className="text-[11px] uppercase tracking-wider text-zinc-500">{label}</p>
                <p className={`text-lg font-bold ${bad ? "text-amber-400" : "text-zinc-100"}`}>{n}</p>
              </div>
            );
          })}
        </div>
      )}

      {empty && (
        <p className="mb-3 rounded-xl bg-amber-950/30 px-3 py-2 text-xs text-amber-300">
          Справочники пусты — нажмите «Восстановить справочники».
        </p>
      )}

      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={repair}
          disabled={busy}
          className="rounded-xl bg-red-600 px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-60"
        >
          {busy ? "Восстанавливаем…" : "Восстановить справочники"}
        </button>
        <button
          type="button"
          onClick={check}
          className="rounded-xl border border-zinc-700 bg-zinc-900 px-4 py-2.5 text-sm font-semibold text-zinc-200"
        >
          Проверить снова
        </button>
      </div>
    </section>
  );
}
