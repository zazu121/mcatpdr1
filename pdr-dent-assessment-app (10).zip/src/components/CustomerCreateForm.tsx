"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Field, inputCls } from "@/components/ui";

export function CustomerCreateForm() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) {
      setError("Укажите имя");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/customers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, phone, email, notes }),
      });
      if (!res.ok) throw new Error("fail");
      const data = await res.json();
      setName("");
      setPhone("");
      setEmail("");
      setNotes("");
      router.push(`/customers/${data.customer.id}`);
      router.refresh();
    } catch {
      setError("Не удалось сохранить");
      setLoading(false);
    }
  }

  return (
    <form onSubmit={submit} className="h-fit rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
      <h2 className="mb-3 text-base font-semibold text-zinc-100">Новый клиент</h2>
      <div className="space-y-3">
        <Field label="Имя *">
          <input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} placeholder="Иван Петров" />
        </Field>
        <Field label="Телефон">
          <input className={inputCls} value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+7 …" />
        </Field>
        <Field label="Email">
          <input className={inputCls} value={email} onChange={(e) => setEmail(e.target.value)} placeholder="mail@…" />
        </Field>
        <Field label="Заметка">
          <textarea className={`${inputCls} min-h-[72px]`} value={notes} onChange={(e) => setNotes(e.target.value)} />
        </Field>
        {error && <p className="text-sm text-red-500">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-xl bg-red-600 py-2.5 text-sm font-semibold text-white disabled:opacity-60"
        >
          {loading ? "Сохраняем…" : "Добавить клиента"}
        </button>
      </div>
    </form>
  );
}
