"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { formatPrice } from "@/lib/pdr";
import { inputCls } from "@/components/ui";
import type {
  CarClass,
  PaintMaterial,
  RepairMethod,
  RiCatalogRow,
  ExtraServiceRow,
  CalcOption,
} from "@/db/schema";
import { AppearanceTab } from "@/components/AppearanceTab";
import { Diagnostics } from "@/components/Diagnostics";

type Reference = {
  markupPercent: number;
  markupLabel: string;
  tzOffset?: number;
  ratePerCm2?: number;
  minDentPrice?: number;
  carClasses: CarClass[];
  paintMaterials: PaintMaterial[];
  repairMethods: RepairMethod[];
  riCatalog: RiCatalogRow[];
  extraServices: ExtraServiceRow[];
  panels?: CalcOption[];
  sizePresets?: CalcOption[];
  dentTypes?: CalcOption[];
  depths?: CalcOption[];
  surcharges?: CalcOption[];
};

type TabId = "pricing" | "multipliers" | "calc" | "ri" | "extras" | "appearance";
const TABS: { id: TabId; label: string; icon: string }[] = [
  { id: "pricing", label: "Цены и надбавка", icon: "💰" },
  { id: "multipliers", label: "Класс / ЛКП / метод", icon: "📊" },
  { id: "calc", label: "Калькулятор", icon: "📐" },
  { id: "ri", label: "Разбор / R&I", icon: "🔧" },
  { id: "extras", label: "Доп. услуги", icon: "✨" },
  { id: "appearance", label: "Оформление", icon: "🎨" },
];

export function SettingsClient({ reference }: { reference: Reference }) {
  const [tab, setTab] = useState<TabId>("pricing");

  return (
    <div className="grid gap-5 lg:grid-cols-[220px_1fr]">
      <nav className="sticky top-14 z-30 flex flex-row gap-1 overflow-x-auto rounded-2xl border border-zinc-800 bg-zinc-900/95 p-2 shadow-sm backdrop-blur lg:top-20 lg:flex-col lg:self-start">
        {TABS.map((t) => {
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2 text-sm font-medium transition-colors ${
                active ? "bg-zinc-100 text-zinc-950" : "text-zinc-400 hover:bg-zinc-800"
              }`}
            >
              <span>{t.icon}</span>
              <span>{t.label}</span>
            </button>
          );
        })}
      </nav>
      <div>
        {tab === "pricing" && <PricingTab initial={reference} />}
        {tab === "multipliers" && <MultipliersTab initial={reference} />}
        {tab === "calc" && <CalcTab reference={reference} />}
        {tab === "ri" && <RiTab initial={reference.riCatalog} />}
        {tab === "extras" && <ExtrasTab initial={reference.extraServices} />}
        {tab === "appearance" && <AppearanceTab />}
      </div>
    </div>
  );
}

/* ---------- Надбавка ---------- */

function PricingTab({ initial }: { initial: { markupPercent: number; markupLabel: string; tzOffset?: number; ratePerCm2?: number; minDentPrice?: number } }) {
  const router = useRouter();
  const [percent, setPercent] = useState(initial.markupPercent);
  const [label, setLabel] = useState(initial.markupLabel);
  const [tz, setTz] = useState(initial.tzOffset ?? 3);
  const [rate, setRate] = useState(initial.ratePerCm2 ?? 180);
  const [minDent, setMinDent] = useState(initial.minDentPrice ?? 1200);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  async function save() {
    setSaving(true);
    setMsg(null);
    const res = await fetch("/api/settings", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ markupPercent: percent, markupLabel: label, tzOffset: tz, ratePerCm2: rate, minDentPrice: minDent }),
    });
    setSaving(false);
    if (res.ok) {
      setMsg("Сохранено");
      router.refresh();
    } else setMsg("Ошибка");
  }

  const example = 10000;
  const rent = Math.round((example * percent) / 100);
  const total = example + rent;

  return (
    <div className="space-y-5">
      <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
        <h2 className="mb-1 text-base font-semibold text-zinc-100">Надбавка к итоговой цене</h2>
        <p className="mb-4 text-sm text-zinc-400">
          Добавляется сверху заработка. Например, для аренды бокса.
        </p>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block">
            <span className="mb-1.5 block text-sm font-medium text-zinc-300">Процент надбавки</span>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min={0}
                max={500}
                className={inputCls}
                value={percent}
                onChange={(e) => setPercent(Math.max(0, Math.min(500, Number(e.target.value) || 0)))}
              />
              <span className="text-lg font-semibold text-zinc-400">%</span>
            </div>
          </label>
          <label className="block">
            <span className="mb-1.5 block text-sm font-medium text-zinc-300">Название (для себя)</span>
            <input className={inputCls} value={label} onChange={(e) => setLabel(e.target.value)} placeholder="Аренда бокса" />
          </label>
        </div>

        <div className="mt-4 grid gap-2 rounded-2xl bg-zinc-950 p-4 sm:grid-cols-3">
          <Stat label="Заработал (моё)" value={formatPrice(example)} tone="ok" />
          <Stat label={`${label} ${percent}%`} value={formatPrice(rent)} tone="warn" />
          <Stat label="Цена клиенту" value={formatPrice(total)} tone="primary" />
        </div>

        <div className="mt-4 flex items-center gap-3">
          <button
            type="button"
            onClick={save}
            disabled={saving}
            className="rounded-xl bg-red-600 px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-60"
          >
            {saving ? "Сохраняем…" : "Сохранить"}
          </button>
          {msg && <p className="text-sm text-zinc-400">{msg}</p>}
        </div>
      </section>

      <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
        <h3 className="mb-1 text-base font-semibold text-zinc-100">Расчёт вмятины по площади</h3>
        <p className="mb-4 text-sm text-zinc-400">Базовая ставка за 1 см² площади вмятины и минимальная цена за вмятину.</p>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block">
            <span className="mb-1.5 block text-sm font-medium text-zinc-300">Коэффициент ₽ за см²</span>
            <input type="number" min={1} className={inputCls} value={rate} onChange={(e) => setRate(Math.max(1, Number(e.target.value) || 1))} />
          </label>
          <label className="block">
            <span className="mb-1.5 block text-sm font-medium text-zinc-300">Минимум за вмятину, ₽</span>
            <input type="number" min={0} className={inputCls} value={minDent} onChange={(e) => setMinDent(Math.max(0, Number(e.target.value) || 0))} />
          </label>
        </div>
        <p className="mt-3 text-xs text-zinc-500">Пример: вмятина 8×6 см = 48 см² × {rate} ₽ × понижающий коэф. размера.</p>
      </section>

      <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
        <h3 className="mb-1 text-base font-semibold text-zinc-100">Часовой пояс</h3>
        <p className="mb-4 text-sm text-zinc-400">Смещение от UTC (Москва = +3). Влияет на авто-отметки времени статусов.</p>
        <label className="block max-w-[200px]">
          <span className="mb-1.5 block text-sm font-medium text-zinc-300">Смещение, часов</span>
          <input type="number" min={-12} max={14} className={inputCls} value={tz} onChange={(e) => setTz(Number(e.target.value) || 0)} />
        </label>
      </section>

      <Diagnostics />

      <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
        <h3 className="mb-2 text-base font-semibold text-zinc-100">Как это работает</h3>
        <ul className="space-y-1.5 text-sm text-zinc-400">
          <li>• Калькулятор считает базовую цену работы (моя часть) — это «Заработал».</li>
          <li>• Сверху накидывается надбавка (аренда) — {percent}%.</li>
          <li>• Клиент видит итог «моё + надбавка». В журнале и кошельке разбивка всегда сохраняется.</li>
        </ul>
      </section>
    </div>
  );
}

/* ---------- Калькулятор: панели, пресеты, типы, глубины, надбавки ---------- */

type OptKind = "panel" | "size_preset" | "dent_type" | "depth" | "surcharge";

function CalcTab({ reference }: { reference: { panels?: CalcOption[]; sizePresets?: CalcOption[]; dentTypes?: CalcOption[]; depths?: CalcOption[]; surcharges?: CalcOption[] } }) {
  return (
    <div className="space-y-5">
      <div className="rounded-2xl border border-red-900/40 bg-red-950/10 p-4 text-sm text-zinc-400">
        Если список пуст — калькулятор использует встроенные значения по умолчанию. Добавьте свои, чтобы переопределить.
      </div>
      <CalcOptionsBlock kind="panel" title="Элементы кузова" desc="Свои панели с множителем сложности доступа." items={reference.panels ?? []} hasEmoji hasMultiplier />
      <CalcOptionsBlock kind="size_preset" title="Пресеты размеров" desc="Быстрые кнопки размеров (длина × ширина, мм)." items={reference.sizePresets ?? []} hasSize />
      <CalcOptionsBlock kind="dent_type" title="Типы вмятин" desc="Свои типы с множителем." items={reference.dentTypes ?? []} hasMultiplier />
      <CalcOptionsBlock kind="depth" title="Глубины" desc="Свои варианты глубины с множителем." items={reference.depths ?? []} hasMultiplier />
      <CalcOptionsBlock kind="surcharge" title="Надбавки" desc="Свои надбавки (алюминий, ребро…). Множитель = доля, напр. 0.3 = +30%." items={reference.surcharges ?? []} hasMultiplier isPercent />
    </div>
  );
}

function CalcOptionsBlock({
  kind, title, desc, items, hasEmoji, hasMultiplier, hasSize, isPercent,
}: {
  kind: OptKind; title: string; desc: string; items: CalcOption[];
  hasEmoji?: boolean; hasMultiplier?: boolean; hasSize?: boolean; isPercent?: boolean;
}) {
  const router = useRouter();
  const [rows, setRows] = useState<CalcOption[]>(items);
  const [nLabel, setNLabel] = useState("");
  const [nEmoji, setNEmoji] = useState("");
  const [nMul, setNMul] = useState(isPercent ? 0.3 : 1);
  const [nLen, setNLen] = useState(40);
  const [nWid, setNWid] = useState(40);

  async function upd(id: number, patch: Partial<CalcOption>) {
    setRows((p) => p.map((r) => (r.id === id ? { ...r, ...patch } : r)));
    await fetch("/api/calc-options", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, ...patch }) });
    router.refresh();
  }
  async function add() {
    if (!nLabel.trim()) return;
    const body: Record<string, unknown> = { kind, label: nLabel, sortOrder: rows.length };
    if (hasEmoji) body.emoji = nEmoji;
    if (hasMultiplier) body.multiplier = nMul;
    if (hasSize) { body.lengthMm = nLen; body.widthMm = nWid; }
    const res = await fetch("/api/calc-options", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    if (res.ok) {
      const data = await res.json();
      setRows((p) => [...p, data.option]);
      setNLabel(""); setNEmoji(""); setNMul(isPercent ? 0.3 : 1); setNLen(40); setNWid(40);
      router.refresh();
    }
  }
  async function del(id: number) {
    if (!confirm("Удалить?")) return;
    await fetch(`/api/calc-options?id=${id}`, { method: "DELETE" });
    setRows((p) => p.filter((r) => r.id !== id));
    router.refresh();
  }

  return (
    <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
      <h3 className="text-base font-semibold text-zinc-100">{title}</h3>
      <p className="mb-3 text-xs text-zinc-500">{desc}</p>

      <ul className="mb-4 divide-y divide-zinc-800/50 overflow-hidden rounded-xl border border-zinc-800">
        {rows.length === 0 && <li className="p-3 text-sm text-zinc-500">Пусто — используются значения по умолчанию.</li>}
        {rows.map((r) => (
          <li key={r.id} className="flex flex-wrap items-center gap-2 bg-zinc-900 p-3">
            {hasEmoji && (
              <input className={`${inputCls} w-14 text-center`} value={r.emoji ?? ""} onChange={(e) => setRows((p) => p.map((x) => x.id === r.id ? { ...x, emoji: e.target.value } : x))} onBlur={() => upd(r.id, { emoji: r.emoji })} placeholder="🚗" />
            )}
            <input className={`${inputCls} min-w-[140px] flex-1`} value={r.label} onChange={(e) => setRows((p) => p.map((x) => x.id === r.id ? { ...x, label: e.target.value } : x))} onBlur={() => upd(r.id, { label: r.label })} />
            {hasSize && (
              <>
                <input type="number" className={`${inputCls} w-20`} value={r.lengthMm ?? 0} onChange={(e) => setRows((p) => p.map((x) => x.id === r.id ? { ...x, lengthMm: Number(e.target.value) } : x))} onBlur={() => upd(r.id, { lengthMm: r.lengthMm ?? 40 })} />
                <span className="text-zinc-500">×</span>
                <input type="number" className={`${inputCls} w-20`} value={r.widthMm ?? 0} onChange={(e) => setRows((p) => p.map((x) => x.id === r.id ? { ...x, widthMm: Number(e.target.value) } : x))} onBlur={() => upd(r.id, { widthMm: r.widthMm ?? 40 })} />
                <span className="text-xs text-zinc-500">мм</span>
              </>
            )}
            {hasMultiplier && (
              <div className="flex items-center gap-1">
                <input type="number" step={isPercent ? "0.05" : "0.05"} className={`${inputCls} w-24 text-right`} value={r.multiplier} onChange={(e) => setRows((p) => p.map((x) => x.id === r.id ? { ...x, multiplier: Number(e.target.value) } : x))} onBlur={() => upd(r.id, { multiplier: r.multiplier })} />
                <span className="text-xs text-zinc-500">{isPercent ? `= +${Math.round(r.multiplier * 100)}%` : "×"}</span>
              </div>
            )}
            <button type="button" onClick={() => del(r.id)} className="text-xs text-red-500">Удалить</button>
          </li>
        ))}
      </ul>

      <div className="flex flex-wrap items-center gap-2">
        {hasEmoji && <input className={`${inputCls} w-14 text-center`} value={nEmoji} onChange={(e) => setNEmoji(e.target.value)} placeholder="🚗" />}
        <input className={`${inputCls} min-w-[160px] flex-1`} placeholder="Название" value={nLabel} onChange={(e) => setNLabel(e.target.value)} />
        {hasSize && (
          <>
            <input type="number" className={`${inputCls} w-20`} value={nLen} onChange={(e) => setNLen(Number(e.target.value))} />
            <span className="text-zinc-500">×</span>
            <input type="number" className={`${inputCls} w-20`} value={nWid} onChange={(e) => setNWid(Number(e.target.value))} />
          </>
        )}
        {hasMultiplier && <input type="number" step="0.05" className={`${inputCls} w-24 text-right`} value={nMul} onChange={(e) => setNMul(Number(e.target.value))} />}
        <button type="button" onClick={add} className="rounded-xl bg-zinc-100 px-4 py-2 text-sm font-semibold text-zinc-950">+ Добавить</button>
      </div>
    </section>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone: "ok" | "warn" | "primary" }) {
  const bg =
    tone === "ok"
      ? "bg-emerald-950/50 text-emerald-400"
      : tone === "warn"
      ? "bg-amber-950/50 text-amber-400"
      : "bg-zinc-100 text-zinc-950";
  return (
    <div className={`rounded-xl px-3 py-2 ${bg}`}>
      <p className="text-[11px] font-medium uppercase tracking-wider opacity-80">{label}</p>
      <p className="mt-0.5 text-lg font-bold tabular-nums">{value}</p>
    </div>
  );
}

/* ---------- Коэффициенты ---------- */

type MultKind = "car_class" | "paint_material" | "repair_method";

function MultipliersTab({
  initial,
}: {
  initial: {
    carClasses: CarClass[];
    paintMaterials: PaintMaterial[];
    repairMethods: RepairMethod[];
  };
}) {
  return (
    <div className="space-y-5">
      <MultipliersBlock title="Класс автомобиля" kind="car_class" items={initial.carClasses} description="Наценка за уровень авто (эконом, средний, премиум, люкс)." />
      <MultipliersBlock title="Материал ЛКП" kind="paint_material" items={initial.paintMaterials} description="Глянец, матовая краска, работа по плёнке." />
      <MultipliersBlock title="Метод ремонта" kind="repair_method" items={initial.repairMethods} description="ПДР или под покраску — множитель к расчёту." />
    </div>
  );
}

type MultRow = { id: number; slug: string; label: string; multiplier: number; sortOrder: number; isDefault: boolean };

function MultipliersBlock({
  title,
  kind,
  items,
  description,
}: {
  title: string;
  kind: MultKind;
  items: MultRow[];
  description: string;
}) {
  const router = useRouter();
  const [rows, setRows] = useState<MultRow[]>(items);
  const [newLabel, setNewLabel] = useState("");
  const [newMult, setNewMult] = useState(1);

  async function updateRow(id: number, patch: Partial<MultRow>) {
    setRows((prev) => prev.map((r) => (r.id === id ? { ...r, ...patch } : r)));
    await fetch("/api/multipliers", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kind, id, ...patch }),
    });
    router.refresh();
  }

  async function addRow() {
    if (!newLabel.trim()) return;
    const res = await fetch("/api/multipliers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kind, label: newLabel, multiplier: newMult, sortOrder: rows.length }),
    });
    if (res.ok) {
      const data = await res.json();
      setRows((prev) => [...prev, data.item]);
      setNewLabel("");
      setNewMult(1);
      router.refresh();
    }
  }

  async function removeRow(id: number) {
    if (!confirm("Удалить пункт?")) return;
    await fetch(`/api/multipliers?kind=${kind}&id=${id}`, { method: "DELETE" });
    setRows((prev) => prev.filter((r) => r.id !== id));
    router.refresh();
  }

  return (
    <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
      <div className="mb-3">
        <h3 className="text-base font-semibold text-zinc-100">{title}</h3>
        <p className="text-xs text-zinc-400">{description}</p>
      </div>

      <ul className="mb-4 divide-y divide-slate-100 overflow-hidden rounded-xl border border-zinc-800">
        {rows.length === 0 && <li className="p-3 text-sm text-zinc-400">Пусто. Добавьте первый пункт.</li>}
        {rows.map((r) => (
          <li key={r.id} className="grid gap-2 bg-zinc-900 p-3 sm:grid-cols-[1fr_120px_auto_auto] sm:items-center">
            <input
              className={inputCls}
              value={r.label}
              onChange={(e) => setRows((prev) => prev.map((x) => (x.id === r.id ? { ...x, label: e.target.value } : x)))}
              onBlur={() => updateRow(r.id, { label: r.label })}
            />
            <div className="flex items-center gap-1.5">
              <input
                type="number"
                min={0}
                step="0.05"
                className={`${inputCls} text-right`}
                value={r.multiplier}
                onChange={(e) =>
                  setRows((prev) =>
                    prev.map((x) => (x.id === r.id ? { ...x, multiplier: Math.max(0, Number(e.target.value) || 0) } : x))
                  )
                }
                onBlur={() => updateRow(r.id, { multiplier: r.multiplier })}
              />
              <span className="text-xs text-zinc-500">× к цене</span>
            </div>
            <label className="flex items-center gap-1.5 text-xs text-zinc-400">
              <input type="checkbox" checked={r.isDefault} onChange={(e) => updateRow(r.id, { isDefault: e.target.checked })} />
              по умолчанию
            </label>
            <button type="button" onClick={() => removeRow(r.id)} className="text-xs text-red-500">
              Удалить
            </button>
          </li>
        ))}
      </ul>

      <div className="grid gap-2 sm:grid-cols-[1fr_120px_auto]">
        <input className={inputCls} placeholder="Название нового пункта" value={newLabel} onChange={(e) => setNewLabel(e.target.value)} />
        <input
          type="number"
          min={0}
          step="0.05"
          className={`${inputCls} text-right`}
          value={newMult}
          onChange={(e) => setNewMult(Math.max(0, Number(e.target.value) || 0))}
          placeholder="1.00"
        />
        <button type="button" onClick={addRow} className="rounded-xl bg-zinc-100 px-4 py-2 text-sm font-semibold text-zinc-950">
          + Добавить
        </button>
      </div>
    </section>
  );
}

/* ---------- R&I каталог ---------- */

function RiTab({ initial }: { initial: RiCatalogRow[] }) {
  const router = useRouter();
  const [rows, setRows] = useState(initial);
  const [nLabel, setNLabel] = useState("");
  const [nGroup, setNGroup] = useState("Общее");
  const [nPrice, setNPrice] = useState(500);

  async function upd(id: number, patch: Partial<RiCatalogRow>) {
    setRows((prev) => prev.map((r) => (r.id === id ? { ...r, ...patch } : r)));
    await fetch(`/api/ri-catalog/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(patch),
    });
    router.refresh();
  }
  async function add() {
    if (!nLabel.trim()) return;
    const res = await fetch("/api/ri-catalog", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ label: nLabel, groupName: nGroup, price: nPrice, sortOrder: rows.length }),
    });
    if (res.ok) {
      const data = await res.json();
      setRows((prev) => [...prev, data.item]);
      setNLabel("");
      setNPrice(500);
      router.refresh();
    }
  }
  async function del(id: number) {
    if (!confirm("Удалить?")) return;
    await fetch(`/api/ri-catalog/${id}`, { method: "DELETE" });
    setRows((prev) => prev.filter((r) => r.id !== id));
    router.refresh();
  }

  const groups = Array.from(new Set(rows.map((r) => r.groupName)));

  return (
    <div className="space-y-5">
      <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
        <h3 className="mb-1 text-base font-semibold text-zinc-100">Каталог разбора / сборки (R&I)</h3>
        <p className="mb-4 text-xs text-zinc-400">Эти позиции появятся в калькуляторе. Можно править цены и группы.</p>

        <ul className="mb-4 divide-y divide-slate-100 overflow-hidden rounded-xl border border-zinc-800">
          {rows.length === 0 && <li className="p-3 text-sm text-zinc-400">Пусто.</li>}
          {rows.map((r) => (
            <li key={r.id} className="grid gap-2 bg-zinc-900 p-3 sm:grid-cols-[1fr_140px_120px_auto] sm:items-center">
              <input className={inputCls} value={r.label} onChange={(e) => setRows((prev) => prev.map((x) => (x.id === r.id ? { ...x, label: e.target.value } : x)))} onBlur={() => upd(r.id, { label: r.label })} />
              <input list="ri-groups" className={inputCls} value={r.groupName} onChange={(e) => setRows((prev) => prev.map((x) => (x.id === r.id ? { ...x, groupName: e.target.value } : x)))} onBlur={() => upd(r.id, { groupName: r.groupName })} />
              <div className="flex items-center gap-1">
                <input type="number" min={0} className={`${inputCls} text-right`} value={r.price} onChange={(e) => setRows((prev) => prev.map((x) => (x.id === r.id ? { ...x, price: Math.max(0, Number(e.target.value) || 0) } : x)))} onBlur={() => upd(r.id, { price: r.price })} />
                <span className="text-xs text-zinc-500">₽</span>
              </div>
              <button type="button" onClick={() => del(r.id)} className="text-xs text-red-500">Удалить</button>
            </li>
          ))}
        </ul>
        <datalist id="ri-groups">
          {groups.map((g) => <option key={g} value={g} />)}
        </datalist>

        <div className="grid gap-2 sm:grid-cols-[1fr_140px_120px_auto]">
          <input className={inputCls} placeholder="Что снимаем (например, Обшивка двери)" value={nLabel} onChange={(e) => setNLabel(e.target.value)} />
          <input list="ri-groups" className={inputCls} placeholder="Группа" value={nGroup} onChange={(e) => setNGroup(e.target.value)} />
          <input type="number" min={0} className={`${inputCls} text-right`} value={nPrice} onChange={(e) => setNPrice(Math.max(0, Number(e.target.value) || 0))} />
          <button type="button" onClick={add} className="rounded-xl bg-zinc-100 px-4 py-2 text-sm font-semibold text-zinc-950">+ Добавить</button>
        </div>
      </section>
    </div>
  );
}

/* ---------- Доп услуги ---------- */

function ExtrasTab({ initial }: { initial: ExtraServiceRow[] }) {
  const router = useRouter();
  const [rows, setRows] = useState(initial);
  const [nLabel, setNLabel] = useState("");
  const [nPrice, setNPrice] = useState(1000);
  const [nDesc, setNDesc] = useState("");

  async function upd(id: number, patch: Partial<ExtraServiceRow>) {
    setRows((prev) => prev.map((r) => (r.id === id ? { ...r, ...patch } : r)));
    await fetch(`/api/extra-services/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(patch),
    });
    router.refresh();
  }
  async function add() {
    if (!nLabel.trim()) return;
    const res = await fetch("/api/extra-services", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ label: nLabel, price: nPrice, description: nDesc, sortOrder: rows.length }),
    });
    if (res.ok) {
      const data = await res.json();
      setRows((prev) => [...prev, data.item]);
      setNLabel("");
      setNDesc("");
      setNPrice(1000);
      router.refresh();
    }
  }
  async function del(id: number) {
    if (!confirm("Удалить услугу?")) return;
    await fetch(`/api/extra-services/${id}`, { method: "DELETE" });
    setRows((prev) => prev.filter((r) => r.id !== id));
    router.refresh();
  }

  return (
    <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
      <h3 className="mb-1 text-base font-semibold text-zinc-100">Дополнительные услуги</h3>
      <p className="mb-4 text-xs text-zinc-400">Полировка повреждения, керамика, свои услуги — с ценой.</p>

      <ul className="mb-4 divide-y divide-slate-100 overflow-hidden rounded-xl border border-zinc-800">
        {rows.length === 0 && <li className="p-3 text-sm text-zinc-400">Пусто.</li>}
        {rows.map((r) => (
          <li key={r.id} className="grid gap-2 bg-zinc-900 p-3 sm:grid-cols-[1fr_1.5fr_120px_auto] sm:items-center">
            <input className={inputCls} value={r.label} onChange={(e) => setRows((prev) => prev.map((x) => (x.id === r.id ? { ...x, label: e.target.value } : x)))} onBlur={() => upd(r.id, { label: r.label })} />
            <input className={inputCls} value={r.description ?? ""} placeholder="Описание (для калькулятора)" onChange={(e) => setRows((prev) => prev.map((x) => (x.id === r.id ? { ...x, description: e.target.value } : x)))} onBlur={() => upd(r.id, { description: r.description })} />
            <div className="flex items-center gap-1">
              <input type="number" min={0} className={`${inputCls} text-right`} value={r.price} onChange={(e) => setRows((prev) => prev.map((x) => (x.id === r.id ? { ...x, price: Math.max(0, Number(e.target.value) || 0) } : x)))} onBlur={() => upd(r.id, { price: r.price })} />
              <span className="text-xs text-zinc-500">₽</span>
            </div>
            <button type="button" onClick={() => del(r.id)} className="text-xs text-red-500">Удалить</button>
          </li>
        ))}
      </ul>

      <div className="grid gap-2 sm:grid-cols-[1fr_1.5fr_120px_auto]">
        <input className={inputCls} placeholder="Название (Полировка повреждения)" value={nLabel} onChange={(e) => setNLabel(e.target.value)} />
        <input className={inputCls} placeholder="Описание (необязательно)" value={nDesc} onChange={(e) => setNDesc(e.target.value)} />
        <input type="number" min={0} className={`${inputCls} text-right`} value={nPrice} onChange={(e) => setNPrice(Math.max(0, Number(e.target.value) || 0))} />
        <button type="button" onClick={add} className="rounded-xl bg-zinc-100 px-4 py-2 text-sm font-semibold text-zinc-950">+ Добавить</button>
      </div>
    </section>
  );
}
