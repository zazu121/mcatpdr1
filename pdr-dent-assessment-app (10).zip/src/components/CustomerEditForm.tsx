"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Field, inputCls } from "@/components/ui";

export function CustomerEditForm({
  customer,
}: {
  customer: {
    id: number;
    name: string;
    phone: string | null;
    email: string | null;
    notes: string | null;
  };
}) {
  const router = useRouter();
  const [name, setName] = useState(customer.name);
  const [phone, setPhone] = useState(customer.phone ?? "");
  const [email, setEmail] = useState(customer.email ?? "");
  const [notes, setNotes] = useState(customer.notes ?? "");
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setMsg(null);
    const res = await fetch(`/api/customers/${customer.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, phone, email, notes }),
    });
    setLoading(false);
    if (res.ok) {
      setMsg("Сохранено");
      router.refresh();
    } else setMsg("Ошибка сохранения");
  }

  async function remove() {
    if (!confirm("Удалить клиента?")) return;
    const res = await fetch(`/api/customers/${customer.id}`, { method: "DELETE" });
    if (res.ok) router.push("/customers");
  }

  return (
    <form onSubmit={save} className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
      <h2 className="mb-3 text-base font-semibold text-zinc-100">Данные клиента</h2>
      <div className="space-y-3">
        <Field label="Имя">
          <input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Телефон">
          <input className={inputCls} value={phone} onChange={(e) => setPhone(e.target.value)} />
        </Field>
        <Field label="Email">
          <input className={inputCls} value={email} onChange={(e) => setEmail(e.target.value)} />
        </Field>
        <Field label="Заметка">
          <textarea className={`${inputCls} min-h-[72px]`} value={notes} onChange={(e) => setNotes(e.target.value)} />
        </Field>
        {msg && <p className="text-sm text-zinc-400">{msg}</p>}
        <div className="flex gap-2">
          <button type="submit" disabled={loading} className="rounded-xl bg-zinc-100 px-4 py-2 text-sm font-semibold text-zinc-950 disabled:opacity-60">
            {loading ? "…" : "Сохранить"}
          </button>
          <button type="button" onClick={remove} className="rounded-xl border border-rose-200 px-4 py-2 text-sm font-medium text-red-500">
            Удалить
          </button>
        </div>
      </div>
    </form>
  );
}
