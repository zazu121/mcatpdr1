"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import {
  PANELS,
  DENT_TYPES,
  DENT_DEPTHS,
  SIZE_PRESETS,
  BRANDS,
  calculateDent,
  calculateJobTotals,
  formatPrice,
  formatSize,
  panelLabel,
  panelEmoji,
  wallClockISO,
  type DentInput,
} from "@/lib/pdr";
import { Field, inputCls } from "@/components/ui";
import type {
  CarClass,
  PaintMaterial,
  RepairMethod,
  RiCatalogRow,
  ExtraServiceRow,
  JobPhoto,
} from "@/db/schema";

export type DentDraft = DentInput & { notes: string; key: string };
export type RiDraft = { key: string; itemId: string; label: string; panel: string; price: number; quantity: number; notes: string; };
export type ExtraDraft = { key: string; serviceId: number | null; label: string; price: number; quantity: number; notes: string; };

function uid() { return Math.random().toString(36).slice(2, 10); }

function emptyDent(panel = "hood"): DentDraft {
  return { key: uid(), panel, dentType: "round", lengthMm: 40, widthMm: 40, depth: "shallow", quantity: 1, isAluminum: false, onBodyLine: false, gluePull: false, hardAccess: false, notes: "" };
}

type Initial = {
  id?: number;
  customerId?: number;
  vehicleId?: number;
  customerName?: string | null;
  phone?: string | null;
  vehicleMake?: string | null;
  vehicleModel?: string | null;
  vehicleYear?: number | null;
  vehicleColor?: string | null;
  licensePlate?: string | null;
  scheduledAt?: string | Date | null;
  notes?: string | null;
  internalNotes?: string | null;
  discount?: number;
  paidAmount?: number;
  status?: string;
  carClassSlug?: string | null;
  paintMaterialSlug?: string | null;
  repairMethodSlug?: string | null;
  markupPercent?: number;
  dents?: Array<{ panel: string; dentType: string; lengthMm: number; widthMm: number; depth: string; quantity: number; isAluminum: boolean; onBodyLine: boolean; gluePull: boolean; hardAccess: boolean; notes?: string | null; }>;
  riItems?: Array<{ itemId: string; label: string; panel?: string | null; price: number; quantity: number; notes?: string | null; }>;
  extras?: Array<{ serviceId?: number | null; label: string; price: number; quantity: number; notes?: string | null; }>;
  photos?: JobPhoto[];
};

type CalcOpt = {
  id: number; kind: string; slug: string; label: string; emoji: string | null;
  multiplier: number; lengthMm: number | null; widthMm: number | null; groupName: string | null;
  sortOrder: number; isActive: boolean;
};

type Reference = {
  markupPercent: number;
  markupLabel: string;
  carClasses: CarClass[];
  paintMaterials: PaintMaterial[];
  repairMethods: RepairMethod[];
  riCatalog: RiCatalogRow[];
  extraServices: ExtraServiceRow[];
  panels?: CalcOpt[];
  sizePresets?: CalcOpt[];
  dentTypes?: CalcOpt[];
  depths?: CalcOpt[];
  surcharges?: CalcOpt[];
  ratePerCm2?: number;
  minDentPrice?: number;
};

export function JobForm({ initial, mode = "create", reference }: { initial?: Initial; mode?: "create" | "edit"; reference: Reference; }) {
  const router = useRouter();

  const defaultCar = reference.carClasses.find((c) => c.isDefault) ?? reference.carClasses[0];
  const defaultPaint = reference.paintMaterials.find((p) => p.isDefault) ?? reference.paintMaterials[0];
  const defaultMethod = reference.repairMethods.find((m) => m.isDefault) ?? reference.repairMethods[0];

  const [customerId, setCustomerId] = useState(initial?.customerId);
  const [vehicleId, setVehicleId] = useState(initial?.vehicleId);
  const [customerName, setCustomerName] = useState(initial?.customerName ?? "");
  const [phone, setPhone] = useState(initial?.phone ?? "");
  const [vehicleMake, setVehicleMake] = useState(initial?.vehicleMake ?? "");
  const [vehicleModel, setVehicleModel] = useState(initial?.vehicleModel ?? "");
  const [vehicleYear, setVehicleYear] = useState(initial?.vehicleYear ? String(initial.vehicleYear) : "");
  const [vehicleColor, setVehicleColor] = useState(initial?.vehicleColor ?? "");
  const [licensePlate, setLicensePlate] = useState(initial?.licensePlate ?? "");
  
  // Дата убрана из главной формы, используется только для отправки
  const [scheduledAt, setScheduledAt] = useState<Date | null>(initial?.scheduledAt ? new Date(initial.scheduledAt) : null);
  
  const [notes, setNotes] = useState(initial?.notes ?? "");
  const [internalNotes, setInternalNotes] = useState(initial?.internalNotes ?? "");
  const [discount, setDiscount] = useState(initial?.discount ?? 0);
  const [paidAmount, setPaidAmount] = useState(initial?.paidAmount ?? 0);
  const [markupPercent, setMarkupPercent] = useState(initial?.markupPercent ?? reference.markupPercent);

  const [carClassSlug, setCarClassSlug] = useState(initial?.carClassSlug ?? defaultCar?.slug ?? "");
  const [paintMaterialSlug, setPaintMaterialSlug] = useState(initial?.paintMaterialSlug ?? defaultPaint?.slug ?? "");
  const [repairMethodSlug, setRepairMethodSlug] = useState(initial?.repairMethodSlug ?? defaultMethod?.slug ?? "");

  const carMul = reference.carClasses.find((c) => c.slug === carClassSlug)?.multiplier ?? 1;
  const paintMul = reference.paintMaterials.find((p) => p.slug === paintMaterialSlug)?.multiplier ?? 1;
  const methodMul = reference.repairMethods.find((r) => r.slug === repairMethodSlug)?.multiplier ?? 1;

  // Эффективные справочники: кастомные из настроек ИЛИ встроенные по умолчанию
  const effPanels = (reference.panels?.length ? reference.panels.map((p) => ({ id: p.slug, label: p.label, emoji: p.emoji ?? "🔧", accessMultiplier: p.multiplier })) : PANELS);
  const effTypes = (reference.dentTypes?.length ? reference.dentTypes.map((t) => ({ id: t.slug, label: t.label, desc: "", multiplier: t.multiplier })) : DENT_TYPES);
  const effDepths = (reference.depths?.length ? reference.depths.map((t) => ({ id: t.slug, label: t.label, desc: "", multiplier: t.multiplier })) : DENT_DEPTHS);
  const effPresets = (reference.sizePresets?.length ? reference.sizePresets.map((s) => ({ id: s.slug, label: s.label, lengthMm: s.lengthMm ?? 40, widthMm: s.widthMm ?? 40 })) : SIZE_PRESETS);
  const effSurcharges = (reference.surcharges?.length ? reference.surcharges.map((s) => ({ id: s.slug, label: s.label, pct: s.multiplier })) : [
    { id: "isAluminum", label: "Алюминий", pct: 0.3 },
    { id: "onBodyLine", label: "На ребре", pct: 0.25 },
    { id: "gluePull", label: "Glue pull", pct: 0.2 },
    { id: "hardAccess", label: "Сложный доступ", pct: 0.35 },
  ]);

  const dentConfig = {
    ratePerCm2: reference.ratePerCm2,
    minDentPrice: reference.minDentPrice,
    panels: effPanels.map((p) => ({ id: p.id, multiplier: p.accessMultiplier })),
    dentTypes: effTypes.map((t) => ({ id: t.id, multiplier: t.multiplier })),
    depths: effDepths.map((d) => ({ id: d.id, multiplier: d.multiplier })),
  };

  // Хелперы для лейблов/эмодзи с учётом кастомных панелей
  const panelLabelEff = (id: string) => effPanels.find((p) => p.id === id)?.label ?? panelLabel(id);
  const panelEmojiEff = (id: string) => effPanels.find((p) => p.id === id)?.emoji ?? panelEmoji(id);

  const [dents, setDents] = useState<DentDraft[]>(initial?.dents?.length ? initial.dents.map((d) => ({ ...d, notes: d.notes ?? "", key: uid() })) : [emptyDent()]);
  const [riItems, setRiItems] = useState<RiDraft[]>(initial?.riItems?.length ? initial.riItems.map((r) => ({ key: uid(), itemId: r.itemId, label: r.label, panel: r.panel ?? "", price: r.price, quantity: r.quantity, notes: r.notes ?? "" })) : []);
  const [extras, setExtras] = useState<ExtraDraft[]>(initial?.extras?.length ? initial.extras.map((x) => ({ key: uid(), serviceId: x.serviceId ?? null, label: x.label, price: x.price, quantity: x.quantity, notes: x.notes ?? "" })) : []);

  const [activeDent, setActiveDent] = useState(0);
  const [showRiCatalog, setShowRiCatalog] = useState(false);
  const [riFilter, setRiFilter] = useState("");
  const [showExtraCatalog, setShowExtraCatalog] = useState(false);
  
  // Управление календарём
  const [showCalendar, setShowCalendar] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const surchargePct = {
    aluminum: effSurcharges.find((s) => s.id === "isAluminum")?.pct,
    bodyLine: effSurcharges.find((s) => s.id === "onBodyLine")?.pct,
    gluePull: effSurcharges.find((s) => s.id === "gluePull")?.pct,
    hardAccess: effSurcharges.find((s) => s.id === "hardAccess")?.pct,
  };
  const dentCalcs = useMemo(
    () => dents.map((d) => calculateDent({ ...d, extraMultipliers: [carMul, paintMul, methodMul] }, { ...dentConfig, surchargePct })),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [dents, carMul, paintMul, methodMul]
  );
  const riLines = useMemo(() => riItems.map((r) => ({ ...r, lineTotal: r.price * Math.max(1, r.quantity) })), [riItems]);
  const extraLines = useMemo(() => extras.map((r) => ({ ...r, lineTotal: r.price * Math.max(1, r.quantity) })), [extras]);
  const totals = useMemo(() => calculateJobTotals(dentCalcs.map((c) => ({ lineTotal: c.lineTotal })), riLines.map((r) => ({ lineTotal: r.lineTotal })), extraLines.map((r) => ({ lineTotal: r.lineTotal })), discount, markupPercent), [dentCalcs, riLines, extraLines, discount, markupPercent]);

  const [photos, setPhotos] = useState<JobPhoto[]>(initial?.photos ?? []);
  const [pendingFiles, setPendingFiles] = useState<File[]>([]);
  const [previewUrls, setPreviewUrls] = useState<string[]>([]);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const urls = pendingFiles.map((f) => URL.createObjectURL(f));
    setPreviewUrls(urls);
    return () => urls.forEach((u) => URL.revokeObjectURL(u));
  }, [pendingFiles]);

  function addFiles(files: FileList | null) {
    if (!files) return;
    const arr = Array.from(files).filter((f) => f.type.startsWith("image/"));
    setPendingFiles((prev) => [...prev, ...arr]);
  }
  async function removeExistingPhoto(id: number) {
    await fetch(`/api/photos?id=${id}`, { method: "DELETE" });
    setPhotos((prev) => prev.filter((p) => p.id !== id));
    router.refresh();
  }
  function updateDent(idx: number, patch: Partial<DentDraft>) {
    setDents((prev) => prev.map((d, i) => (i === idx ? { ...d, ...patch } : d)));
  }
  function removeDent(idx: number) {
    setDents((prev) => {
      if (prev.length <= 1) return prev;
      const next = prev.filter((_, i) => i !== idx);
      setActiveDent((a) => Math.min(a, next.length - 1));
      return next;
    });
  }

  async function uploadPhotos(jobId: number) {
    for (const f of pendingFiles) {
      const fd = new FormData();
      fd.append("jobId", String(jobId));
      fd.append("file", f);
      try { await fetch("/api/photos", { method: "POST", body: fd }); } catch (e) { console.error(e); }
    }
  }

  // Сначала показываем календарь (если нажат Submit)
  function promptSubmit() {
    setShowCalendar(true);
  }

  // Фактическая отправка
  async function executeSubmit(finalDateIso: string) {
    setSubmitting(true);
    setError(null);
    const payload = {
      customerId, vehicleId,
      customerName, phone, vehicleMake: vehicleMake || "Не указана", vehicleModel,
      vehicleYear: vehicleYear ? Number(vehicleYear) : null, vehicleColor, licensePlate,
      scheduledAt: finalDateIso,
      notes, internalNotes, discount, paidAmount, markupPercent,
      carClassSlug, carClassMult: carMul, paintMaterialSlug, paintMaterialMult: paintMul,
      repairMethodSlug, repairMethodMult: methodMul,
      dents: dents.map(({ key: _k, ...d }) => d),
      riItems: riItems.map(({ key: _k, ...r }) => r),
      extras: extras.map(({ key: _k, ...r }) => r),
      status: initial?.status ?? "scheduled",
    };

    try {
      const url = mode === "edit" && initial?.id ? `/api/jobs/${initial.id}` : "/api/jobs";
      const res = await fetch(url, { method: mode === "edit" ? "PATCH" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      if (!res.ok) throw new Error("fail");
      const data = await res.json();
      const jobId = data.job?.id ?? initial?.id;
      if (jobId && pendingFiles.length) await uploadPhotos(jobId);
      router.push(`/journal/${jobId}`);
      router.refresh();
    } catch {
      setError("Не удалось сохранить. Проверьте данные и попробуйте снова.");
      setSubmitting(false);
      setShowCalendar(false);
    }
  }

  const d = dents[activeDent] ?? dents[0];
  const calc = dentCalcs[activeDent] ?? dentCalcs[0];

  const filteredRi = reference.riCatalog.filter((item) => {
    if (!riFilter) return true;
    const q = riFilter.toLowerCase();
    return item.label.toLowerCase().includes(q) || item.groupName.toLowerCase().includes(q);
  });
  const riGroups = useMemo(() => {
    const map = new Map<string, RiCatalogRow[]>();
    for (const item of filteredRi) {
      const list = map.get(item.groupName) ?? [];
      list.push(item);
      map.set(item.groupName, list);
    }
    return Array.from(map.entries());
  }, [filteredRi]);

  return (
    <>
    <div className="grid gap-6 xl:grid-cols-[1fr_360px]">
      <div className="space-y-5">
        <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-md">
          <h2 className="mb-4 text-base font-semibold text-zinc-100">Клиент и автомобиль</h2>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <Field label="Клиент">
              <input className={inputCls} value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder="Иван Петров" />
            </Field>
            <Field label="Телефон">
              <input className={inputCls} value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+7 (900) 123-45-67" />
            </Field>
            <Field label="Марка">
              <input list="brands" className={inputCls} value={vehicleMake} onChange={(e) => setVehicleMake(e.target.value)} placeholder="Toyota" />
              <datalist id="brands">{BRANDS.map((b) => <option key={b} value={b} />)}</datalist>
            </Field>
            <Field label="Модель">
              <input className={inputCls} value={vehicleModel} onChange={(e) => setVehicleModel(e.target.value)} placeholder="Camry" />
            </Field>
            <Field label="Год">
              <input className={inputCls} value={vehicleYear} onChange={(e) => setVehicleYear(e.target.value.replace(/\D/g, "").slice(0, 4))} placeholder="2021" inputMode="numeric" />
            </Field>
            <Field label="Цвет">
              <input className={inputCls} value={vehicleColor} onChange={(e) => setVehicleColor(e.target.value)} placeholder="Белый" />
            </Field>
            <Field label="Гос. номер">
              <input className={`${inputCls} uppercase`} value={licensePlate} onChange={(e) => setLicensePlate(e.target.value.toUpperCase())} placeholder="А123ВС 77" />
            </Field>
            <Field label="Оплачено, ₽ (аванс)">
              <input className={inputCls} value={paidAmount || ""} onChange={(e) => setPaidAmount(Math.max(0, Number(e.target.value.replace(/\D/g, "")) || 0))} inputMode="numeric" placeholder="0" />
            </Field>
          </div>
        </section>

        <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-md">
          <h2 className="mb-4 text-base font-semibold text-zinc-100">Параметры ремонта</h2>
          <div className="space-y-4">
            <ChipGroup
              label="Класс автомобиля"
              options={reference.carClasses.map((c) => ({ id: c.slug, label: c.label, hint: c.multiplier === 1 ? "баз." : `×${c.multiplier.toFixed(2)}` }))}
              value={carClassSlug} onChange={setCarClassSlug}
            />
            <ChipGroup
              label="Материал ЛКП"
              options={reference.paintMaterials.map((c) => ({ id: c.slug, label: c.label, hint: c.multiplier === 1 ? "баз." : `×${c.multiplier.toFixed(2)}` }))}
              value={paintMaterialSlug} onChange={setPaintMaterialSlug}
            />
            <ChipGroup
              label="Метод ремонта"
              options={reference.repairMethods.map((c) => ({ id: c.slug, label: c.label, hint: c.multiplier === 1 ? "баз." : `×${c.multiplier.toFixed(2)}` }))}
              value={repairMethodSlug} onChange={setRepairMethodSlug}
            />
          </div>
        </section>

        <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-md">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-base font-semibold text-zinc-100">Вмятины · {dents.length}</h2>
            <button type="button" onClick={() => setDents((p) => { const n = [...p, emptyDent(p[activeDent]?.panel ?? "hood")]; setActiveDent(n.length-1); return n;})} className="rounded-lg bg-zinc-100 px-3 py-1.5 text-xs font-semibold text-zinc-950">
              + Добавить вмятину
            </button>
          </div>

          <div className="mb-4 flex flex-wrap gap-2">
            {dents.map((item, idx) => {
              const c = dentCalcs[idx];
              const active = idx === activeDent;
              return (
                <button
                  key={item.key}
                  type="button"
                  onClick={() => setActiveDent(idx)}
                  className={`rounded-xl border px-3 py-2 text-left transition-all ${
                    active ? "border-red-500 bg-red-950/20 ring-2 ring-red-500/20" : "border-zinc-800 bg-zinc-900 hover:border-zinc-700"
                  }`}
                >
                  <div className="flex items-center gap-2 text-xs font-semibold text-zinc-200">
                    <span>{panelEmojiEff(item.panel)}</span>
                    <span>{panelLabelEff(item.panel)}</span>
                  </div>
                  <div className="mt-0.5 text-[11px] text-zinc-400">
                    {formatSize(item.lengthMm, item.widthMm)} · {formatPrice(c.lineTotal)}
                  </div>
                </button>
              );
            })}
          </div>

          {d && calc && (
            <div className="space-y-5 rounded-xl bg-zinc-950 p-4">
              <div>
                <p className="mb-2 text-sm font-medium text-zinc-300">Элемент кузова</p>
                <div className="flex flex-wrap gap-1.5">
                  {effPanels.map((p) => {
                    const active = d.panel === p.id;
                    return (
                      <button key={p.id} type="button" onClick={() => updateDent(activeDent, { panel: p.id })}
                        className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-xs font-medium ${
                          active ? "border-red-500 bg-red-600 text-zinc-50" : "border-zinc-800 bg-zinc-900 text-zinc-400 hover:border-zinc-700"
                        }`}
                      >
                        <span>{p.emoji}</span>{p.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                  <p className="text-sm font-medium text-zinc-300">Размер вмятины</p>
                  <span className="text-xs text-zinc-400">{formatSize(d.lengthMm, d.widthMm)} · {calc.areaCm2} см²</span>
                </div>
                <div className="mb-2 flex flex-wrap gap-1.5">
                  {effPresets.map((s) => (
                    <button key={s.id} type="button" onClick={() => updateDent(activeDent, { lengthMm: s.lengthMm, widthMm: s.widthMm })}
                      className="rounded-lg border border-zinc-800 bg-zinc-900 px-2.5 py-1 text-xs font-medium text-zinc-400 hover:border-red-500 hover:text-red-500"
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                  <Field label="Длина, мм">
                    <input type="number" min={5} max={1000} className={inputCls} value={d.lengthMm} onChange={(e) => updateDent(activeDent, { lengthMm: Math.max(5, Number(e.target.value) || 5) })} />
                  </Field>
                  <Field label="Ширина, мм">
                    <input type="number" min={5} max={1000} className={inputCls} value={d.widthMm} onChange={(e) => updateDent(activeDent, { widthMm: Math.max(5, Number(e.target.value) || 5) })} />
                  </Field>
                  <Field label="Кол-во">
                    <div className="flex overflow-hidden rounded-xl border border-zinc-800 bg-zinc-900">
                      <button type="button" className="grid h-[42px] w-10 place-items-center text-lg text-zinc-400" onClick={() => updateDent(activeDent, { quantity: Math.max(1, d.quantity - 1) })}>−</button>
                      <input className="h-[42px] w-full border-x border-zinc-800 bg-transparent text-center text-sm font-semibold outline-none" value={d.quantity} onChange={(e) => updateDent(activeDent, { quantity: Math.max(1, Number(e.target.value.replace(/\D/g, "")) || 1) })} />
                      <button type="button" className="grid h-[42px] w-10 place-items-center text-lg text-zinc-400" onClick={() => updateDent(activeDent, { quantity: d.quantity + 1 })}>+</button>
                    </div>
                  </Field>
                  <div className="flex flex-col justify-end">
                    <div className="rounded-xl bg-zinc-900 px-3 py-2.5 text-center ring-1 ring-zinc-800">
                      <p className="text-[10px] uppercase tracking-wider text-zinc-500">Строка</p>
                      <p className="text-sm font-bold text-zinc-100">{formatPrice(calc.lineTotal)}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid gap-4 lg:grid-cols-2">
                <div>
                  <p className="mb-2 text-sm font-medium text-zinc-300">Тип вмятины</p>
                  <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
                    {effTypes.map((t) => {
                      const active = d.dentType === t.id;
                      return (
                        <button key={t.id} type="button" onClick={() => updateDent(activeDent, { dentType: t.id })}
                          className={`rounded-xl border p-2.5 text-left ${active ? "border-red-500 bg-red-950/20" : "border-zinc-800 bg-zinc-900 hover:border-zinc-700"}`}
                        >
                          <p className={`text-xs font-semibold ${active ? "text-red-400" : "text-zinc-200"}`}>{t.label}</p>
                          <p className="text-[11px] text-zinc-400">{t.desc}</p>
                        </button>
                      );
                    })}
                  </div>
                </div>
                <div>
                  <p className="mb-2 text-sm font-medium text-zinc-300">Глубина</p>
                  <div className="space-y-1.5">
                    {effDepths.map((t) => {
                      const active = d.depth === t.id;
                      return (
                        <button key={t.id} type="button" onClick={() => updateDent(activeDent, { depth: t.id })}
                          className={`flex w-full items-center justify-between rounded-xl border p-2.5 text-left ${active ? "border-red-500 bg-red-950/20" : "border-zinc-800 bg-zinc-900 hover:border-zinc-700"}`}
                        >
                          <div>
                            <p className={`text-xs font-semibold ${active ? "text-red-400" : "text-zinc-200"}`}>{t.label}</p>
                            <p className="text-[11px] text-zinc-400">{t.desc}</p>
                          </div>
                          <span className="text-xs text-zinc-500">×{t.multiplier}</span>
                        </button>
                      );
                    })}
                  </div>
                  <div className="mt-3 grid grid-cols-2 gap-2">
                    {effSurcharges.map((sc) => {
                      const key = sc.id as "isAluminum" | "onBodyLine" | "gluePull" | "hardAccess";
                      const on = Boolean(d[key]);
                      return (
                        <button key={sc.id} type="button" onClick={() => updateDent(activeDent, { [key]: !on })}
                          className={`rounded-xl border px-3 py-2 text-left text-xs font-medium ${
                            on ? "border-amber-900 bg-amber-950/30 text-amber-400" : "border-zinc-800 bg-zinc-900 text-zinc-400"
                          }`}
                        >
                          {sc.label} <span className="text-[10px] opacity-70">+{Math.round(sc.pct * 100)}%</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              <Field label="Заметка по вмятине">
                <input className={inputCls} value={d.notes} onChange={(e) => updateDent(activeDent, { notes: e.target.value })} placeholder="На ребре…" />
              </Field>

              <div className="rounded-xl border border-zinc-800 bg-zinc-900 p-3 text-xs">
                <p className="mb-2 font-semibold text-zinc-300">Как посчитано</p>
                <div className="grid gap-1 text-zinc-400 sm:grid-cols-2">
                  <div className="flex justify-between gap-2"><span>Площадь</span><span>{calc.areaCm2} см² × {calc.sizeFactor}</span></div>
                  <div className="flex justify-between gap-2"><span>База</span><span>{formatPrice(calc.base)}</span></div>
                  <div className="flex justify-between gap-2"><span>Тип</span><span>×{calc.typeMultiplier}</span></div>
                  <div className="flex justify-between gap-2"><span>Доступ панели</span><span>×{calc.accessMultiplier}</span></div>
                  <div className="flex justify-between gap-2"><span>Глубина</span><span>×{calc.depthMultiplier}</span></div>
                  {calc.extraMultiplier !== 1 && (
                    <div className="flex justify-between gap-2 text-red-400"><span>Класс + ЛКП + метод</span><span>×{calc.extraMultiplier}</span></div>
                  )}
                  {calc.surcharges.map((s) => (
                    <div key={s.key} className="flex justify-between gap-2 text-amber-400"><span>{s.label}</span><span>+{Math.round(s.pct * 100)}%</span></div>
                  ))}
                  <div className="flex justify-between gap-2 font-semibold text-zinc-100 sm:col-span-2">
                    <span>Итого × {calc.quantity}</span>
                    <span>{formatPrice(calc.unitPrice)} × {calc.quantity} = {formatPrice(calc.lineTotal)}</span>
                  </div>
                </div>
              </div>

              {dents.length > 1 && (
                <button type="button" onClick={() => removeDent(activeDent)} className="text-xs font-medium text-red-500 hover:text-red-400">
                  Удалить эту вмятину
                </button>
              )}
            </div>
          )}
        </section>

        <LineSection
          title="Разбор / сборка (R&I)"
          subtitle="Обшивки, фары, бамперы"
          count={riItems.length}
          total={totals.riTotal}
          catalogOpen={showRiCatalog}
          onToggleCatalog={() => setShowRiCatalog((v) => !v)}
          onAddCustom={() => setRiItems((p) => [...p, { key: uid(), itemId: "custom", label: "Свой разбор", panel: "", price: 500, quantity: 1, notes: "" }])}
          catalogContent={
            <>
              <input className={`${inputCls} mb-3`} placeholder="Поиск…" value={riFilter} onChange={(e) => setRiFilter(e.target.value)} />
              <div className="max-h-64 space-y-3 overflow-y-auto pr-1">
                {riGroups.map(([group, items]) => (
                  <div key={group}>
                    <p className="mb-1.5 text-[11px] font-bold uppercase tracking-wider text-zinc-500">{group}</p>
                    <div className="flex flex-wrap gap-1.5">
                      {items.map((item) => (
                        <button key={item.id} type="button" onClick={() => { setRiItems(p => [...p, { key: uid(), itemId: String(item.id), label: item.label, panel: item.panel ?? "", price: item.price, quantity: 1, notes: "" }]); setShowRiCatalog(false); }}
                          className="rounded-lg border border-zinc-800 bg-zinc-900 px-2.5 py-1.5 text-left text-xs hover:border-red-500"
                        >
                          <span className="font-medium text-zinc-200">{item.label}</span>
                          <span className="ml-2 text-zinc-500">{item.price > 0 ? formatPrice(item.price) : "своё"}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </>
          }
          items={
            <ul className="divide-y divide-zinc-800/50 overflow-hidden rounded-xl border border-zinc-800">
              {riItems.map((r, idx) => (
                <li key={r.key} className="grid gap-2 bg-zinc-900 p-3 sm:grid-cols-[1fr_100px_80px_auto] sm:items-center">
                  <input className={inputCls} value={r.label} onChange={(e) => setRiItems((prev) => prev.map((x, i) => (i === idx ? { ...x, label: e.target.value } : x)))} />
                  <input className={inputCls} inputMode="numeric" value={r.price} onChange={(e) => setRiItems((prev) => prev.map((x, i) => (i === idx ? { ...x, price: Math.max(0, Number(e.target.value.replace(/\D/g, "")) || 0) } : x)))} placeholder="Цена" />
                  <input className={inputCls} inputMode="numeric" value={r.quantity} onChange={(e) => setRiItems((prev) => prev.map((x, i) => (i === idx ? { ...x, quantity: Math.max(1, Number(e.target.value.replace(/\D/g, "")) || 1) } : x)))} />
                  <div className="flex items-center justify-between gap-3 sm:justify-end">
                    <span className="text-sm font-semibold tabular-nums text-zinc-100">{formatPrice(r.price * r.quantity)}</span>
                    <button type="button" onClick={() => setRiItems((prev) => prev.filter((_, i) => i !== idx))} className="text-xs text-red-500">✕</button>
                  </div>
                </li>
              ))}
            </ul>
          }
        />

        <LineSection
          title="Дополнительные услуги"
          subtitle="Полировка, керамика"
          count={extras.length}
          total={totals.extrasTotal}
          catalogOpen={showExtraCatalog}
          onToggleCatalog={() => setShowExtraCatalog((v) => !v)}
          onAddCustom={() => setExtras((p) => [...p, { key: uid(), serviceId: null, label: "Своя услуга", price: 500, quantity: 1, notes: "" }])}
          catalogContent={
            <div className="max-h-64 space-y-1.5 overflow-y-auto pr-1">
              {reference.extraServices.map((item) => (
                <button key={item.id} type="button" onClick={() => { setExtras(p => [...p, { key: uid(), serviceId: item.id, label: item.label, price: item.price, quantity: 1, notes: "" }]); setShowExtraCatalog(false); }}
                  className="flex w-full items-center justify-between rounded-lg border border-zinc-800 bg-zinc-900 px-3 py-2 text-left text-xs hover:border-red-500"
                >
                  <div><p className="text-sm font-medium text-zinc-200">{item.label}</p></div>
                  <span className="text-sm font-semibold text-zinc-300">{formatPrice(item.price)}</span>
                </button>
              ))}
            </div>
          }
          items={
            <ul className="divide-y divide-zinc-800/50 overflow-hidden rounded-xl border border-zinc-800">
              {extras.map((r, idx) => (
                <li key={r.key} className="grid gap-2 bg-zinc-900 p-3 sm:grid-cols-[1fr_100px_80px_auto] sm:items-center">
                  <input className={inputCls} value={r.label} onChange={(e) => setExtras((prev) => prev.map((x, i) => (i === idx ? { ...x, label: e.target.value } : x)))} />
                  <input className={inputCls} inputMode="numeric" value={r.price} onChange={(e) => setExtras((prev) => prev.map((x, i) => (i === idx ? { ...x, price: Math.max(0, Number(e.target.value.replace(/\D/g, "")) || 0) } : x)))} />
                  <input className={inputCls} inputMode="numeric" value={r.quantity} onChange={(e) => setExtras((prev) => prev.map((x, i) => (i === idx ? { ...x, quantity: Math.max(1, Number(e.target.value.replace(/\D/g, "")) || 1) } : x)))} />
                  <div className="flex items-center justify-between gap-3 sm:justify-end">
                    <span className="text-sm font-semibold tabular-nums text-zinc-100">{formatPrice(r.price * r.quantity)}</span>
                    <button type="button" onClick={() => setExtras((prev) => prev.filter((_, i) => i !== idx))} className="text-xs text-red-500">✕</button>
                  </div>
                </li>
              ))}
            </ul>
          }
        />

        <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-md">
          <div className="mb-3 flex items-center justify-between">
            <div><h2 className="text-base font-semibold text-zinc-100">Фотографии</h2><p className="text-xs text-zinc-400">До/после ремонта</p></div>
            <button type="button" onClick={() => fileRef.current?.click()} className="rounded-lg bg-zinc-100 px-3 py-1.5 text-xs font-semibold text-zinc-950">+ Фото</button>
            <input ref={fileRef} type="file" multiple accept="image/*" className="hidden" onChange={(e) => addFiles(e.target.files)} />
          </div>
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-4 md:grid-cols-5">
            {photos.map((p) => (
              <div key={p.id} className="group relative overflow-hidden rounded-xl border border-zinc-800 bg-zinc-800">
                <div className="relative aspect-square"><Image src={p.url} alt="фото" fill className="object-cover" sizes="200px" unoptimized /></div>
                <button type="button" onClick={() => removeExistingPhoto(p.id)} className="absolute right-1 top-1 grid h-6 w-6 place-items-center rounded-full bg-black/50 text-xs text-zinc-50 opacity-0 group-hover:opacity-100">✕</button>
              </div>
            ))}
            {previewUrls.map((url, idx) => (
              <div key={url} className="group relative overflow-hidden rounded-xl border border-dashed border-red-700 bg-red-950/20">
                <div className="relative aspect-square"><Image src={url} alt="новое" fill className="object-cover" sizes="200px" unoptimized /></div>
                <button type="button" onClick={() => setPendingFiles((p) => p.filter((_, i) => i !== idx))} className="absolute right-1 top-1 grid h-6 w-6 place-items-center rounded-full bg-black/50 text-xs text-zinc-50 opacity-0 group-hover:opacity-100">✕</button>
              </div>
            ))}
          </div>
        </section>
      </div>

      <aside className="xl:sticky xl:top-20 xl:self-start">
        <div className="overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900 shadow-2xl shadow-black/20">
          <div className="bg-gradient-to-br from-zinc-900 to-black p-5 text-white">
            <p className="text-xs font-medium uppercase tracking-wider text-zinc-500">Клиенту</p>
            <p className="mt-1 text-3xl font-bold tracking-tight">{formatPrice(totals.totalCost)}</p>
            <p className="mt-1 text-sm text-zinc-500">{dents.length} вмятин · {riItems.length} разборов · {extras.length} услуг</p>
            <div className="mt-3 grid grid-cols-2 gap-2 rounded-xl bg-black/50 p-3 text-xs">
              <div><p className="text-emerald-500">Мне (заработок)</p><p className="mt-0.5 text-sm font-bold text-zinc-50">{formatPrice(totals.earnings)}</p></div>
              <div><p className="text-amber-500">{reference.markupLabel}</p><p className="mt-0.5 text-sm font-bold text-zinc-50">{formatPrice(totals.markupAmount)} <span className="text-[10px] opacity-80">({totals.markupPercent}%)</span></p></div>
            </div>
          </div>

          <div className="space-y-2 p-5 text-sm">
            <div className="flex justify-between text-zinc-400">
              <span>ПДР (вмятины)</span>
              <span className="font-medium text-zinc-200">{formatPrice(totals.dentsTotal)}</span>
            </div>
            <div className="flex justify-between text-zinc-400">
              <span>Разбор / сборка</span>
              <span className="font-medium text-zinc-200">{formatPrice(totals.riTotal)}</span>
            </div>
            <div className="flex justify-between text-zinc-400">
              <span>Доп. услуги</span>
              <span className="font-medium text-zinc-200">{formatPrice(totals.extrasTotal)}</span>
            </div>
            <div className="flex items-center justify-between gap-3 text-zinc-400">
              <span>Скидка, ₽</span>
              <input className="w-24 rounded-lg border border-zinc-800 bg-zinc-950 px-2 py-1 text-right text-sm font-medium outline-none focus:border-red-500" value={discount || ""} onChange={(e) => setDiscount(Math.max(0, Number(e.target.value.replace(/\D/g, "")) || 0))} />
            </div>
            <div className="flex items-center justify-between gap-3 text-zinc-400">
              <span>Надбавка, %</span>
              <input className="w-24 rounded-lg border border-zinc-800 bg-zinc-950 px-2 py-1 text-right text-sm font-medium outline-none focus:border-red-500" value={markupPercent} onChange={(e) => setMarkupPercent(Math.max(0, Math.min(500, Number(e.target.value.replace(/\D/g, "")) || 0)))} />
            </div>
            {totals.minApplied && (
              <p className="rounded-lg bg-amber-950/30 px-2.5 py-1.5 text-xs text-amber-400">Применён минимум заказа {formatPrice(1500)}</p>
            )}
            <div className="border-t border-zinc-800/50 pt-2">
              <div className="flex justify-between text-zinc-400">
                <span>Моя часть</span>
                <span className="font-semibold text-emerald-400">{formatPrice(totals.earnings)}</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>+ надбавка {totals.markupPercent}%</span>
                <span className="font-semibold text-amber-400">{formatPrice(totals.markupAmount)}</span>
              </div>
              <div className="mt-1 flex justify-between text-base font-bold text-zinc-100">
                <span>К оплате</span>
                <span>{formatPrice(totals.totalCost)}</span>
              </div>
              {paidAmount > 0 && (
                <div className="mt-1 flex justify-between text-xs text-zinc-500">
                  <span>Оплачено {formatPrice(paidAmount)}</span>
                  <span>остаток {formatPrice(Math.max(0, totals.totalCost - paidAmount))}</span>
                </div>
              )}
            </div>
          </div>

          <div className="max-h-48 space-y-1 overflow-y-auto border-t border-zinc-800/50 px-5 pt-3 pb-1">
            {dents.map((item, idx) => (
              <button
                key={item.key}
                type="button"
                onClick={() => setActiveDent(idx)}
                className="flex w-full items-center justify-between gap-2 rounded-lg px-2 py-1.5 text-left text-xs hover:bg-zinc-800"
              >
                <span className="truncate text-zinc-500">
                  {panelEmojiEff(item.panel)} {panelLabelEff(item.panel)} · {formatSize(item.lengthMm, item.widthMm)}
                  {item.quantity > 1 ? ` ×${item.quantity}` : ""}
                </span>
                <span className="shrink-0 font-medium text-zinc-300">{formatPrice(dentCalcs[idx].lineTotal)}</span>
              </button>
            ))}
            {riLines.map((r) => (
              <div key={r.key} className="flex items-center justify-between gap-2 px-2 py-1 text-xs">
                <span className="truncate text-zinc-600">🔧 {r.label}</span>
                <span className="shrink-0 font-medium text-zinc-400">{formatPrice(r.lineTotal)}</span>
              </div>
            ))}
            {extraLines.map((r) => (
              <div key={r.key} className="flex items-center justify-between gap-2 px-2 py-1 text-xs">
                <span className="truncate text-zinc-600">✨ {r.label}</span>
                <span className="shrink-0 font-medium text-zinc-400">{formatPrice(r.lineTotal)}</span>
              </div>
            ))}
          </div>

          <div className="space-y-2 border-t border-zinc-800/50 p-5">
            {error && <p className="text-sm text-red-500">{error}</p>}
            <button
              type="button"
              disabled={submitting}
              onClick={promptSubmit}
              className="w-full rounded-xl bg-red-600 px-4 py-3 text-sm font-semibold text-zinc-50 shadow-lg shadow-red-600/25 hover:bg-red-500 disabled:opacity-60"
            >
              {mode === "edit" ? "Сохранить изменения" : "Создать запись"}
            </button>
          </div>
        </div>
      </aside>
    </div>

    {showCalendar && (
      <CalendarModal
        initialDate={scheduledAt ?? new Date()}
        submitting={submitting}
        onConfirm={(iso: string) => {
          setScheduledAt(new Date(iso));
          executeSubmit(iso);
        }}
        onCancel={() => setShowCalendar(false)}
      />
    )}
    </>
  );
}

function ChipGroup({ label, options, value, onChange }: { label: string; options: { id: string; label: string; hint?: string }[]; value: string; onChange: (v: string) => void; }) {
  return (
    <div>
      <p className="mb-2 text-sm font-medium text-zinc-300">{label}</p>
      <div className="flex flex-wrap gap-1.5">
        {options.map((o) => {
          const active = o.id === value;
          return (
            <button key={o.id} type="button" onClick={() => onChange(o.id)}
              className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium ${
                active ? "border-red-500 bg-red-600 text-zinc-50" : "border-zinc-800 bg-zinc-900 text-zinc-400 hover:border-zinc-700"
              }`}
            >
              {o.label}{o.hint && <span className={`text-[10px] ${active ? "opacity-80" : "text-zinc-500"}`}>{o.hint}</span>}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function LineSection({ title, subtitle, count, total, catalogOpen, onToggleCatalog, onAddCustom, catalogContent, items }: any) {
  return (
    <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-md">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <div><h2 className="text-base font-semibold text-zinc-100">{title} · {count}</h2><p className="text-xs text-zinc-500">{subtitle} · итого {formatPrice(total)}</p></div>
        <div className="flex gap-2">
          <button type="button" onClick={onToggleCatalog} className="rounded-lg bg-zinc-100 px-3 py-1.5 text-xs font-semibold text-zinc-950">{catalogOpen ? "Скрыть" : "+ Из каталога"}</button>
          <button type="button" onClick={onAddCustom} className="rounded-lg border border-zinc-800 bg-zinc-900 px-3 py-1.5 text-xs font-semibold text-zinc-300">+ Своё</button>
        </div>
      </div>
      {catalogOpen && <div className="mb-4 rounded-xl border border-red-900/50 bg-red-950/20 p-3">{catalogContent}</div>}
      {items}
    </section>
  );
}

// ---------------------------------------------------
// КРАСИВЫЙ КАЛЕНДАРЬ (МОДАЛЬНОЕ ОКНО ПОСЛЕ НАЖАТИЯ)
// ---------------------------------------------------
function CalendarModal({ initialDate, onConfirm, onCancel, submitting }: any) {
  // Читаем компоненты в UTC (мы храним wall-clock как UTC), чтобы не было сдвига.
  const init: Date = initialDate;
  const [sel, setSel] = useState({
    year: init.getUTCFullYear(),
    month: init.getUTCMonth(),
    day: init.getUTCDate(),
  });
  const [time, setTime] = useState(
    `${String(init.getUTCHours()).padStart(2, "0")}:${String(init.getUTCMinutes()).padStart(2, "0")}`
  );

  const { year, month, day } = sel;
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDay = (new Date(year, month, 1).getDay() + 6) % 7; // Monday = 0
  const days = Array(firstDay).fill(null).concat(Array.from({ length: daysInMonth }, (_, i) => i + 1));
  const monthNames = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"];

  function shiftMonth(delta: number) {
    const nd = new Date(year, month + delta, 1);
    setSel({ year: nd.getFullYear(), month: nd.getMonth(), day: 1 });
  }

  function handleConfirm() {
    const [h, m] = time.split(":").map(Number);
    // wallClockISO: то, что выбрал мастер, сохраняем без сдвига TZ
    onConfirm(wallClockISO(year, month, day, h || 0, m || 0));
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="w-full max-w-sm rounded-3xl bg-zinc-950 p-6 shadow-2xl ring-1 ring-zinc-800">
        <h2 className="text-xl font-bold text-zinc-100">Дата и время записи</h2>
        <p className="mt-1 text-sm text-zinc-400">Когда клиент приедет на ремонт?</p>

        <div className="mt-6 flex items-center justify-between rounded-xl bg-zinc-900 p-2">
          <button type="button" onClick={() => shiftMonth(-1)} className="grid h-8 w-8 place-items-center rounded-lg text-zinc-400 hover:bg-zinc-800 hover:text-white">←</button>
          <span className="font-semibold text-zinc-100">{monthNames[month]} {year}</span>
          <button type="button" onClick={() => shiftMonth(1)} className="grid h-8 w-8 place-items-center rounded-lg text-zinc-400 hover:bg-zinc-800 hover:text-white">→</button>
        </div>

        <div className="mt-4 grid grid-cols-7 gap-1 text-center text-[10px] font-bold uppercase tracking-wider text-zinc-500">
          {["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"].map((d) => (<div key={d} className="py-2">{d}</div>))}
          {days.map((d, i) => {
            if (!d) return <div key={i} />;
            const isSelected = d === day;
            return (
              <button
                key={i}
                type="button"
                onClick={() => setSel({ year, month, day: d })}
                className={`mx-auto grid h-8 w-8 place-items-center rounded-full text-sm font-medium transition-colors ${
                  isSelected ? "bg-red-600 text-white shadow-md shadow-red-600/30" : "text-zinc-300 hover:bg-zinc-800"
                }`}
              >
                {d}
              </button>
            );
          })}
        </div>

        <div className="mt-6">
          <label className="text-xs font-semibold uppercase tracking-wider text-zinc-500">Время визита</label>
          <input
            type="time"
            value={time}
            onChange={(e) => setTime(e.target.value)}
            className="mt-2 w-full rounded-xl border border-zinc-800 bg-zinc-900 px-4 py-3 text-lg font-bold text-zinc-100 outline-none focus:border-red-500 focus:ring-2 focus:ring-red-500/20"
          />
        </div>

        <div className="mt-8 flex gap-3">
          <button type="button" onClick={onCancel} disabled={submitting} className="w-full rounded-xl border border-zinc-800 bg-zinc-900 py-3 text-sm font-semibold text-zinc-300 hover:bg-zinc-800">
            Назад
          </button>
          <button type="button" onClick={handleConfirm} disabled={submitting} className="w-full rounded-xl bg-red-600 py-3 text-sm font-semibold text-white shadow-lg shadow-red-600/30 hover:bg-red-500">
            {submitting ? "..." : "Сохранить"}
          </button>
        </div>
      </div>
    </div>
  );
}
