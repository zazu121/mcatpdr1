"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { BRANDS } from "@/lib/pdr";
import { Field, inputCls } from "@/components/ui";

export function VehicleAddForm({ customerId }: { customerId: number }) {
  const router = useRouter();
  const [make, setMake] = useState("");
  const [model, setModel] = useState("");
  const [year, setYear] = useState("");
  const [color, setColor] = useState("");
  const [licensePlate, setLicensePlate] = useState("");
  const [vin, setVin] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!make.trim()) {
      setError("Укажите марку");
      return;
    }
    setLoading(true);
    setError(null);
    const res = await fetch("/api/vehicles", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        customerId,
        make,
        model,
        year: year || null,
        color,
        licensePlate,
        vin,
      }),
    });
    setLoading(false);
    if (!res.ok) {
      setError("Не удалось добавить");
      return;
    }
    setMake("");
    setModel("");
    setYear("");
    setColor("");
    setLicensePlate("");
    setVin("");
    router.refresh();
  }

  return (
    <form onSubmit={submit} className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
      <h2 className="mb-3 text-base font-semibold text-zinc-100">Добавить авто</h2>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Марка *">
          <input list="brands2" className={inputCls} value={make} onChange={(e) => setMake(e.target.value)} />
          <datalist id="brands2">{BRANDS.map((b) => <option key={b} value={b} />)}</datalist>
        </Field>
        <Field label="Модель">
          <input className={inputCls} value={model} onChange={(e) => setModel(e.target.value)} />
        </Field>
        <Field label="Год">
          <input className={inputCls} value={year} onChange={(e) => setYear(e.target.value.replace(/\D/g, "").slice(0, 4))} />
        </Field>
        <Field label="Цвет">
          <input className={inputCls} value={color} onChange={(e) => setColor(e.target.value)} />
        </Field>
        <Field label="Гос. номер">
          <input className={`${inputCls} uppercase`} value={licensePlate} onChange={(e) => setLicensePlate(e.target.value.toUpperCase())} />
        </Field>
        <Field label="VIN">
          <input className={`${inputCls} uppercase`} value={vin} onChange={(e) => setVin(e.target.value.toUpperCase())} />
        </Field>
      </div>
      {error && <p className="mt-2 text-sm text-red-500">{error}</p>}
      <button
        type="submit"
        disabled={loading}
        className="mt-3 rounded-xl bg-red-600 px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
      >
        {loading ? "…" : "Добавить авто"}
      </button>
    </form>
  );
}
