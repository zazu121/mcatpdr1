"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { JOB_STATUS, JOB_STATUS_IDS } from "@/lib/pdr";

export function JobActions({
  jobId,
  currentStatus,
  paidAmount,
  totalCost,
}: {
  jobId: number;
  currentStatus: string;
  paidAmount: number;
  totalCost: number;
}) {
  const router = useRouter();
  const [status, setStatus] = useState(currentStatus);
  const [paid, setPaid] = useState(paidAmount);
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  function patch(body: Record<string, unknown>, okMsg?: string) {
    start(async () => {
      setError(null);
      setMsg(null);
      const res = await fetch(`/api/jobs/${jobId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        setError("Не удалось обновить");
        return;
      }
      if (okMsg) setMsg(okMsg);
      router.refresh();
    });
  }

  function changeStatus(next: string) {
    setStatus(next);
    patch({ status: next }, `Статус: ${JOB_STATUS[next]?.label ?? next}`);
  }

  function savePaid() {
    patch({ paidAmount: paid }, "Оплата сохранена");
  }

  function remove() {
    if (!confirm("Удалить запись из журнала безвозвратно?")) return;
    start(async () => {
      const res = await fetch(`/api/jobs/${jobId}`, { method: "DELETE" });
      if (res.ok) router.push("/journal");
      else setError("Не удалось удалить");
    });
  }

  return (
    <div className="space-y-4">
      <div>
        <p className="mb-2 text-sm font-medium text-zinc-300">Статус</p>
        <div className="flex flex-wrap gap-1.5">
          {JOB_STATUS_IDS.map((s) => {
            const active = status === s;
            const info = JOB_STATUS[s];
            return (
              <button
                key={s}
                type="button"
                disabled={pending}
                onClick={() => changeStatus(s)}
                className={`rounded-lg px-2.5 py-1.5 text-xs font-medium ring-1 ring-inset transition-all disabled:opacity-50 ${
                  active
                    ? "bg-zinc-100 text-zinc-950 ring-zinc-100"
                    : "bg-zinc-900 text-zinc-400 ring-zinc-800 hover:ring-zinc-700"
                }`}
              >
                <span className={`mr-1.5 inline-block h-1.5 w-1.5 rounded-full ${info.dot}`} />
                {info.short}
              </button>
            );
          })}
        </div>
      </div>

      <div>
        <p className="mb-2 text-sm font-medium text-zinc-300">Оплата</p>
        <div className="flex gap-2">
          <input
            type="number"
            min={0}
            value={paid}
            onChange={(e) => setPaid(Math.max(0, Number(e.target.value) || 0))}
            className="w-full rounded-xl border border-zinc-800 px-3 py-2 text-sm outline-none focus:border-red-500"
          />
          <button
            type="button"
            disabled={pending}
            onClick={savePaid}
            className="shrink-0 rounded-xl bg-zinc-100 px-3 py-2 text-xs font-semibold text-zinc-950 disabled:opacity-50"
          >
            OK
          </button>
        </div>
        <div className="mt-1.5 flex flex-wrap gap-2">
          <button
            type="button"
            className="text-xs font-medium text-red-500"
            onClick={() => {
              setPaid(totalCost);
              patch({ paidAmount: totalCost }, "Отмечено как оплачено");
            }}
          >
            Оплачено полностью
          </button>
          <button
            type="button"
            className="text-xs font-medium text-zinc-400"
            onClick={() => {
              setPaid(0);
              patch({ paidAmount: 0 }, "Оплата сброшена");
            }}
          >
            Сбросить
          </button>
        </div>
      </div>

      {error && <p className="text-sm text-red-500">{error}</p>}
      {msg && <p className="text-sm text-emerald-500">{msg}</p>}

      <div className="flex flex-wrap gap-2 border-t border-zinc-800/50 pt-4">
        <a
          href={`/journal/${jobId}/edit`}
          className="rounded-xl bg-red-600 px-4 py-2 text-sm font-semibold text-white"
        >
          Редактировать
        </a>
        <button
          type="button"
          onClick={remove}
          disabled={pending}
          className="rounded-xl border border-rose-200 bg-zinc-900 px-4 py-2 text-sm font-medium text-red-500 hover:bg-rose-50 disabled:opacity-50"
        >
          Удалить
        </button>
      </div>
    </div>
  );
}
