import Link from "next/link";
import { JOB_STATUS, formatPrice } from "@/lib/pdr";

export function StatusBadge({ status }: { status: string }) {
  const info = JOB_STATUS[status] ?? JOB_STATUS.scheduled;
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset ${info.color}`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${info.dot}`} />
      {info.label}
    </span>
  );
}

export function Money({ amount }: { amount: number }) {
  return <span className="tabular-nums font-semibold">{formatPrice(amount)}</span>;
}

export function EmptyState({
  icon,
  title,
  text,
  actionHref,
  actionLabel,
}: {
  icon: string;
  title: string;
  text: string;
  actionHref?: string;
  actionLabel?: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-zinc-700 bg-zinc-900 px-6 py-16 text-center">
      <div className="grid h-14 w-14 place-items-center rounded-2xl bg-zinc-800 text-2xl">{icon}</div>
      <p className="mt-4 text-sm font-semibold text-zinc-200">{title}</p>
      <p className="mt-1 max-w-sm text-sm text-zinc-400">{text}</p>
      {actionHref && actionLabel && (
        <Link
          href={actionHref}
          className="mt-5 inline-flex rounded-xl bg-zinc-100 px-4 py-2.5 text-sm font-semibold text-zinc-950"
        >
          {actionLabel}
        </Link>
      )}
    </div>
  );
}

export const inputCls =
  "w-full rounded-xl border border-zinc-800 bg-zinc-900 px-3.5 py-2.5 text-sm text-zinc-100 shadow-sm outline-none transition-colors placeholder:text-zinc-500 focus:border-red-500 focus:ring-2 focus:ring-red-500/30";

export const labelCls = "mb-1.5 block text-sm font-medium text-zinc-300";

export function Field({
  label,
  children,
  className = "",
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <label className={`block ${className}`}>
      <span className={labelCls}>{label}</span>
      {children}
    </label>
  );
}

export function Card({
  children,
  className = "",
  title,
  action,
}: {
  children: React.ReactNode;
  className?: string;
  title?: string;
  action?: React.ReactNode;
}) {
  return (
    <section className={`rounded-2xl border border-zinc-800 bg-zinc-900 shadow-sm ${className}`}>
      {(title || action) && (
        <div className="flex items-center justify-between border-b border-zinc-800/50 px-5 py-3.5">
          {title ? <h2 className="text-base font-semibold text-zinc-100">{title}</h2> : <span />}
          {action}
        </div>
      )}
      {children}
    </section>
  );
}
