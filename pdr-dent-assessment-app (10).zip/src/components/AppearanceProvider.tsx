"use client";

import { useEffect } from "react";
import { loadAppearance, applyAppearance } from "@/lib/appearance";

// Применяет сохранённое оформление как можно раньше на клиенте.
export function AppearanceProvider() {
  useEffect(() => {
    applyAppearance(loadAppearance());
  }, []);
  return null;
}
