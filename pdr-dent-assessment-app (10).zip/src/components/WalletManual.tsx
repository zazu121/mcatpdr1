"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { inputCls } from "@/components/ui";
import type { WalletEntry } from "@/db/schema";

export function WalletManual({ entries: _entries }: { entries: WalletEntry[] }) {
  const router = useRouter();
  const [kind, setKind] = useState<"income" | "expense">("income");
  const [amount, setAmount] = useState(0);
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [saving, setSaving] = useState(false);

  async function add() {
    if (!amount) return;
    setSaving(true);
    await fetch("/api/wallet", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kind, amount, category, description }),
    });
    setSaving(false);
    setAmount(0);
    setCategory("");
    setDescription("");
    router.refresh();
  }

  return (
    <div className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
      <h3 className="mb-3 text-base font-semibold text-zinc-100">Добавить операцию</h3>
      <div className="mb-3 grid grid-cols-2 gap-1 rounded-xl bg-zinc-800 p-1">
        <button
          type="button"
          onClick={() => setKind("income")}
          className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
            kind === "income" ? "bg-zinc-900 text-emerald-700 shadow" : "text-zinc-400"
          }`}
        >
          + Доход
        </button>
        <button
          type="button"
          onClick={() => setKind("expense")}
          className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
            kind === "expense" ? "bg-zinc-900 text-rose-700 shadow" : "text-zinc-400"
          }`}
        >
          − Расход
        </button>
      </div>
      <div className="space-y-2">
        <input
          type="number"
          min={0}
          className={`${inputCls} text-right text-lg font-semibold`}
          value={amount || ""}
          onChange={(e) => setAmount(Math.max(0, Number(e.target.value.replace(/\D/g, "")) || 0))}
          placeholder="Сумма, ₽"
          inputMode="numeric"
        />
        <input className={inputCls} value={category} onChange={(e) => setCategory(e.target.value)} placeholder="Категория (аренда, инструмент…)" />
        <input className={inputCls} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Комментарий" />
        <button
          type="button"
          onClick={add}
          disabled={saving || !amount}
          className="w-full rounded-xl bg-zinc-100 px-4 py-2.5 text-sm font-semibold text-zinc-950 disabled:opacity-60"
        >
          {saving ? "…" : "Добавить"}
        </button>
      </div>
    </div>
  );
}
