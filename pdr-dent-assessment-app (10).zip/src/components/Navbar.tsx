"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { loadAppearance, type Appearance } from "@/lib/appearance";

const links = [
  { href: "/", label: "Дашборд", icon: "grid" },
  { href: "/journal", label: "Журнал", icon: "book" },
  { href: "/calculator", label: "Калькулятор", icon: "calc" },
  { href: "/customers", label: "Клиенты", icon: "users" },
  { href: "/wallet", label: "Кошелёк", icon: "wallet" },
  { href: "/settings", label: "Настройки", icon: "gear" },
];

function Icon({ name, className = "h-5 w-5" }: { name: string; className?: string }) {
  const paths: Record<string, React.ReactNode> = {
    grid: <path strokeLinecap="round" strokeLinejoin="round" d="M4 5h6v6H4V5zm10 0h6v6h-6V5zM4 15h6v4H4v-4zm10 0h6v4h-6v-4z" />,
    book: <path strokeLinecap="round" strokeLinejoin="round" d="M4 5a2 2 0 012-2h12v16H6a2 2 0 00-2 2V5z" />,
    calc: <path strokeLinecap="round" strokeLinejoin="round" d="M7 3h10a1 1 0 011 1v16a1 1 0 01-1 1H7a1 1 0 01-1-1V4a1 1 0 011-1zm1 4h8M8 11h2m3 0h3M8 15h2m3 0h3" />,
    users: <path strokeLinecap="round" strokeLinejoin="round" d="M15 19a4 4 0 00-8 0M11 11a3 3 0 100-6 3 3 0 000 6zm6 8a3 3 0 00-2-2.8M16 11a2.5 2.5 0 000-5" />,
    wallet: <path strokeLinecap="round" strokeLinejoin="round" d="M3 7a2 2 0 012-2h12a2 2 0 012 2v1h1a1 1 0 011 1v6a1 1 0 01-1 1h-1v1a2 2 0 01-2 2H5a2 2 0 01-2-2V7zm14 4a1 1 0 100 2 1 1 0 000-2z" />,
    gear: <path strokeLinecap="round" strokeLinejoin="round" d="M12 15a3 3 0 100-6 3 3 0 000 6zm7.4-3a7.4 7.4 0 00-.1-1l2-1.5-2-3.4-2.3 1a7.3 7.3 0 00-1.7-1l-.4-2.5H10l-.4 2.5a7.3 7.3 0 00-1.7 1l-2.3-1-2 3.4 2 1.5a7.4 7.4 0 000 2l-2 1.5 2 3.4 2.3-1a7.3 7.3 0 001.7 1l.4 2.5h4l.4-2.5a7.3 7.3 0 001.7-1l2.3 1 2-3.4-2-1.5c.1-.3.1-.7.1-1z" />,
  };
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth={1.8}>
      {paths[name]}
    </svg>
  );
}

export function Navbar() {
  const pathname = usePathname();
  const [ap, setAp] = useState<Appearance | null>(null);

  useEffect(() => {
    setAp(loadAppearance());
    const handler = (e: Event) => setAp((e as CustomEvent).detail);
    window.addEventListener("appearance-change", handler);
    return () => window.removeEventListener("appearance-change", handler);
  }, []);

  const navPosition = ap?.navPosition ?? "top";
  const navStyle = ap?.navStyle ?? "both";
  const iconsOnly = navStyle === "icon";
  const textOnly = navStyle === "text";

  const isActive = (href: string) =>
    href === "/" ? pathname === "/" : pathname === href || pathname.startsWith(href + "/");

  // ------- НИЖНЯЯ НАВИГАЦИЯ -------
  if (navPosition === "bottom") {
    return (
      <>
        <header className="sticky top-0 z-40 border-b border-zinc-800/80 bg-zinc-950/85 backdrop-blur-lg">
          <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4 sm:px-6">
            <Link href="/" className="flex items-center gap-2.5">
              <Logo />
              <span className="text-sm font-bold tracking-tight text-zinc-100">MCAT PDR</span>
            </Link>
            <Link href="/journal/new" className="theme-glow rounded-lg bg-red-600 px-3.5 py-2 text-sm font-semibold text-white shadow-sm shadow-red-600/30">
              + Запись
            </Link>
          </div>
        </header>

        <nav className="fixed inset-x-0 bottom-0 z-50 border-t border-zinc-800 bg-zinc-950/95 backdrop-blur-lg">
          <div className="mx-auto flex max-w-2xl items-center justify-around px-1 py-1.5">
            {links.map((l) => {
              const active = isActive(l.href);
              return (
                <Link
                  key={l.href}
                  href={l.href}
                  className={`flex flex-1 flex-col items-center gap-0.5 rounded-lg px-1 py-1.5 text-[10px] font-medium transition-colors ${
                    active ? "text-red-500" : "text-zinc-500 hover:text-zinc-300"
                  }`}
                >
                  {!textOnly && <Icon name={l.icon} className="h-5 w-5" />}
                  {!iconsOnly && <span className="truncate">{l.label}</span>}
                </Link>
              );
            })}
          </div>
        </nav>
      </>
    );
  }

  // ------- ВЕРХНЯЯ НАВИГАЦИЯ (по умолчанию) -------
  return (
    <header className="sticky top-0 z-40 border-b border-zinc-800/80 bg-zinc-950/85 backdrop-blur-lg">
      <div className="mx-auto flex h-14 max-w-7xl items-center justify-between gap-3 px-3 sm:h-16 sm:px-6">
        <Link href="/" className="flex shrink-0 items-center gap-2.5">
          <Logo />
          <div className="leading-tight">
            <span className="block text-sm font-bold tracking-tight text-zinc-100">MCAT PDR</span>
            <span className="hidden text-[10px] font-medium uppercase tracking-[0.16em] text-red-500 sm:block">PDR · Журнал</span>
          </div>
        </Link>

        <nav className="flex items-center gap-0.5 overflow-x-auto">
          {links.map((l) => {
            const active = isActive(l.href);
            return (
              <Link
                key={l.href}
                href={l.href}
                title={l.label}
                className={`flex items-center gap-1.5 whitespace-nowrap rounded-lg px-2.5 py-2 text-sm font-medium transition-colors sm:px-3 ${
                  active ? "bg-zinc-100 text-zinc-950" : "text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100"
                }`}
              >
                {!textOnly && <Icon name={l.icon} className="h-4 w-4" />}
                {!iconsOnly && <span>{l.label}</span>}
              </Link>
            );
          })}
        </nav>

        <Link href="/journal/new" className="theme-glow hidden shrink-0 rounded-lg bg-red-600 px-3.5 py-2 text-sm font-semibold text-white shadow-sm shadow-red-600/30 sm:inline-flex">
          + Запись
        </Link>
      </div>
    </header>
  );
}

function Logo() {
  return (
    <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-red-500 to-red-700 text-white shadow-lg shadow-red-600/25">
      <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 13l1.5-4.5A2 2 0 016.4 7h11.2a2 2 0 011.9 1.5L21 13M3 13h18M3 13v4a1 1 0 001 1h1a1 1 0 001-1v-1h12v1a1 1 0 001 1h1a1 1 0 001-1v-4" />
        <circle cx="7.5" cy="16.5" r="0.6" fill="currentColor" />
        <circle cx="16.5" cy="16.5" r="0.6" fill="currentColor" />
      </svg>
    </span>
  );
}
