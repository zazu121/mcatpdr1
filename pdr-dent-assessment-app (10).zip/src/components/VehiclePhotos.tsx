"use client";

import { useRef, useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import type { VehiclePhoto } from "@/db/schema";

export function VehiclePhotos({ vehicleId, initial }: { vehicleId: number; initial: VehiclePhoto[] }) {
  const router = useRouter();
  const [photos, setPhotos] = useState<VehiclePhoto[]>(initial);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  async function upload(files: FileList | null) {
    if (!files) return;
    setUploading(true);
    for (const f of Array.from(files)) {
      if (!f.type.startsWith("image/")) continue;
      const fd = new FormData();
      fd.append("vehicleId", String(vehicleId));
      fd.append("file", f);
      const res = await fetch("/api/vehicle-photos", { method: "POST", body: fd });
      if (res.ok) {
        const data = await res.json();
        setPhotos((p) => [...p, data.photo]);
      }
    }
    setUploading(false);
    router.refresh();
  }

  async function remove(pid: number) {
    await fetch(`/api/vehicle-photos?id=${pid}`, { method: "DELETE" });
    setPhotos((p) => p.filter((x) => x.id !== pid));
    router.refresh();
  }

  return (
    <div className="mt-2">
      <div className="flex flex-wrap gap-2">
        {photos.map((p) => (
          <div key={p.id} className="group relative h-16 w-16 overflow-hidden rounded-lg border border-zinc-800">
            <Image src={p.url} alt="авто" fill className="object-cover" sizes="64px" unoptimized />
            <button type="button" onClick={() => remove(p.id)} className="absolute right-0.5 top-0.5 grid h-5 w-5 place-items-center rounded-full bg-black/60 text-[10px] text-white opacity-0 group-hover:opacity-100">✕</button>
          </div>
        ))}
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          disabled={uploading}
          className="grid h-16 w-16 place-items-center rounded-lg border border-dashed border-zinc-700 text-xl text-zinc-500 hover:border-red-500 hover:text-red-500 disabled:opacity-50"
        >
          {uploading ? "…" : "+"}
        </button>
        <input ref={fileRef} type="file" accept="image/*" multiple className="hidden" onChange={(e) => upload(e.target.files)} />
      </div>
    </div>
  );
}
