"use client";

import { useEffect, useState } from "react";
import {
  loadAppearance,
  saveAppearance,
  WALLPAPERS,
  type Appearance,
  type ThemeMode,
  type NavPosition,
  type NavStyle,
  type Wallpaper,
} from "@/lib/appearance";

export function AppearanceTab() {
  const [ap, setAp] = useState<Appearance | null>(null);

  useEffect(() => {
    setAp(loadAppearance());
  }, []);

  if (!ap) return <div className="text-sm text-zinc-500">Загрузка…</div>;

  function update(patch: Partial<Appearance>) {
    const next = { ...ap!, ...patch };
    setAp(next);
    saveAppearance(next);
  }

  return (
    <div className="space-y-5">
      {/* Тема */}
      <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
        <h3 className="mb-1 text-base font-semibold text-zinc-100">Тема</h3>
        <p className="mb-4 text-sm text-zinc-400">Светлая или тёмная.</p>
        <div className="flex gap-2">
          <button
            type="button"
            className={`flex-1 rounded-xl border px-4 py-3 text-sm font-semibold transition-colors ${
              ap.theme === "dark" ? "border-red-500 bg-red-600 text-white" : "border-zinc-800 bg-zinc-900 text-zinc-300 hover:border-zinc-700"
            }`}
          >
            🌙 Тёмная
          </button>
        </div>
        <p className="mt-3 text-xs text-zinc-500">Светлая тема отключена.</p>
      </section>

      {/* Обои */}
      <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
        <h3 className="mb-1 text-base font-semibold text-zinc-100">Обои / фон</h3>
        <p className="mb-4 text-sm text-zinc-400">Оформление фона приложения.</p>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {WALLPAPERS.map((w) => (
            <button
              key={w.id}
              type="button"
              onClick={() => update({ wallpaper: w.id as Wallpaper })}
              className={`group overflow-hidden rounded-xl border-2 text-left transition-all ${
                ap.wallpaper === w.id ? "border-red-500 ring-2 ring-red-500/30" : "border-zinc-800 hover:border-zinc-700"
              }`}
            >
              <div className="h-16 w-full" style={{ background: w.preview }} />
              <div className="flex items-center justify-between px-3 py-2">
                <span className="text-xs font-medium text-zinc-200">{w.label}</span>
                {ap.wallpaper === w.id && <span className="text-red-500">●</span>}
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Навигация */}
      <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 shadow-sm">
        <h3 className="mb-1 text-base font-semibold text-zinc-100">Навигация</h3>
        <p className="mb-4 text-sm text-zinc-400">Где показывать меню и как.</p>

        <div className="mb-4">
          <p className="mb-2 text-sm font-medium text-zinc-300">Расположение</p>
          <div className="flex gap-2">
            {([["top", "Сверху"], ["bottom", "Снизу"]] as [NavPosition, string][]).map(([v, l]) => (
              <button
                key={v}
                type="button"
                onClick={() => update({ navPosition: v })}
                className={`flex-1 rounded-xl border px-4 py-2.5 text-sm font-semibold transition-colors ${
                  ap.navPosition === v ? "border-red-500 bg-red-600 text-white" : "border-zinc-800 bg-zinc-900 text-zinc-300 hover:border-zinc-700"
                }`}
              >
                {l}
              </button>
            ))}
          </div>
        </div>

        <div>
          <p className="mb-2 text-sm font-medium text-zinc-300">Вид кнопок</p>
          <div className="flex gap-2">
            {([["both", "Текст + иконка"], ["icon", "Только иконки"], ["text", "Только текст"]] as [NavStyle, string][]).map(([v, l]) => (
              <button
                key={v}
                type="button"
                onClick={() => update({ navStyle: v })}
                className={`flex-1 rounded-xl border px-4 py-2.5 text-sm font-semibold transition-colors ${
                  ap.navStyle === v ? "border-red-500 bg-red-600 text-white" : "border-zinc-800 bg-zinc-900 text-zinc-300 hover:border-zinc-700"
                }`}
              >
                {l}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Офлайн-версия */}
      <section className="rounded-2xl border border-red-900/40 bg-red-950/10 p-5 shadow-sm">
        <h3 className="mb-1 text-base font-semibold text-zinc-100">📱 Офлайн-версия для телефона</h3>
        <p className="mb-4 text-sm text-zinc-400">
          Один HTML-файл: калькулятор, журнал, клиенты, кошелёк и настройки. Работает без интернета
          и без сервера — данные хранятся в памяти телефона.
        </p>
        <div className="flex flex-wrap gap-2">
          <a
            href="/mcat-pdr-offline.html"
            download="MCAT-PDR.html"
            className="rounded-xl bg-red-600 px-4 py-2.5 text-sm font-semibold text-white shadow-lg shadow-red-600/25 hover:bg-red-500"
          >
            ⬇ Скачать MCAT-PDR.html
          </a>
          <a
            href="/mcat-pdr-offline.html"
            target="_blank"
            rel="noopener"
            className="rounded-xl border border-zinc-700 bg-zinc-900 px-4 py-2.5 text-sm font-semibold text-zinc-200 hover:border-zinc-600"
          >
            Открыть сейчас
          </a>
        </div>
        <ol className="mt-4 space-y-1 text-xs text-zinc-500">
          <li>1. Скачайте файл на телефон.</li>
          <li>2. Откройте его любым браузером (файл → «Открыть в браузере»).</li>
          <li>3. В меню браузера — «Добавить на главный экран», чтобы был как приложение.</li>
          <li>4. Работает полностью офлайн. Резервная копия — кнопка «Экспорт» в настройках.</li>
        </ol>
      </section>

      <p className="text-center text-xs text-zinc-500">Настройки оформления сохраняются на этом устройстве.</p>
    </div>
  );
}
